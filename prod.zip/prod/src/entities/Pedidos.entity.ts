import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Pessoa } from './Pessoa.entity';
import { SubPedidos } from './SubPedidos.entity';
import { Pagamentos } from './Pagamentos.entity';
import { Entregas } from './Entregas.entity';
import { PedidoItens } from './PedidoItens.entity';

@Entity('pedidos')
export class Pedidos {
  @PrimaryGeneratedColumn()
  id_pedido: number;

  @Column({ type: 'int', name: 'cliente_id' })
  cliente_id: number;

  @Column({ type: 'decimal', name: 'total_produtos', precision: 10, scale: 2 })
  total_produtos: string;

  @Column({ type: 'decimal', name: 'taxa_entrega', precision: 10, scale: 2, default: 0.00 })
  taxa_entrega: string;

  @Column({ type: 'decimal', name: 'total_geral', precision: 10, scale: 2, generatedType: 'STORED', asExpression: 'total_produtos + taxa_entrega' })
  total_geral: string;

  @Column({
    type: 'enum',
    name: 'status_pedido',
    enum: ['PENDENTE', 'EM_PROCESSAMENTO', 'PAGO', 'CONCLUIDO', 'CANCELADO'],
    default: 'PENDENTE',
  })
  status_pedido: string;

  @Column({ type: 'varchar', length: 255, name: 'endereco_entrega_alternativo', nullable: true })
  endereco_entrega_alternativo: string | null;

  @Column({ type: 'timestamp', name: 'data_pedido', default: () => 'CURRENT_TIMESTAMP' })
  data_pedido: Date;

  @ManyToOne(() => Pessoa, (pessoa) => pessoa.pedidos)
  @JoinColumn({ name: 'cliente_id' })
  cliente: Pessoa;

  @OneToMany(() => SubPedidos, (sub) => sub.pedidoPai)
  subPedidos: SubPedidos[];

  @OneToMany(() => Pagamentos, (pag) => pag.pedido)
  pagamentos: Pagamentos[];

  @OneToMany(() => Entregas, (ent) => ent.pedido)
  entregas: Entregas[];

  @OneToMany(() => PedidoItens, (item) => item.pedido)
  pedidoItens: PedidoItens[];
}
