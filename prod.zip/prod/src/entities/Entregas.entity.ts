import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Pedidos } from './Pedidos.entity';
import { Pessoa } from './Pessoa.entity';

@Entity('entregas')
export class Entregas {
  @PrimaryGeneratedColumn()
  id_entrega: number;

  @Column({ type: 'int', name: 'pedido_id' })
  pedido_id: number;

  @Column({ type: 'int', name: 'estafeta_id', nullable: true })
  estafeta_id: number | null;

  @Column({
    type: 'enum',
    name: 'status_entrega',
    enum: ['AGUARDANDO_ESTAFETA', 'A_CAMINHO_DA_LOJA', 'EM_TRANSPORTE', 'ENTREGUE', 'FALHADA'],
    default: 'AGUARDANDO_ESTAFETA',
  })
  status_entrega: string;

  @Column({ type: 'varchar', length: 6, name: 'codigo_verificacao' })
  codigo_verificacao: string;

  @Column({ type: 'timestamp', name: 'data_recolha', nullable: true })
  data_recolha: Date | null;

  @Column({ type: 'timestamp', name: 'data_entrega_confirmada', nullable: true })
  data_entrega_confirmada: Date | null;

  @ManyToOne(() => Pedidos, (pedido) => pedido.entregas)
  @JoinColumn({ name: 'pedido_id' })
  pedido: Pedidos;

  @ManyToOne(() => Pessoa, (pessoa) => pessoa.entregas)
  @JoinColumn({ name: 'estafeta_id' })
  estafeta: Pessoa;
}
