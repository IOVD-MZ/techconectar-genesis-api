import { Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn } from 'typeorm';
import { Pessoa } from './Pessoa.entity';

@Entity('estabelecimentos')
export class Estabelecimentos {
  @PrimaryGeneratedColumn()
  id_estabelecimento: number;

  @Column({ type: 'int', name: 'pessoa_id' })
  pessoa_id: number;

  @Column({ type: 'varchar', length: 255, name: 'nome_comercial' })
  nome_comercial: string;

  @Column({ type: 'varchar', length: 20, name: 'nuit', nullable: true })
  nuit: string | null;

  @Column({ type: 'decimal', name: 'raio_entrega_km', precision: 5, scale: 2, default: 5.00 })
  raio_entrega_km: string;

  @Column({ type: 'int', name: 'tempo_medio_preparo_min', default: 30 })
  tempo_medio_preparo_min: number;

  @Column({ type: 'tinyint', name: 'is_aberto', default: 1 })
  is_aberto: boolean;

  @Column({ type: 'decimal', name: 'comissao_plataforma_pct', precision: 5, scale: 2, default: 10.00 })
  comissao_plataforma_pct: string;

  @Column({ type: 'varchar', length: 50, name: 'dados_pagamento_mpesa', nullable: true })
  dados_pagamento_mpesa: string | null;

  @Column({ type: 'timestamp', name: 'criado_em', default: () => 'CURRENT_TIMESTAMP' })
  criado_em: Date;

  @Column({ type: 'timestamp', name: 'atualizado_em', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  atualizado_em: Date;

  @OneToOne(() => Pessoa, (pessoa) => pessoa.estabelecimento)
  @JoinColumn({ name: 'pessoa_id' })
  pessoa: Pessoa;
}
