import { Entity, PrimaryGeneratedColumn, Column, OneToMany, ManyToOne, JoinColumn } from 'typeorm';
import { Produtos } from './Produtos.entity';

@Entity('categorias')
export class Categorias {
  @PrimaryGeneratedColumn()
  id_categoria: number;

  @Column({ type: 'varchar', length: 100, name: 'nome' })
  nome: string;

  @Column({ type: 'int', name: 'categoria_pai_id', nullable: true })
  categoria_pai_id: number | null;

  @ManyToOne(() => Categorias, (cat) => cat.subCategorias)
  @JoinColumn({ name: 'categoria_pai_id' })
  categoriaPai: Categorias;

  @OneToMany(() => Categorias, (cat) => cat.categoriaPai)
  subCategorias: Categorias[];

  @OneToMany(() => Produtos, (prod) => prod.categoria)
  produtos: Produtos[];
}
