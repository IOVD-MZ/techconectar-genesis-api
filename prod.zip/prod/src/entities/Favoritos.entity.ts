import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { Pessoa } from './Pessoa.entity';
import { Produtos } from './Produtos.entity';

@Entity('favoritos')
export class Favoritos {
  @PrimaryGeneratedColumn()
  id_favorito: number;

  @Column({ type: 'int', name: 'cliente_id' })
  cliente_id: number;

  @Column({ type: 'int', name: 'produto_id' })
  produto_id: number;

  @CreateDateColumn({ name: 'criado_em' })
  criado_em: Date;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'cliente_id' })
  cliente: Pessoa;

  @ManyToOne(() => Produtos)
  @JoinColumn({ name: 'produto_id' })
  produto: Produtos;
}
