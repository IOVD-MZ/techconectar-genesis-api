import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Pessoa } from './Pessoa.entity';
import { Anexo } from './Anexo.entity';

@Entity('pessoa_anexo')
export class PessoaAnexo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int', name: 'pessoa_id' })
  pessoa_id: number;

  @Column({ type: 'int', name: 'anexo_id' })
  anexo_id: number;

  @Column({ type: 'enum', name: 'tipo', enum: ['foto', 'outra_imagem'], default: 'foto' })
  tipo: string;

  @CreateDateColumn({ name: 'criado_em' })
  criado_em: Date;

  @UpdateDateColumn({ name: 'atualizado_em' })
  atualizado_em: Date;

  @ManyToOne(() => Pessoa, (pessoa) => pessoa.anexos)
  @JoinColumn({ name: 'pessoa_id' })
  pessoa: Pessoa;

  @ManyToOne(() => Anexo, (anexo) => anexo.pessoas)
  @JoinColumn({ name: 'anexo_id' })
  anexo: Anexo;
}
