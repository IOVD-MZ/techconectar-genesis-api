import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Pessoa } from './Pessoa.entity';
import { Anexo } from './Anexo.entity';

@Entity('pessoa_anexo')
export class PessoaAnexo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int', name: 'pessoa_id' })
  pessoa_id: number;

  @Column({ type: 'int', name: 'anexo_id' })
  anexo_id: number;

  @Column({
    type: 'enum',
    name: 'tipo',
    enum: [
      'foto','outra_imagem','avatar','capa_perfil','documento_id',
      'thumbnail','historico','banner_hero','banner_secundario',
      'banner_masonry','banner_evento',
    ],
    default: 'foto',
  })
  tipo: string;

  @Column({ type: 'json', name: 'config', nullable: true })
  config: any;

  @CreateDateColumn({ name: 'criado_em' })
  criado_em: Date;

  @UpdateDateColumn({ name: 'atualizado_em' })
  atualizado_em: Date;

  @ManyToOne(() => Pessoa, (pessoa) => pessoa.anexos, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'pessoa_id', referencedColumnName: 'idpessoa' })
  pessoa: Pessoa;

  @ManyToOne(() => Anexo, (anexo) => anexo.pessoas, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'anexo_id', referencedColumnName: 'id' })
  anexo: Anexo;
}
