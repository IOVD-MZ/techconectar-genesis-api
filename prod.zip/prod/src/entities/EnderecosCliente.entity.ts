import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Pessoa } from './Pessoa.entity';

@Entity('enderecos_cliente')
export class EnderecosCliente {
  @PrimaryGeneratedColumn()
  id_endereco: number;

  @Column({ type: 'int', name: 'cliente_id' })
  cliente_id: number;

  @Column({ type: 'varchar', length: 50, name: 'rotulo', default: 'Casa' })
  rotulo: string;

  @Column({ type: 'varchar', length: 255, name: 'endereco_fisico' })
  endereco_fisico: string;

  @Column({ type: 'varchar', length: 255, name: 'ponto_referencia', nullable: true })
  ponto_referencia: string | null;

  @Column({ type: 'decimal', name: 'latitude', precision: 10, scale: 8, nullable: true })
  latitude: string | null;

  @Column({ type: 'decimal', name: 'longitude', precision: 11, scale: 8, nullable: true })
  longitude: string | null;

  @Column({ type: 'tinyint', name: 'is_padrao', default: 0 })
  is_padrao: boolean;

  @Column({ type: 'timestamp', name: 'criado_em', default: () => 'CURRENT_TIMESTAMP' })
  criado_em: Date;

  @ManyToOne(() => Pessoa, (pessoa) => pessoa.enderecos)
  @JoinColumn({ name: 'cliente_id' })
  cliente: Pessoa;
}
