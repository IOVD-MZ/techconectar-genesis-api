import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Pessoa } from './Pessoa.entity';
import { Categorias } from './Categorias.entity';
import { PedidoItens } from './PedidoItens.entity';
import { CarrinhoItens } from './CarrinhoItens.entity';
import { ProdutoAnexo } from './ProdutoAnexo.entity';

@Entity('produtos')
export class Produtos {
  @PrimaryGeneratedColumn()
  id_produto: number;

  @Column({ type: 'int', name: 'fornecedor_id', nullable: true })
  fornecedor_id: number | null;

  @Column({ type: 'int', name: 'categoria_id' })
  categoria_id: number;

  @Column({ type: 'varchar', length: 255, name: 'nome' })
  nome: string;

  @Column({ type: 'text', name: 'descricao', nullable: true })
  descricao: string | null;

  @Column({ type: 'decimal', name: 'preco', precision: 10, scale: 2 })
  preco: string;

  @Column({ type: 'decimal', name: 'preco_promocional', precision: 10, scale: 2, nullable: true })
  preco_promocional: string | null;

  @Column({ type: 'int', name: 'stock', default: 0 })
  stock: number;

  @Column({
    type: 'enum',
    name: 'status_produto',
    enum: ['DISPONIVEL', 'INDISPONIVEL', 'DESCONTINUADO', 'SOB_ENCOMENDA'],
    default: 'DISPONIVEL',
  })
  status_produto: string;

  @Column({ type: 'tinyint', name: 'destaque_patrocinado', default: 0 })
  destaque_patrocinado: boolean;

  @Column({ type: 'date', name: 'validade', nullable: true })
  validade: string | null;

  @Column({ type: 'tinyint', name: 'is_perecivel', default: 0 })
  is_perecivel: boolean;

  @Column({ type: 'json', name: 'atributos_especificos', nullable: true })
  atributos_especificos: any;

  @Column({ type: 'int', name: 'requisicao_especial_id', nullable: true })
  requisicao_especial_id: number | null;

  @Column({ type: 'timestamp', name: 'data_criacao', default: () => 'CURRENT_TIMESTAMP' })
  data_criacao: Date;

  @Column({ type: 'timestamp', name: 'data_atualizacao', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  data_atualizacao: Date;

  @ManyToOne(() => Pessoa, (pessoa) => pessoa.produtos)
  @JoinColumn({ name: 'fornecedor_id' })
  fornecedor: Pessoa;

  @ManyToOne(() => Categorias, (categoria) => categoria.produtos)
  @JoinColumn({ name: 'categoria_id' })
  categoria: Categorias;

  @OneToMany(() => PedidoItens, (item) => item.produto)
  pedidoItens: PedidoItens[];

  @OneToMany(() => CarrinhoItens, (item) => item.produto)
  carrinhoItens: CarrinhoItens[];

  @OneToMany(() => ProdutoAnexo, (pa) => pa.produto)
  anexos: ProdutoAnexo[];
}
