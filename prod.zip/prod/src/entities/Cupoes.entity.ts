import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity('cupoes')
export class Cupoes {
  @PrimaryGeneratedColumn()
  id_cupom: number;

  @Column({ type: 'varchar', length: 30, name: 'codigo', unique: true })
  codigo: string;

  @Column({ type: 'varchar', length: 255, name: 'descricao', nullable: true })
  descricao: string | null;

  @Column({
    type: 'enum',
    name: 'tipo_desconto',
    enum: ['PERCENTUAL', 'VALOR_FIXO'],
    default: 'PERCENTUAL',
  })
  tipo_desconto: string;

  @Column({ type: 'decimal', name: 'valor_desconto', precision: 10, scale: 2 })
  valor_desconto: string;

  @Column({ type: 'decimal', name: 'valor_minimo_pedido', precision: 10, scale: 2, default: 0.00 })
  valor_minimo_pedido: string;

  @Column({ type: 'int', name: 'limite_uso_total', nullable: true })
  limite_uso_total: number | null;

  @Column({ type: 'int', name: 'limite_uso_por_cliente', default: 1 })
  limite_uso_por_cliente: number;

  @Column({ type: 'datetime', name: 'data_inicio' })
  data_inicio: Date;

  @Column({ type: 'datetime', name: 'data_fim' })
  data_fim: Date;

  @Column('tinyint', { name: 'is_ativo', default: 1 })
  is_ativo: boolean;

  @CreateDateColumn({ name: 'criado_em' })
  criado_em: Date;
}
