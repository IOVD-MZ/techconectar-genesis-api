import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinTable } from 'typeorm';
import { Usuario } from './Usuario.entity';
import { Permissao } from './Permissao.entity';

@Entity('papel')
export class Papel {
  @PrimaryGeneratedColumn()
  idpapel: number;

  @Column({ type: 'varchar', length: 50, name: 'nome' })
  nome: string;

  @Column({ type: 'text', name: 'descricao', nullable: true })
  descricao: string | null;

  @Column({ type: 'timestamp', name: 'criado_em', default: () => 'CURRENT_TIMESTAMP' })
  criado_em: Date;

  @Column({ type: 'timestamp', name: 'atualizado_em', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  atualizado_em: Date;

  @Column({ type: 'timestamp', name: 'deleted_at', nullable: true })
  deleted_at: Date | null;

  @ManyToMany(() => Usuario, (usuario) => usuario.papeis)
  usuarios: Usuario[];

  @ManyToMany(() => Permissao, { eager: true })
  @JoinTable({
    name: 'papel_permissao',
    joinColumn: { name: 'idpapel', referencedColumnName: 'idpapel' },
    inverseJoinColumn: { name: 'idpermissao', referencedColumnName: 'idpermissao' },
  })
  permissoes: Permissao[];
}
