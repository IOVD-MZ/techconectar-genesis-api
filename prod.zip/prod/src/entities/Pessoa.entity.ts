import { Entity, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, JoinColumn } from 'typeorm';
import { Usuario } from './Usuario.entity';
import { Estabelecimentos } from './Estabelecimentos.entity';
import { EstafetasPerfil } from './EstafetasPerfil.entity';
import { EnderecosCliente } from './EnderecosCliente.entity';
import { Pedidos } from './Pedidos.entity';
import { Produtos } from './Produtos.entity';
import { Carrinho } from './Carrinho.entity';
import { Entregas } from './Entregas.entity';
import { PessoaAnexo } from './PessoaAnexo.entity';

@Entity('pessoa')
export class Pessoa {
  @PrimaryGeneratedColumn()
  idpessoa: number;

  @Column({ type: 'int', name: 'idusuario', nullable: true })
  idusuario: number | null;

  @Column({ type: 'varchar', length: 255, name: 'nome_completo' })
  nome_completo: string;

  @Column({ type: 'varchar', length: 50, name: 'alcunha', nullable: true })
  alcunha: string | null;

  @Column({ type: 'varchar', length: 255, name: 'slogan', nullable: true })
  slogan: string | null;

  @Column({ type: 'tinyint', name: 'selo_verificacao', default: 0 })
  selo_verificacao: boolean;

  @Column({ type: 'decimal', name: 'limite_credito', precision: 10, scale: 2, default: 0.00 })
  limites: string;

  @Column({ type: 'varchar', length: 255, name: 'endereco_fisico', nullable: true })
  endereco_fisico: string | null;

  @Column({ type: 'varchar', length: 255, name: 'ponto_referencia', nullable: true })
  ponto_referencia: string | null;

  @Column({
    type: 'enum',
    name: 'tipo_pessoa',
    enum: ['CLIENTE', 'FORNECEDOR', 'ESTAFETA', 'ADMIN', 'SISTEMA'],
    default: 'CLIENTE',
  })
  tipo_pessoa: string;

  @Column({ type: 'timestamp', name: 'data_criacao', default: () => 'CURRENT_TIMESTAMP' })
  data_criacao: Date;

  @Column({ type: 'timestamp', name: 'data_modificacao', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  data_modificacao: Date;

  @OneToOne(() => Usuario, (usuario) => usuario.pessoa)
  @JoinColumn({ name: 'idusuario' })
  usuario: Usuario;

  @OneToOne(() => Estabelecimentos, (est) => est.pessoa)
  estabelecimento: Estabelecimentos;

  @OneToOne(() => EstafetasPerfil, (est) => est.pessoa)
  estafetaPerfil: EstafetasPerfil;

  @OneToMany(() => EnderecosCliente, (end) => end.cliente)
  enderecos: EnderecosCliente[];

  @OneToMany(() => Pedidos, (ped) => ped.cliente)
  pedidos: Pedidos[];

  @OneToMany(() => Produtos, (prod) => prod.fornecedor)
  produtos: Produtos[];

  @OneToMany(() => Carrinho, (carrinho) => carrinho.usuario)
  carrinhos: Carrinho[];

  @OneToMany(() => Entregas, (entrega) => entrega.estafeta)
  entregas: Entregas[];

  @OneToMany(() => PessoaAnexo, (pa) => pa.pessoa)
  anexos: PessoaAnexo[];
}
