import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Pedidos } from './Pedidos.entity';
import { SubPedidos } from './SubPedidos.entity';
import { Produtos } from './Produtos.entity';

@Entity('pedido_itens')
export class PedidoItens {
  @PrimaryGeneratedColumn()
  iditem: number;

  @Column({ type: 'int', name: 'pedido_id' })
  pedido_id: number;

  @Column({ type: 'int', name: 'sub_pedido_id', nullable: true })
  sub_pedido_id: number | null;

  @Column({ type: 'int', name: 'produto_id' })
  produto_id: number;

  @Column({ type: 'varchar', length: 255, name: 'nome_produto_snapshot' })
  nome_produto_snapshot: string;

  @Column({ type: 'int', name: 'quantidade' })
  quantidade: number;

  @Column({ type: 'decimal', name: 'preco_unitario_historico', precision: 10, scale: 2 })
  preco_unitario_historico: string;

  @Column({ type: 'decimal', name: 'subtotal', precision: 10, scale: 2, generatedType: 'STORED', asExpression: 'quantidade * preco_unitario_historico' })
  subtotal: string;

  @ManyToOne(() => Pedidos, (pedido) => pedido.pedidoItens)
  @JoinColumn({ name: 'pedido_id' })
  pedido: Pedidos;

  @ManyToOne(() => SubPedidos, (sub) => sub.itens)
  @JoinColumn({ name: 'sub_pedido_id' })
  subPedido: SubPedidos;

  @ManyToOne(() => Produtos, (prod) => prod.pedidoItens)
  @JoinColumn({ name: 'produto_id' })
  produto: Produtos;
}
