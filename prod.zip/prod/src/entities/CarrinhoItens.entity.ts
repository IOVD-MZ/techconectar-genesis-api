import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { Carrinho } from './Carrinho.entity';
import { Produtos } from './Produtos.entity';

@Entity('carrinho_itens')
export class CarrinhoItens {
  @PrimaryGeneratedColumn({ name: 'id_item' })
  id_item: number;

  @Column({ type: 'int', name: 'carrinho_id' })
  carrinho_id: number;

  @Column({ type: 'int', name: 'produto_id' })
  produto_id: number;

  @Column({ type: 'int', name: 'quantidade', default: 1 })
  quantidade: number;

  @Column({
    type: 'decimal',
    name: 'custo_unitario',
    precision: 10,
    scale: 2,
  })
  custo_unitario: string;

  @Column({
    type: 'decimal',
    name: 'produto_peso',
    precision: 8,
    scale: 3,
    nullable: true,
  })
  produto_peso: string | null;

  @CreateDateColumn({ name: 'data_criacao' })
  data_criacao: Date;

  @ManyToOne(() => Carrinho, (carrinho) => carrinho.itens, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'carrinho_id', referencedColumnName: 'id_carrinho' })
  carrinho: Carrinho;

  @ManyToOne(() => Produtos, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'produto_id', referencedColumnName: 'id_produto' })
  produto: Produtos;
}
