import { Entity, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToMany, JoinTable } from 'typeorm';
import { Pessoa } from './Pessoa.entity';
import { AuditoriaLog } from './AuditoriaLog.entity';
import { Dispositivos } from './Dispositivos.entity';
import { Papel } from './Papel.entity';

@Entity('usuarios')
export class Usuario {
  @PrimaryGeneratedColumn()
  idusuario: number;

  @Column({ type: 'varchar', length: 150, unique: true })
  email: string;

  @Column({ type: 'varchar', length: 255, name: 'password_hash' })
  password_hash: string;

  @Column({ type: 'tinyint', name: 'is_ativo', default: 1 })
  is_ativo: boolean;

  @Column({ type: 'timestamp', name: 'ultimo_login', nullable: true })
  ultimo_login: Date | null;

  @Column({ type: 'timestamp', name: 'criado_em', default: () => 'CURRENT_TIMESTAMP' })
  criado_em: Date;

  @OneToOne(() => Pessoa, (pessoa) => pessoa.usuario)
  pessoa: Pessoa;

  @OneToMany(() => AuditoriaLog, (log) => log.usuario)
  auditoriaLogs: AuditoriaLog[];

  @OneToMany(() => Dispositivos, (disp) => disp.usuario)
  dispositivos: Dispositivos[];

  @ManyToMany(() => Papel, (papel) => papel.usuarios, { eager: true })
  @JoinTable({
    name: 'usuario_papel',
    joinColumn: { name: 'idusuario', referencedColumnName: 'idusuario' },
    inverseJoinColumn: { name: 'idpapel', referencedColumnName: 'idpapel' },
  })
  papeis: Papel[];
}
