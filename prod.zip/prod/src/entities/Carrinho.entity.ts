import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  OneToMany,
  CreateDateColumn,
} from 'typeorm';
import { Pessoa } from './Pessoa.entity';
import { CarrinhoItens } from './CarrinhoItens.entity';

@Entity('carrinho')
export class Carrinho {
  @PrimaryGeneratedColumn({ name: 'id_carrinho' })
  id_carrinho: number;

  @Column({ type: 'int', name: 'usuario_id' })
  usuario_id: number;

  @Column({
    type: 'enum',
    name: 'estado',
    enum: ['ABERTO', 'FINALIZADO', 'ABANDONADO'],
    default: 'ABERTO',
  })
  estado: string;

  @CreateDateColumn({ name: 'data_criacao' })
  data_criacao: Date;

  @ManyToOne(() => Pessoa, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'usuario_id', referencedColumnName: 'idpessoa' })
  usuario: Pessoa;

  @OneToMany(() => CarrinhoItens, (item) => item.carrinho)
  itens: CarrinhoItens[];
}
