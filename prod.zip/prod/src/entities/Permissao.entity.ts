import { Entity, PrimaryGeneratedColumn, Column, ManyToMany } from 'typeorm';
import { Papel } from './Papel.entity';

@Entity('permissao')
export class Permissao {
  @PrimaryGeneratedColumn()
  idpermissao: number;

  @Column({ type: 'varchar', length: 80, name: 'chave' })
  chave: string;

  @Column({ type: 'varchar', length: 50, name: 'modulo' })
  modulo: string;

  @Column({ type: 'varchar', length: 255, name: 'descricao', nullable: true })
  descricao: string | null;

  @Column({ type: 'timestamp', name: 'criado_em', default: () => 'CURRENT_TIMESTAMP' })
  criado_em: Date;

  @ManyToMany(() => Papel, (papel) => papel.permissoes)
  papeis: Papel[];
}
