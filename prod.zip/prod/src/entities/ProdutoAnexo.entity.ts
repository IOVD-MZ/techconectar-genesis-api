import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Produtos } from './Produtos.entity';
import { Anexo } from './Anexo.entity';

@Entity('produto_anexo')
export class ProdutoAnexo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int', name: 'produto_id' })
  produto_id: number;

  @Column({ type: 'int', name: 'anexo_id' })
  anexo_id: number;

  @Column({
    type: 'enum',
    name: 'tipo',
    enum: ['capa', 'lateral_esquerda', 'lateral_direita', 'cima', 'baixo', 'traseira', 'frontal', 'status'],
    default: 'capa',
  })
  tipo: string;

  @Column({ type: 'int', name: 'ordem', default: 0 })
  ordem: number;

  @CreateDateColumn({ name: 'criado_em' })
  criado_em: Date;

  @UpdateDateColumn({ name: 'atualizado_em' })
  atualizado_em: Date;

  @ManyToOne(() => Produtos, (produto) => produto.anexos)
  @JoinColumn({ name: 'produto_id' })
  produto: Produtos;

  @ManyToOne(() => Anexo, (anexo) => anexo.produtos)
  @JoinColumn({ name: 'anexo_id' })
  anexo: Anexo;
}
