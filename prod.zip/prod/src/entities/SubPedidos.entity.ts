import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Pedidos } from './Pedidos.entity';
import { Pessoa } from './Pessoa.entity';
import { PedidoItens } from './PedidoItens.entity';

@Entity('sub_pedidos')
export class SubPedidos {
  @PrimaryGeneratedColumn()
  id_sub_pedido: number;

  @Column({ type: 'int', name: 'pedido_pai_id' })
  pedido_pai_id: number;

  @Column({ type: 'int', name: 'fornecedor_id', nullable: true })
  fornecedor_id: number | null;

  @Column({ type: 'decimal', name: 'subtotal_produtos', precision: 10, scale: 2 })
  subtotal_produtos: string;

  @Column({ type: 'decimal', name: 'taxa_entrega_loja', precision: 10, scale: 2, default: 0.00 })
  taxa_entrega_loja: string;

  @Column({
    type: 'enum',
    name: 'status_sub_pedido',
    enum: ['PENDENTE', 'ACEITO_LOJA', 'EM_PREPARACAO', 'PRONTO_PARA_RECOLHA', 'ENTREGUE_AO_ESTAFETA', 'CANCELADO'],
    default: 'PENDENTE',
  })
  status_sub_pedido: string;

  @Column({ type: 'timestamp', name: 'criado_em', default: () => 'CURRENT_TIMESTAMP' })
  criado_em: Date;

  @ManyToOne(() => Pedidos, (pedido) => pedido.subPedidos)
  @JoinColumn({ name: 'pedido_pai_id' })
  pedidoPai: Pedidos;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'fornecedor_id' })
  fornecedor: Pessoa;

  @OneToMany(() => PedidoItens, (item) => item.subPedido)
  itens: PedidoItens[];
}
