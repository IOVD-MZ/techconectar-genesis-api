import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Usuario } from './Usuario.entity';

@Entity('auditoria_log')
export class AuditoriaLog {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int', name: 'idusuario', nullable: true })
  idusuario: number | null;

  @Column({ type: 'varchar', length: 100, name: 'acao' })
  acao: string;

  @Column({ type: 'varchar', length: 100, name: 'entidade' })
  entidade: string;

  @Column({ type: 'varchar', length: 50, name: 'entidade_id', nullable: true })
  entidade_id: string | null;

  @Column({ type: 'json', name: 'dados_anteriores', nullable: true })
  dados_anteriores: any;

  @Column({ type: 'json', name: 'dados_novos', nullable: true })
  dados_novos: any;

  @Column({ type: 'varchar', length: 45, name: 'endereco_ip', nullable: true })
  endereco_ip: string | null;

  @Column({ type: 'varchar', length: 255, name: 'user_agent', nullable: true })
  user_agent: string | null;

  @Column({ type: 'timestamp', name: 'criado_em', default: () => 'CURRENT_TIMESTAMP' })
  criado_em: Date;

  @ManyToOne(() => Usuario, (usuario) => usuario.auditoriaLogs)
  @JoinColumn({ name: 'idusuario' })
  usuario: Usuario;
}
