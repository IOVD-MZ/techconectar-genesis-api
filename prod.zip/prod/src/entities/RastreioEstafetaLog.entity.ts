import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Entregas } from './Entregas.entity';
import { Pessoa } from './Pessoa.entity';

@Entity('rastreio_estafeta_log')
export class RastreioEstafetaLog {
  @PrimaryGeneratedColumn()
  id_log: number;

  @Column({ type: 'int', name: 'entrega_id' })
  entrega_id: number;

  @Column({ type: 'int', name: 'estafeta_id' })
  estafeta_id: number;

  @Column({ type: 'decimal', name: 'latitude', precision: 10, scale: 8 })
  latitude: number;

  @Column({ type: 'decimal', name: 'longitude', precision: 11, scale: 8 })
  longitude: number;

  @Column({ type: 'timestamp', name: 'registado_em', default: () => 'CURRENT_TIMESTAMP' })
  registado_em: Date;

  @ManyToOne(() => Entregas)
  @JoinColumn({ name: 'entrega_id' })
  entrega: Entregas;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'estafeta_id' })
  estafeta: Pessoa;
}
