import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { Pedidos } from './Pedidos.entity';
import { Pessoa } from './Pessoa.entity';

@Entity('mensagens_chat')
export class MensagensChat {
  @PrimaryGeneratedColumn()
  id_mensagem: number;

  @Column({ type: 'int', name: 'pedido_id' })
  pedido_id: number;

  @Column({ type: 'int', name: 'remetente_id' })
  remetente_id: number;

  @Column({
    type: 'enum',
    name: 'tipo_remetente',
    enum: ['CLIENTE', 'ESTAFETA', 'FORNECEDOR', 'SISTEMA'],
    default: 'CLIENTE',
  })
  tipo_remetente: string;

  @Column({ type: 'text', name: 'mensagem' })
  mensagem: string;

  @Column({ type: 'tinyint', name: 'lida', default: 0 })
  lida: boolean;

  @CreateDateColumn({ name: 'data_envio' })
  data_envio: Date;

  @ManyToOne(() => Pedidos, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'pedido_id' })
  pedido: Pedidos;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'remetente_id' })
  remetente: Pessoa;
}
