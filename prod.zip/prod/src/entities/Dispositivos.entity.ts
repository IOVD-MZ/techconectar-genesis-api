import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { Usuario } from './Usuario.entity';

@Entity('dispositivos')
export class Dispositivos {
  @PrimaryGeneratedColumn()
  id_dispositivo: number;

  @Column({ type: 'int', name: 'idusuario' })
  idusuario: number;

  @Column({
    type: 'varchar',
    length: 255,
    name: 'token_notificacao',
    unique: true,
  })
  token_notificacao: string;

  @Column({
    type: 'enum',
    name: 'tipo',
    enum: ['WEB', 'ANDROID', 'IOS'],
    default: 'WEB',
  })
  tipo: string;

  // CORREÇÃO: remover 'width' e usar objeto com type
  @Column({ type: 'tinyint', name: 'ativo', default: 1 })
  ativo: boolean;

  @Column({
    type: 'timestamp',
    name: 'data_registo',
    default: () => 'CURRENT_TIMESTAMP',
  })
  data_registo: Date;

  @Column({
    type: 'timestamp',
    name: 'data_atualizacao',
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  data_atualizacao: Date;

  @ManyToOne(() => Usuario, (usuario) => usuario.dispositivos)
  @JoinColumn({ name: 'idusuario' })
  usuario: Usuario;
}
