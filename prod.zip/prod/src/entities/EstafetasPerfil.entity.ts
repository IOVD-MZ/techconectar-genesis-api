import { Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn } from 'typeorm';
import { Pessoa } from './Pessoa.entity';

@Entity('estafetas_perfil')
export class EstafetasPerfil {
  @PrimaryGeneratedColumn()
  id_estafeta: number;

  @Column({ type: 'int', name: 'pessoa_id' })
  pessoa_id: number;

  @Column({
    type: 'enum',
    name: 'tipo_veiculo',
    enum: ['MOTO', 'BICICLETA', 'CARRO', 'A_PE'],
    default: 'MOTO',
  })
  tipo_veiculo: string;

  @Column({ type: 'varchar', length: 20, name: 'matricula_veiculo', nullable: true })
  matricula_veiculo: string | null;

  @Column({ type: 'varchar', length: 50, name: 'numero_carta_conducao', nullable: true })
  numero_carta_conducao: string | null;

  @Column({
    type: 'enum',
    name: 'status_operacional',
    enum: ['DISPONIVEL', 'EM_ENTREGA', 'OFFLINE'],
    default: 'OFFLINE',
  })
  status_operacional: string;

  @Column({ type: 'timestamp', name: 'criado_em', default: () => 'CURRENT_TIMESTAMP' })
  criado_em: Date;

  @Column({ type: 'timestamp', name: 'atualizado_em', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  atualizado_em: Date;

  @OneToOne(() => Pessoa, (pessoa) => pessoa.estafetaPerfil)
  @JoinColumn({ name: 'pessoa_id' })
  pessoa: Pessoa;
}
