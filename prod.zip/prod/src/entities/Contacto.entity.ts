import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Pessoa } from './Pessoa.entity';

@Entity('contacto')
export class Contacto {
  @PrimaryGeneratedColumn()
  idcontacto: number;

  @Column({ type: 'int', name: 'idpessoa' })
  idpessoa: number;

  @Column({
    type: 'enum',
    name: 'tipo_contacto',
    enum: ['TELEFONE', 'EMAIL', 'WHATSAPP'],
  })
  tipo_contacto: string;

  @Column({ type: 'varchar', length: 255, name: 'descricao' })
  descricao: string;

  @CreateDateColumn({ name: 'data_criacao' })
  data_criacao: Date;

  @UpdateDateColumn({ name: 'data_modificacao' })
  data_modificacao: Date;

  @ManyToOne(() => Pessoa, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'idpessoa' })
  pessoa: Pessoa;
}
