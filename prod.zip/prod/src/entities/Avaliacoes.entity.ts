import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { Pedidos } from './Pedidos.entity';
import { Pessoa } from './Pessoa.entity';
import { Estabelecimentos } from './Estabelecimentos.entity';
import { Produtos } from './Produtos.entity';

@Entity('avaliacoes')
export class Avaliacoes {
  @PrimaryGeneratedColumn()
  id_avaliacao: number;

  @Column({ type: 'int', name: 'pedido_id' })
  pedido_id: number;

  @Column({ type: 'int', name: 'cliente_id' })
  cliente_id: number;

  @Column({ type: 'int', name: 'estabelecimento_id', nullable: true })
  estabelecimento_id: number | null;

  @Column({ type: 'int', name: 'produto_id', nullable: true })
  produto_id: number | null;

  @Column({ type: 'int', name: 'estafeta_id', nullable: true })
  estafeta_id: number | null;

  @Column({ type: 'tinyint', name: 'classificacao' })
  classificacao: number;

  @Column({ type: 'text', name: 'comentario', nullable: true })
  comentario: string | null;

  @CreateDateColumn({ name: 'criado_em' })
  criado_em: Date;

  @ManyToOne(() => Pedidos)
  @JoinColumn({ name: 'pedido_id' })
  pedido: Pedidos;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'cliente_id' })
  cliente: Pessoa;

  @ManyToOne(() => Estabelecimentos)
  @JoinColumn({ name: 'estabelecimento_id' })
  estabelecimento: Estabelecimentos;

  @ManyToOne(() => Produtos)
  @JoinColumn({ name: 'produto_id' })
  produto: Produtos;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'estafeta_id' })
  estafeta: Pessoa;
}
