import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
  OneToOne,
} from 'typeorm';
import { Pessoa } from './Pessoa.entity';
import { Produtos } from './Produtos.entity';
import { Categorias } from './Categorias.entity';

@Entity('requisicao_especial')
export class RequisicaoEspecial {
  @PrimaryGeneratedColumn()
  id_requisicao: number;

  @Column({ type: 'int', name: 'cliente_id' })
  cliente_id: number;

  @Column({ type: 'int', name: 'fornecedor_id', nullable: true })
  fornecedor_id: number | null;

  @Column({ type: 'varchar', length: 255, name: 'designacao' })
  designacao: string;

  @Column({ type: 'text', name: 'especificacoes' })
  especificacoes: string;

  @Column({ type: 'int', name: 'quantidade', default: 1 })
  quantidade: number;

  @Column({ type: 'varchar', length: 20, name: 'contacto_whatsapp' })
  contacto_whatsapp: string;

  @Column({ type: 'decimal', name: 'latitude', precision: 10, scale: 8, nullable: true })
  latitude: string | null;

  @Column({ type: 'decimal', name: 'longitude', precision: 11, scale: 8, nullable: true })
  longitude: string | null;

  @Column({ type: 'varchar', length: 500, name: 'imagem_url', nullable: true })
  imagem_url: string | null;

  @Column({ type: 'text', name: 'observacoes', nullable: true })
  observacoes: string | null;

  @Column({ type: 'decimal', name: 'preco_sugerido', precision: 10, scale: 2, nullable: true })
  preco_sugerido: string | null;

  @Column({ type: 'int', name: 'categoria_sugerida_id', nullable: true })
  categoria_sugerida_id: number | null;

  @Column({ type: 'decimal', name: 'preco_aprovado', precision: 10, scale: 2, nullable: true })
  preco_aprovado: string | null;

  @Column({ type: 'int', name: 'categoria_aprovada_id', nullable: true })
  categoria_aprovada_id: number | null;

  @Column({ type: 'int', name: 'aprovado_por_id', nullable: true })
  aprovado_por_id: number | null;

  @Column({ type: 'timestamp', name: 'data_aprovacao', nullable: true })
  data_aprovacao: Date | null;

  @Column({ type: 'int', name: 'ultima_atualizacao_por_id', nullable: true })
  ultima_atualizacao_por_id: number | null;

  @Column({
    type: 'enum',
    name: 'status',
    enum: ['PENDENTE', 'EM_ANALISE', 'APROVADO', 'REJEITADO', 'CANCELADO'],
    default: 'PENDENTE',
  })
  status: string;

  @Column({ type: 'text', name: 'motivo_rejeicao', nullable: true })
  motivo_rejeicao: string | null;

  @Column({ type: 'int', name: 'produto_id', nullable: true })
  produto_id: number | null;

  @CreateDateColumn({ name: 'criado_em' })
  criado_em: Date;

  @UpdateDateColumn({ name: 'atualizado_em' })
  atualizado_em: Date;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'cliente_id' })
  cliente: Pessoa;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'fornecedor_id' })
  fornecedor: Pessoa;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'aprovado_por_id' })
  aprovado_por: Pessoa;

  @ManyToOne(() => Categorias)
  @JoinColumn({ name: 'categoria_sugerida_id' })
  categoriaSugerida: Categorias;

  @ManyToOne(() => Categorias)
  @JoinColumn({ name: 'categoria_aprovada_id' })
  categoriaAprovada: Categorias;

  @OneToOne(() => Produtos)
  @JoinColumn({ name: 'produto_id' })
  produto: Produtos;
}
