import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Pedidos } from './Pedidos.entity';

@Entity('pagamentos')
export class Pagamentos {
  @PrimaryGeneratedColumn()
  id_pagamento: number;

  @Column({ type: 'int', name: 'pedido_id' })
  pedido_id: number;

  @Column({
    type: 'enum',
    name: 'metodo_pagamento',
    enum: ['EMOLA', 'MPESA', 'CARTAO', 'NUMERARIO_ENTREGA', 'POS_ENTREGA'],
  })
  metodo_pagamento: string;

  @Column({ type: 'decimal', name: 'valor', precision: 10, scale: 2 })
  valor: string;

  @Column({ type: 'varchar', length: 5, name: 'moeda', default: 'MZN' })
  moeda: string;

  @Column({
    type: 'enum',
    name: 'status_pagamento',
    enum: ['PENDENTE', 'PROCESSANDO', 'PAGO', 'FALHADO', 'CANCELADO', 'REEMBOLSADO'],
    default: 'PENDENTE',
  })
  status_pagamento: string;

  @Column({ type: 'varchar', length: 100, name: 'referencia_transacao', nullable: true })
  referencia_transacao: string | null;

  @Column({ type: 'varchar', length: 100, name: 'referencia_externa', nullable: true })
  referencia_externa: string | null;

  @Column({ type: 'varchar', length: 30, name: 'numero_conta_pagador', nullable: true })
  numero_conta_pagador: string | null;

  @Column({ type: 'json', name: 'detalhes_resposta', nullable: true })
  detalhes_resposta: any;

  @Column({ type: 'timestamp', name: 'criado_em', default: () => 'CURRENT_TIMESTAMP' })
  criado_em: Date;

  @Column({ type: 'timestamp', name: 'atualizado_em', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  atualizado_em: Date;

  @ManyToOne(() => Pedidos, (pedido) => pedido.pagamentos)
  @JoinColumn({ name: 'pedido_id' })
  pedido: Pedidos;
}
