import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
} from 'typeorm';
import { Pessoa } from './Pessoa.entity';
import { PessoaAnexo } from './PessoaAnexo.entity';
import { ProdutoAnexo } from './ProdutoAnexo.entity';

@Entity('anexo')
export class Anexo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int', name: 'idpessoa' })
  idpessoa: number;

  @Column({ type: 'varchar', length: 255, name: 'tipo_anexo', nullable: true })
  tipo_anexo: string | null;

  @Column({ type: 'varchar', length: 255, name: 'nome_ficheiro_original' })
  nome_ficheiro_original: string;

  @Column({ type: 'varchar', length: 500, name: 'caminho_armazenamento' })
  caminho_armazenamento: string;

  @Column({ type: 'bigint', name: 'tamanho_bytes' })
  tamanho_bytes: number;

  @Column({ type: 'char', length: 64, name: 'hash_sha256' })
  hash_sha256: string;

  @Column({ type: 'varchar', length: 100, name: 'mime_type', nullable: true })
  mime_type: string | null;

  @CreateDateColumn({ name: 'carregado_em' })
  carregado_em: Date;

  @UpdateDateColumn({ name: 'atualizado_em' })
  atualizado_em: Date;

  @Column({ type: 'tinyint', name: 'is_deleted', default: 0 })
  is_deleted: boolean;

  @Column({ type: 'timestamp', name: 'deleted_at', nullable: true })
  deleted_at: Date | null;

  @ManyToOne(() => Pessoa)
  @JoinColumn({ name: 'idpessoa' })
  pessoa: Pessoa;

  @OneToMany(() => PessoaAnexo, (pa) => pa.anexo)
  pessoas: PessoaAnexo[];

  @OneToMany(() => ProdutoAnexo, (pa) => pa.anexo)
  produtos: ProdutoAnexo[];
}
