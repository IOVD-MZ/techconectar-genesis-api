import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Pessoa } from '../entities/Pessoa.entity';

@Injectable()
export class PessoasService {
  constructor(
    @InjectRepository(Pessoa)
    private pessoaRepo: Repository<Pessoa>,
  ) {}

  async meuPerfil(idpessoa: number) {
    if (!idpessoa || isNaN(idpessoa)) {
      throw new BadRequestException('Pessoa inválida');
    }

    const pessoa = await this.pessoaRepo.findOne({
      where: { idpessoa },
      select: {
        idpessoa: true,
        nome_completo: true,
        alcunha: true,
        slogan: true,
        selo_verificacao: true,
        limites: true,
        endereco_fisico: true,
        ponto_referencia: true,
        tipo_pessoa: true,
        data_criacao: true,
        data_modificacao: true,
      },
    });

    if (!pessoa) {
      throw new NotFoundException('Pessoa não encontrada');
    }

    return {
      ...pessoa,
      limite_credito: pessoa.limites,
    };
  }
}
