import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Pessoa } from '../entities/Pessoa.entity';

@Injectable()
export class PessoasService {
  constructor(
    @InjectRepository(Pessoa)
    private pessoaRepo: Repository<Pessoa>,
  ) {}

  async meuPerfil(idpessoa: number) {
    if (!idpessoa || isNaN(idpessoa)) {
      throw new BadRequestException('Pessoa inválida');
    }

    const pessoa = await this.pessoaRepo.findOne({
      where: { idpessoa },
      select: {
        idpessoa: true,
        nome_completo: true,
        alcunha: true,
        slogan: true,
        selo_verificacao: true,
        limites: true,
        endereco_fisico: true,
        ponto_referencia: true,
        tipo_pessoa: true,
        data_criacao: true,
        data_modificacao: true,
      },
    });

    if (!pessoa) {
      throw new NotFoundException('Pessoa não encontrada');
    }

    return {
      ...pessoa,
      limite_credito: pessoa.limites,
    };
  }

  async atualizar(idpessoa: number, dto: any) {
    if (!idpessoa || isNaN(idpessoa)) {
      throw new BadRequestException('Pessoa inválida');
    }
    const pessoa = await this.pessoaRepo.findOne({ where: { idpessoa } });
    if (!pessoa) throw new NotFoundException('Pessoa não encontrada');

    const updateData: any = {};
    if (dto.nome_completo !== undefined) updateData.nome_completo = dto.nome_completo;
    if (dto.alcunha !== undefined) updateData.alcunha = dto.alcunha;
    if (dto.slogan !== undefined) updateData.slogan = dto.slogan;
    if (dto.endereco_fisico !== undefined) updateData.endereco_fisico = dto.endereco_fisico;
    if (dto.ponto_referencia !== undefined) updateData.ponto_referencia = dto.ponto_referencia;

    if (Object.keys(updateData).length > 0) {
      await this.pessoaRepo.update(idpessoa, updateData);
    }

    if (dto.latitude && dto.longitude) {
      try {
        const lat = parseFloat(dto.latitude);
        const lon = parseFloat(dto.longitude);
        if (!isNaN(lat) && !isNaN(lon)) {
          const existing = await this.pessoaRepo.manager.query(
            `SELECT g.idgeolocalizacoes FROM geolocalizacoes_pessoa gp
             INNER JOIN geolocalizacoes g ON g.idgeolocalizacoes = gp.idgeolocalizacoes
             WHERE gp.idpessoa = ? LIMIT 1`, [idpessoa],
          );
          if (existing && existing.length > 0) {
            await this.pessoaRepo.manager.query(
              `UPDATE geolocalizacoes SET localizacao = ST_GeomFromText(?, 4326) WHERE idgeolocalizacoes = ?`,
              [`POINT(${lon} ${lat})`, existing[0].idgeolocalizacoes],
            );
          } else {
            const res = await this.pessoaRepo.manager.query(
              `INSERT INTO geolocalizacoes (localizacao) VALUES (ST_GeomFromText(?, 4326))`,
              [`POINT(${lon} ${lat})`],
            );
            await this.pessoaRepo.manager.query(
              `INSERT INTO geolocalizacoes_pessoa (idpessoa, idgeolocalizacoes) VALUES (?, ?)`,
              [idpessoa, res.insertId],
            );
          }
        }
      } catch (err) { /* opcional */ }
    }
    return this.meuPerfil(idpessoa);
  }

}
