import {
  Controller, Get, Patch, Body, Param, ParseIntPipe, UseGuards, Request, ForbiddenException,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { PessoasService } from './pessoas.service';
import { UpdatePessoaDto } from './dto/update-pessoa.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('pessoas')
@Controller('pessoas')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT-auth')
export class PessoasController {
  constructor(private readonly pessoasService: PessoasService) {}

  @Get('meu-perfil')
  @ApiOperation({ summary: 'Perfil completo da pessoa autenticada' })
  async meuPerfil(@Request() req) {
    return this.pessoasService.meuPerfil(req.user.idpessoa);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar dados da própria pessoa' })
  async atualizar(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdatePessoaDto,
    @Request() req,
  ) {
    const papeis = req.user.papeis || [];
    const isAdmin = papeis.includes('ADMIN');
    const isProprio = Number(req.user.idpessoa) === Number(id);
    if (!isAdmin && !isProprio) {
      throw new ForbiddenException('Sem permissão para editar outra pessoa');
    }
    return this.pessoasService.atualizar(id, dto);
  }
}
