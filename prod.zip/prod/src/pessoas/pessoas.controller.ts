import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { PessoasService } from './pessoas.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('pessoas')
@Controller('pessoas')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT-auth')
export class PessoasController {
  constructor(private readonly pessoasService: PessoasService) {}

  @Get('meu-perfil')
  @ApiOperation({ summary: 'Perfil completo da pessoa autenticada' })
  @ApiResponse({ status: 200, description: 'Perfil com limite de crédito' })
  @ApiResponse({ status: 404, description: 'Pessoa não encontrada' })
  async meuPerfil(@Request() req) {
    return this.pessoasService.meuPerfil(req.user.idpessoa);
  }
}
