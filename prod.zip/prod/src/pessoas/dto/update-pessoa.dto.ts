import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdatePessoaDto {
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(255) nome_completo?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(50) alcunha?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(255) slogan?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(255) endereco_fisico?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(255) ponto_referencia?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() latitude?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() longitude?: string;
}
