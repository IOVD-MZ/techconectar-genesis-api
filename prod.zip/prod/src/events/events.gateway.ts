import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';

@WebSocketGateway({
  cors: { origin: '*' },
  namespace: 'events',
})
export class EventsGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;
  private logger = new Logger(EventsGateway.name);
  private userSockets = new Map<number, string>();

  constructor(
    private jwtService: JwtService,
    private config: ConfigService,
  ) {}

  handleConnection(client: Socket) {
    try {
      const token = client.handshake.auth.token || client.handshake.query.token;
      if (!token) throw new Error('Token não fornecido');
      const payload = this.jwtService.verify(token, { secret: this.config.get('JWT_SECRET') });
      const userId = payload.sub;
      this.userSockets.set(userId, client.id);
      client.join(`user-${userId}`);
      this.logger.log(`Cliente ${userId} conectado`);
    } catch (err) {
      this.logger.warn(`Conexão rejeitada: ${err.message}`);
      client.disconnect();
    }
  }

  handleDisconnect(client: Socket) {
    for (const [userId, socketId] of this.userSockets.entries()) {
      if (socketId === client.id) {
        this.userSockets.delete(userId);
        break;
      }
    }
  }

  notifyUser(userId: number, event: string, data: any) {
    this.server.to(`user-${userId}`).emit(event, data);
  }

  notifyRoom(room: string, event: string, data: any) {
    this.server.to(room).emit(event, data);
  }

  @SubscribeMessage('subscribe-delivery')
  handleSubscribeDelivery(client: Socket, deliveryId: number) {
    client.join(`delivery-${deliveryId}`);
  }
}
