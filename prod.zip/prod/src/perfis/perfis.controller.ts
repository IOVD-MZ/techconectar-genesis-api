import { Controller, Get, Patch, Body, Param, ParseIntPipe, UseGuards, Request, ForbiddenException } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { PerfisService } from './perfis.service';
import { UpdateCredenciaisDto } from './dto/update-credenciais.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('perfis')
@Controller('perfis')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT-auth')
export class PerfisController {
  constructor(private readonly perfisService: PerfisService) {}

  @Get('me')
  @ApiOperation({ summary: 'Perfil completo do utilizador autenticado' })
  @ApiResponse({ status: 200, description: 'Perfil com pessoa + usuario + papeis' })
  async me(@Request() req) {
    return this.perfisService.meuPerfil(req.user.idpessoa, req.user.idusuario);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar credenciais (email/senha) do próprio utilizador' })
  @ApiBody({ type: UpdateCredenciaisDto })
  async atualizarCredenciais(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateCredenciaisDto,
    @Request() req,
  ) {
    const isAdmin = (req.user.papeis || []).includes('ADMIN');
    const isProprio = Number(req.user.idusuario) === Number(id);
    if (!isAdmin && !isProprio) {
      throw new ForbiddenException('Sem permissão');
    }
    return this.perfisService.atualizarCredenciais(id, dto);
  }

}
