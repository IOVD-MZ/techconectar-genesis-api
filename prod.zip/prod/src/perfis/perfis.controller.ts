import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { PerfisService } from './perfis.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('perfis')
@Controller('perfis')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT-auth')
export class PerfisController {
  constructor(private readonly perfisService: PerfisService) {}

  @Get('me')
  @ApiOperation({ summary: 'Perfil completo do utilizador autenticado' })
  @ApiResponse({ status: 200, description: 'Perfil com pessoa + usuario + papeis' })
  async me(@Request() req) {
    return this.perfisService.meuPerfil(req.user.idpessoa, req.user.idusuario);
  }
}
