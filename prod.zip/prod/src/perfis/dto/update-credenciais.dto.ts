import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString, MinLength, IsEmail, MaxLength } from 'class-validator';

export class UpdateCredenciaisDto {
  @ApiPropertyOptional({ example: 'novo.email@genesis.co.mz' })
  @IsOptional()
  @IsEmail()
  @MaxLength(150)
  email?: string;

  @ApiPropertyOptional({ example: 'novaSenha123' })
  @IsOptional()
  @IsString()
  @MinLength(6)
  password?: string;
}
