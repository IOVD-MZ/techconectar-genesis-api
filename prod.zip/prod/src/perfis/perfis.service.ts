import * as bcrypt from 'bcrypt';
import { Injectable, NotFoundException, BadRequestException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Pessoa } from '../entities/Pessoa.entity';
import { Usuario } from '../entities/Usuario.entity';
import { Estabelecimentos } from '../entities/Estabelecimentos.entity';
import { EstafetasPerfil } from '../entities/EstafetasPerfil.entity';

@Injectable()
export class PerfisService {
  constructor(
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
    @InjectRepository(Usuario) private usuarioRepo: Repository<Usuario>,
    @InjectRepository(Estabelecimentos)
    private estabelecimentoRepo: Repository<Estabelecimentos>,
    @InjectRepository(EstafetasPerfil)
    private estafetaRepo: Repository<EstafetasPerfil>,
  ) {}

  async meuPerfil(idpessoa: number, idusuario: number) {
    if (!idpessoa || !idusuario) {
      throw new NotFoundException('Pessoa/Utilizador inválido');
    }

    const [pessoa, usuario] = await Promise.all([
      this.pessoaRepo.findOne({
        where: { idpessoa },
        select: {
          idpessoa: true,
          nome_completo: true,
          alcunha: true,
          slogan: true,
          selo_verificacao: true,
          limites: true,
          endereco_fisico: true,
          ponto_referencia: true,
          tipo_pessoa: true,
          data_criacao: true,
          data_modificacao: true,
        },
      }),
      this.usuarioRepo.findOne({
        where: { idusuario },
        relations: { papeis: true },
        select: {
          idusuario: true,
          email: true,
          is_ativo: true,
          ultimo_login: true,
          criado_em: true,
          password_hash: false,
        },
      }),
    ]);

    if (!pessoa) throw new NotFoundException('Pessoa não encontrada');

    // Perfil extra por tipo
    let estabelecimento: Estabelecimentos | null = null;
    let estafetaPerfil: EstafetasPerfil | null = null;

    if (pessoa.tipo_pessoa === 'FORNECEDOR') {
      estabelecimento = await this.estabelecimentoRepo.findOne({
        where: { pessoa_id: idpessoa },
      });
    }
    if (pessoa.tipo_pessoa === 'ESTAFETA') {
      estafetaPerfil = await this.estafetaRepo.findOne({
        where: { pessoa_id: idpessoa },
      });
    }

    return {
      idpessoa: pessoa.idpessoa,
      nome_completo: pessoa.nome_completo,
      alcunha: pessoa.alcunha,
      slogan: pessoa.slogan,
      selo_verificacao: pessoa.selo_verificacao,
      limites: pessoa.limites,
      limite_credito: pessoa.limites,
      endereco_fisico: pessoa.endereco_fisico,
      ponto_referencia: pessoa.ponto_referencia,
      tipo_pessoa: pessoa.tipo_pessoa,
      data_criacao: pessoa.data_criacao,
      data_modificacao: pessoa.data_modificacao,
      usuario: usuario
        ? {
            idusuario: usuario.idusuario,
            email: usuario.email,
            is_ativo: usuario.is_ativo,
            ultimo_login: usuario.ultimo_login,
            criado_em: usuario.criado_em,
            papeis: usuario.papeis || [],
          }
        : null,
      estabelecimento,
      estafeta_perfil: estafetaPerfil,
    };
  }

  async atualizarCredenciais(idusuario: number, dto: { email?: string; password?: string }) {
    if (!idusuario || isNaN(idusuario)) {
      throw new BadRequestException('Utilizador inválido');
    }

    const usuario = await this.usuarioRepo.findOne({
      where: { idusuario },
    });
    if (!usuario) throw new NotFoundException('Utilizador não encontrado');

    const updateData: any = {};

    if (dto.email && dto.email !== usuario.email) {
      const existente = await this.usuarioRepo.findOne({
        where: { email: dto.email },
      });
      if (existente && existente.idusuario !== idusuario) {
        throw new ConflictException('Email já registado');
      }
      updateData.email = dto.email;
    }

    if (dto.password) {
      updateData.password_hash = await bcrypt.hash(dto.password, 10);
    }

    if (Object.keys(updateData).length > 0) {
      await this.usuarioRepo.update(idusuario, updateData);
    }

    return {
      idusuario,
      email: updateData.email || usuario.email,
      message: 'Credenciais atualizadas',
    };
  }

}
