import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PerfisService } from './perfis.service';
import { PerfisController } from './perfis.controller';
import { Pessoa } from '../entities/Pessoa.entity';
import { Usuario } from '../entities/Usuario.entity';
import { Estabelecimentos } from '../entities/Estabelecimentos.entity';
import { EstafetasPerfil } from '../entities/EstafetasPerfil.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Pessoa, Usuario, Estabelecimentos, EstafetasPerfil]),
  ],
  controllers: [PerfisController],
  providers: [PerfisService],
})
export class PerfisModule {}
