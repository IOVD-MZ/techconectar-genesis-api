import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Request,
  BadRequestException,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { RequisicoesService } from './requisicoes.service';
import { CreateRequisicaoDto } from './dto/create-requisicao.dto';
import { UpdateRequisicaoDto } from './dto/update-requisicao.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('requisicoes')
@Controller('requisicoes')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class RequisicoesController {
  constructor(private readonly requisicoesService: RequisicoesService) {}

  @Post()
  @Permissions('requisicoes:criar')
  @ApiOperation({ summary: 'Criar requisição especial (gera produto SOB_ENCOMENDA)' })
  @ApiBody({ type: CreateRequisicaoDto })
  @ApiResponse({ status: 201, description: 'Requisição e produto criados' })
  create(@Body() createDto: CreateRequisicaoDto, @Request() req) {
    return this.requisicoesService.create(req.user.idpessoa, createDto);
  }

  @Get()
  @Permissions('requisicoes:visualizar')
  @ApiOperation({ summary: 'Listar requisições (filtrado por papel)' })
  @ApiResponse({ status: 200, description: 'Lista de requisições' })
  findAll(@Request() req) {
    return this.requisicoesService.findAll(req.user);
  }

  @Get(':id')
  @Permissions('requisicoes:visualizar')
  @ApiOperation({ summary: 'Obter detalhes' })
  @ApiResponse({ status: 200, description: 'Detalhes da requisição' })
  findOne(@Param('id') id: string, @Request() req) {
    return this.requisicoesService.findOne(+id, req.user);
  }

  @Patch(':id')
  @Permissions('requisicoes:gerir')
  @ApiOperation({ summary: 'Atualizar requisição (status, fornecedor)' })
  @ApiBody({ type: UpdateRequisicaoDto })
  @ApiResponse({ status: 200, description: 'Requisição atualizada' })
  update(@Param('id') id: string, @Body() updateDto: UpdateRequisicaoDto, @Request() req) {
    const idNumber = Number(id);
    if (isNaN(idNumber) || idNumber <= 0) {
      throw new BadRequestException('ID inválido');
    }
    return this.requisicoesService.update(idNumber, updateDto, req.user);
  }

  @Delete(':id')
  @Permissions('requisicoes:gerir')
  @ApiOperation({ summary: 'Remover requisição (apenas ADMIN)' })
  @ApiResponse({ status: 200, description: 'Requisição removida' })
  remove(@Param('id') id: string, @Request() req) {
    return this.requisicoesService.remove(+id, req.user);
  }
}
