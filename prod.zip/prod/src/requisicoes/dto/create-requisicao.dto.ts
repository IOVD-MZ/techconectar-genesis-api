import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsNumber,
  IsOptional,
  IsUrl,
  IsLatitude,
  IsLongitude,
  Min,
  MaxLength,
  IsPositive,
} from 'class-validator';

export class CreateRequisicaoDto {
  @ApiProperty({ description: 'Designação do produto', example: 'Motor Elétrico 5kW' })
  @IsString()
  @MaxLength(255)
  designacao: string;

  @ApiProperty({ description: 'Especificações técnicas', example: 'Motor trifásico, 380V, 5kW' })
  @IsString()
  especificacoes: string;

  @ApiProperty({ description: 'Quantidade desejada', example: 2 })
  @IsNumber()
  @Min(1)
  quantidade: number;

  @ApiProperty({ description: 'Contacto WhatsApp', example: '+258841234567' })
  @IsString()
  @MaxLength(20)
  contacto_whatsapp: string;

  @ApiPropertyOptional({ description: 'Preço sugerido (opcional)', example: 1500.00 })
  @IsOptional()
  @IsNumber()
  @IsPositive()
  preco_sugerido?: number;

  @ApiPropertyOptional({ description: 'ID da categoria sugerida (opcional)', example: 4 })
  @IsOptional()
  @IsNumber()
  @Min(1)
  categoria_sugerida_id?: number;

  @ApiPropertyOptional({ description: 'Latitude para entrega', example: -15.615100 })
  @IsOptional()
  @IsLatitude()
  latitude?: number;

  @ApiPropertyOptional({ description: 'Longitude para entrega', example: 32.772500 })
  @IsOptional()
  @IsLongitude()
  longitude?: number;

  @ApiPropertyOptional({ description: 'URL da imagem de referência' })
  @IsOptional()
  @IsUrl()
  imagem_url?: string;

  @ApiPropertyOptional({ description: 'Observações adicionais' })
  @IsOptional()
  @IsString()
  observacoes?: string;
}
