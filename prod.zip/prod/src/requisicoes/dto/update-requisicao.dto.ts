import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsString, IsOptional, IsNumber, Min, IsPositive } from 'class-validator';
import { PartialType } from '@nestjs/mapped-types';
import { CreateRequisicaoDto } from './create-requisicao.dto';

export class UpdateRequisicaoDto extends PartialType(CreateRequisicaoDto) {
  @ApiPropertyOptional({ enum: ['PENDENTE', 'EM_ANALISE', 'APROVADO', 'REJEITADO', 'CANCELADO'] })
  @IsOptional()
  @IsEnum(['PENDENTE', 'EM_ANALISE', 'APROVADO', 'REJEITADO', 'CANCELADO'])
  status?: string;

  @ApiPropertyOptional({ description: 'Motivo da rejeição' })
  @IsOptional()
  @IsString()
  motivo_rejeicao?: string;

  @ApiPropertyOptional({ description: 'ID do fornecedor atribuído' })
  @IsOptional()
  @IsNumber()
  fornecedor_id?: number;

  @ApiPropertyOptional({ description: 'Preço aprovado (definido pelo fornecedor/admin)' })
  @IsOptional()
  @IsNumber()
  @IsPositive()
  preco_aprovado?: number;

  @ApiPropertyOptional({ description: 'ID da categoria aprovada' })
  @IsOptional()
  @IsNumber()
  @Min(1)
  categoria_aprovada_id?: number;
}
