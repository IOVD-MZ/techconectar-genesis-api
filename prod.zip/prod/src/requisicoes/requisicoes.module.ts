import { Module } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RequisicoesService } from './requisicoes.service';
import { RequisicoesController } from './requisicoes.controller';
import { RequisicaoEspecial } from '../entities/RequisicaoEspecial.entity';
import { Produtos } from '../entities/Produtos.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Categorias } from '../entities/Categorias.entity';
import { EventsModule } from '../events/events.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([RequisicaoEspecial, Produtos, Pessoa, Categorias]),
    EventsModule,
  ],
  controllers: [RequisicoesController],
  providers: [RequisicoesService],
})
export class RequisicoesModule {}
