import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { RequisicaoEspecial } from '../entities/RequisicaoEspecial.entity';
import { Produtos } from '../entities/Produtos.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Categorias } from '../entities/Categorias.entity';
import { EventsGateway } from '../events/events.gateway';
import { CreateRequisicaoDto } from './dto/create-requisicao.dto';
import { UpdateRequisicaoDto } from './dto/update-requisicao.dto';

@Injectable()
export class RequisicoesService {
  constructor(
    @InjectRepository(RequisicaoEspecial)
    private requisicaoRepo: Repository<RequisicaoEspecial>,
    @InjectRepository(Produtos)
    private produtoRepo: Repository<Produtos>,
    @InjectRepository(Pessoa)
    private pessoaRepo: Repository<Pessoa>,
    @InjectRepository(Categorias)
    private categoriaRepo: Repository<Categorias>,
    private eventsGateway: EventsGateway,
    private dataSource: DataSource,
  ) {}

  async create(clienteId: number, createDto: CreateRequisicaoDto) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Validar cliente (idpessoa com tipo CLIENTE)
      const cliente = await queryRunner.manager.query(
        `SELECT idpessoa, tipo_pessoa FROM pessoa WHERE idpessoa = ? AND tipo_pessoa = 'CLIENTE'`,
        [clienteId],
      );
      if (!cliente || cliente.length === 0) {
        throw new NotFoundException('Cliente não encontrado');
      }

      // Validar categoria sugerida se fornecida
      let categoriaSugerida: Categorias | null = null;
      if (createDto.categoria_sugerida_id) {
        categoriaSugerida = await this.categoriaRepo.findOne({
          where: { id_categoria: createDto.categoria_sugerida_id },
        });
        if (!categoriaSugerida) {
          throw new BadRequestException('Categoria sugerida não encontrada');
        }
      }

      // 1. Criar requisição
      const requisicaoData = {
        cliente_id: clienteId,
        designacao: createDto.designacao,
        especificacoes: createDto.especificacoes,
        quantidade: createDto.quantidade,
        contacto_whatsapp: createDto.contacto_whatsapp,
        latitude: createDto.latitude ? createDto.latitude.toString() : null,
        longitude: createDto.longitude ? createDto.longitude.toString() : null,
        imagem_url: createDto.imagem_url || null,
        observacoes: createDto.observacoes || null,
        preco_sugerido: createDto.preco_sugerido != null ? createDto.preco_sugerido.toString() : null,
        categoria_sugerida_id: createDto.categoria_sugerida_id ?? 1,
        status: 'PENDENTE',
      };
      const requisicao = this.requisicaoRepo.create(requisicaoData);
      const savedRequisicao = await queryRunner.manager.save(requisicao);

      // 2. Criar produto automaticamente com status SOB_ENCOMENDA
      const produtoData: any = {
        nome: createDto.designacao,
        descricao: createDto.especificacoes,
        preco: createDto.preco_sugerido ? createDto.preco_sugerido.toString() : "'0'",
        stock: createDto.quantidade,
        status_produto: 'SOB_ENCOMENDA',
        categoria_id: createDto.categoria_sugerida_id ?? 1,
        requisicao_especial_id: savedRequisicao.id_requisicao,
      };
      const produto = this.produtoRepo.create(produtoData);
      const savedProduto = await queryRunner.manager.save(produto);

      // 3. Atualizar requisição com o id do produto
      if (savedProduto && (savedProduto as any).id_produto) {
        savedRequisicao.produto_id = (savedProduto as any).id_produto;
        await queryRunner.manager.save(savedRequisicao);
      }

      await queryRunner.commitTransaction();

      // Notificar fornecedores (após commit)
      this.eventsGateway.notifyRoom('fornecedores', 'nova-requisicao', {
        requisicaoId: savedRequisicao.id_requisicao,
        designacao: savedRequisicao.designacao,
        cliente: cliente[0].nome_completo || `Cliente #${clienteId}`,
      });

      return this.findOne(savedRequisicao.id_requisicao, { idpessoa: clienteId, papeis: ['CLIENTE'] });

    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  // ... resto do serviço mantido (findAll, findOne, update, remove)
  async findAll(user: any) {
    const papeis = user.papeis || [];

    if (papeis.includes('ADMIN')) {
      return await this.requisicaoRepo.find({
        relations: {
          cliente: true,
          fornecedor: true,
          aprovado_por: true,
          produto: true,
          categoriaSugerida: true,
          categoriaAprovada: true,
        },
        order: { criado_em: 'DESC' },
      });
    }

    if (papeis.includes('FORNECEDOR')) {
      return await this.requisicaoRepo.find({
        where: [
          { status: 'PENDENTE' },
          { status: 'EM_ANALISE' },
          { fornecedor_id: user.idpessoa },
        ],
        relations: {
          cliente: true,
          fornecedor: true,
          aprovado_por: true,
          produto: true,
          categoriaSugerida: true,
          categoriaAprovada: true,
        },
        order: { criado_em: 'DESC' },
      });
    }

    if (papeis.includes('CLIENTE')) {
      return await this.requisicaoRepo.find({
        where: { cliente_id: user.idpessoa },
        relations: {
          cliente: true,
          fornecedor: true,
          aprovado_por: true,
          produto: true,
          categoriaSugerida: true,
          categoriaAprovada: true,
        },
        order: { criado_em: 'DESC' },
      });
    }

    return [];
  }

  async findOne(id: number, user: any) {
    if (isNaN(id) || id <= 0) {
      throw new NotFoundException("Requisição não encontrada");
    }
    const requisicao = await this.requisicaoRepo.findOne({
      where: { id_requisicao: id },
      relations: {
        cliente: true,
        fornecedor: true,
        aprovado_por: true,
        produto: true,
        categoriaSugerida: true,
        categoriaAprovada: true,
      },
    });
    if (!requisicao) throw new NotFoundException('Requisição não encontrada');

    const papeis = user.papeis || [];
    if (papeis.includes('ADMIN')) return requisicao;

    if (papeis.includes('FORNECEDOR')) {
      if (
        ['PENDENTE', 'EM_ANALISE'].includes(requisicao.status) ||
        requisicao.fornecedor_id === user.idpessoa
      ) {
        return requisicao;
      }
      throw new ForbiddenException('Não tem permissão para ver esta requisição');
    }

    if (papeis.includes('CLIENTE')) {
      if (requisicao.cliente_id === user.idpessoa) return requisicao;
      throw new ForbiddenException('Não é o dono desta requisição');
    }

    throw new ForbiddenException('Acesso negado');
  }

  async update(id: number, updateDto: UpdateRequisicaoDto, user: any) {
    if (isNaN(id) || id <= 0) {
      throw new BadRequestException("ID inválido");
    }
    const requisicao = await this.findOne(id, user);
    const papeis = user.papeis || [];

    // Cliente só pode cancelar (status = CANCELADO) se estiver PENDENTE
    if (papeis.includes('CLIENTE')) {
      if (requisicao.cliente_id === user.idpessoa) {
        if (updateDto.status === 'CANCELADO' && requisicao.status === 'PENDENTE') {
          await this.requisicaoRepo.update(id, {
            status: 'CANCELADO',
            motivo_rejeicao: updateDto.motivo_rejeicao || 'Cancelado pelo cliente',
            ultima_atualizacao_por_id: user.idusuario,
          });
          this.eventsGateway.notifyUser(requisicao.cliente_id, 'requisicao-cancelada', {
            requisicaoId: id,
            status: 'CANCELADO',
          });
          return this.findOne(id, user);
        }
        throw new ForbiddenException('Só pode cancelar requisições pendentes');
      }
    }

    // Fornecedor pode analisar, aprovar, rejeitar e atribuir-se
    if (papeis.includes('FORNECEDOR')) {
      if (!['PENDENTE', 'EM_ANALISE'].includes(requisicao.status)) {
        throw new BadRequestException('Esta requisição já foi processada');
      }
      if (updateDto.fornecedor_id && updateDto.fornecedor_id !== user.idpessoa) {
        throw new ForbiddenException('Só pode atribuir a si mesmo');
      }
      const fornecedorId = user.idpessoa;

      let precoAprovado: string | null = requisicao.preco_aprovado;
      if (updateDto.preco_aprovado) {
        precoAprovado = updateDto.preco_aprovado.toString();
      }

      let categoriaAprovadaId: number | null = requisicao.categoria_aprovada_id;
      if (updateDto.categoria_aprovada_id) {
        const categoria = await this.categoriaRepo.findOne({
          where: { id_categoria: updateDto.categoria_aprovada_id },
        });
        if (!categoria) throw new BadRequestException('Categoria aprovada não encontrada');
        categoriaAprovadaId = updateDto.categoria_aprovada_id;
      }

      const novoStatus = updateDto.status || 'EM_ANALISE';

      await this.requisicaoRepo.update(id, {
        fornecedor_id: fornecedorId,
        status: novoStatus,
        motivo_rejeicao: novoStatus === 'REJEITADO' ? updateDto.motivo_rejeicao : null,
        preco_aprovado: precoAprovado,
        categoria_aprovada_id: categoriaAprovadaId,
        ultima_atualizacao_por_id: user.idusuario,
        ...(novoStatus === 'APROVADO' && {
          aprovado_por_id: user.idusuario,
          data_aprovacao: new Date(),
        }),
      });

      if (requisicao.produto_id) {
        const updateData: any = {
          fornecedor_id: fornecedorId,
        };
        if (novoStatus === 'APROVADO') {
          updateData.status_produto = 'DISPONIVEL';
          if (precoAprovado) {
            updateData.preco = precoAprovado;
          }
          if (categoriaAprovadaId) {
            updateData.categoria_id = categoriaAprovadaId;
          }
        } else if (novoStatus === 'REJEITADO') {
          updateData.status_produto = 'INDISPONIVEL';
        }
        await this.produtoRepo.update(requisicao.produto_id, updateData);
      }

      this.eventsGateway.notifyUser(requisicao.cliente_id, 'requisicao-status-changed', {
        requisicaoId: id,
        novoStatus: novoStatus,
        mensagem: novoStatus === 'APROVADO' ? 'Sua requisição foi aprovada!' : 'Sua requisição foi atualizada.',
      });

      return this.findOne(id, user);
    }

    // ADMIN pode tudo
    if (papeis.includes('ADMIN')) {
      let precoAprovado: string | null = requisicao.preco_aprovado;
      if (updateDto.preco_aprovado) {
        precoAprovado = updateDto.preco_aprovado.toString();
      }

      let categoriaAprovadaId: number | null = requisicao.categoria_aprovada_id;
      if (updateDto.categoria_aprovada_id) {
        const categoria = await this.categoriaRepo.findOne({
          where: { id_categoria: updateDto.categoria_aprovada_id },
        });
        if (!categoria) throw new BadRequestException('Categoria aprovada não encontrada');
        categoriaAprovadaId = updateDto.categoria_aprovada_id;
      }

      const updateData: any = {
        status: updateDto.status || requisicao.status,
        motivo_rejeicao: updateDto.motivo_rejeicao || requisicao.motivo_rejeicao,
        preco_aprovado: precoAprovado,
        categoria_aprovada_id: categoriaAprovadaId,
        ultima_atualizacao_por_id: user.idusuario,
      };
      if (updateDto.fornecedor_id !== undefined) {
        updateData.fornecedor_id = updateDto.fornecedor_id;
      }
      if (updateDto.status === 'APROVADO' && !requisicao.aprovado_por_id) {
        updateData.aprovado_por_id = user.idusuario;
        updateData.data_aprovacao = new Date();
      }
      await this.requisicaoRepo.update(id, updateData);

      if (requisicao.produto_id && updateDto.status === 'APROVADO') {
        const fornecedorId = updateDto.fornecedor_id || requisicao.fornecedor_id;
        const updateProdData: any = {
          fornecedor_id: fornecedorId || undefined,
          status_produto: 'DISPONIVEL',
          preco: precoAprovado || requisicao.preco_sugerido || '0',
        };
        if (categoriaAprovadaId) {
          updateProdData.categoria_id = categoriaAprovadaId;
        } else if (requisicao.categoria_sugerida_id) {
          updateProdData.categoria_id = requisicao.categoria_sugerida_id;
        }
        await this.produtoRepo.update(requisicao.produto_id, updateProdData);
      }

      this.eventsGateway.notifyUser(requisicao.cliente_id, 'requisicao-status-changed', {
        requisicaoId: id,
        novoStatus: updateDto.status || requisicao.status,
      });

      return this.findOne(id, user);
    }

    throw new ForbiddenException('Permissão insuficiente');
  }

  async remove(id: number, user: any) {
    const requisicao = await this.findOne(id, user);
    if (!user.papeis.includes('ADMIN')) {
      throw new ForbiddenException('Apenas administradores podem remover requisições');
    }
    if (requisicao.produto_id) {
      await this.produtoRepo.delete(requisicao.produto_id);
    }
    await this.requisicaoRepo.delete(id);
    return { message: 'Requisição removida permanentemente' };
  }
}
