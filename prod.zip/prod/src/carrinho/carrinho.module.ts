import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CarrinhoService } from './carrinho.service';
import { CarrinhoController } from './carrinho.controller';
import { Carrinho } from '../entities/Carrinho.entity';
import { CarrinhoItens } from '../entities/CarrinhoItens.entity';
import { Produtos } from '../entities/Produtos.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Carrinho, CarrinhoItens, Produtos])],
  controllers: [CarrinhoController],
  providers: [CarrinhoService],
})
export class CarrinhoModule {}
