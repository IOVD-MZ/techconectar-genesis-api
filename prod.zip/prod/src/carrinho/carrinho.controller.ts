import { Controller, Get, Post, Delete, Patch, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { CarrinhoService } from './carrinho.service';
import { AdicionarItemDto } from './dto/adicionar-item.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';

@ApiTags('carrinho')
@Controller('carrinho')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class CarrinhoController {
  constructor(private readonly carrinhoService: CarrinhoService) {}

  @Get()
  @ApiOperation({ summary: 'Obter carrinho atual' })
  getCarrinho(@Request() req) {
    return this.carrinhoService.getCarrinhoAtivo(req.user.idpessoa);
  }

  @Post('itens')
  @ApiOperation({ summary: 'Adicionar item ao carrinho' })
  @ApiBody({ type: AdicionarItemDto })
  adicionarItem(@Request() req, @Body() dto: AdicionarItemDto) {
    return this.carrinhoService.adicionarItem(req.user.idpessoa, dto);
  }

  @Delete('itens/:itemId')
  @ApiOperation({ summary: 'Remover item do carrinho' })
  removerItem(@Request() req, @Param('itemId') itemId: string) {
    return this.carrinhoService.removerItem(req.user.idpessoa, +itemId);
  }

  @Patch('itens/:itemId')
  @ApiOperation({ summary: 'Atualizar quantidade de item' })
  @ApiBody({ schema: { properties: { quantidade: { type: 'number' } } } })
  atualizarQuantidade(@Request() req, @Param('itemId') itemId: string, @Body('quantidade') quantidade: number) {
    return this.carrinhoService.atualizarQuantidade(req.user.idpessoa, +itemId, quantidade);
  }

  @Delete()
  @ApiOperation({ summary: 'Limpar carrinho' })
  limparCarrinho(@Request() req) {
    return this.carrinhoService.limparCarrinho(req.user.idpessoa);
  }

  @Post('finalizar')
  @ApiOperation({ summary: 'Finalizar carrinho' })
  finalizarCarrinho(@Request() req) {
    return this.carrinhoService.finalizarCarrinho(req.user.idpessoa);
  }
}
