import {
  Injectable,
  NotFoundException,
  BadRequestException,
  InternalServerErrorException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Carrinho } from '../entities/Carrinho.entity';
import { CarrinhoItens } from '../entities/CarrinhoItens.entity';
import { Produtos } from '../entities/Produtos.entity';
import { AdicionarItemDto } from './dto/adicionar-item.dto';

@Injectable()
export class CarrinhoService {
  private readonly logger = new Logger(CarrinhoService.name);

  constructor(
    @InjectRepository(Carrinho) private carrinhoRepo: Repository<Carrinho>,
    @InjectRepository(CarrinhoItens)
    private itemRepo: Repository<CarrinhoItens>,
    @InjectRepository(Produtos) private produtoRepo: Repository<Produtos>,
    private dataSource: DataSource,
  ) {}

  // ────────────────────────────────────────────────────────
  async getCarrinhoAtivo(usuarioId: number): Promise<Carrinho> {
    if (!usuarioId || isNaN(usuarioId)) {
      throw new BadRequestException('Utilizador inválido');
    }

    try {
      // Buscar diretamente com query SQL (mais robusto que relations)
      const carrinhos = await this.dataSource.query(
        `SELECT id_carrinho, usuario_id, estado, data_criacao
         FROM carrinho
         WHERE usuario_id = ? AND estado = 'ABERTO'
         ORDER BY id_carrinho DESC
         LIMIT 1`,
        [usuarioId],
      );

      let carrinhoId: number;

      if (carrinhos.length === 0) {
        // Criar novo carrinho
        const result = await this.dataSource.query(
          `INSERT INTO carrinho (usuario_id, estado) VALUES (?, 'ABERTO')`,
          [usuarioId],
        );
        carrinhoId = result.insertId;
      } else {
        carrinhoId = carrinhos[0].id_carrinho;
      }

      // Buscar itens associados
      const itens = await this.dataSource.query(
        `SELECT 
           ci.id_item, ci.carrinho_id, ci.produto_id, ci.quantidade,
           ci.custo_unitario, ci.produto_peso, ci.data_criacao,
           p.nome AS produto_nome, p.preco AS produto_preco,
           p.preco_promocional AS produto_preco_promocional,
           p.stock AS produto_stock, p.status_produto,
           p.fornecedor_id, p.categoria_id, p.descricao AS produto_descricao
         FROM carrinho_itens ci
         LEFT JOIN produtos p ON p.id_produto = ci.produto_id
         WHERE ci.carrinho_id = ?
         ORDER BY ci.id_item ASC`,
        [carrinhoId],
      );

      // Montar objeto compatível com o formato anterior
      const carrinho: any = {
        id_carrinho: carrinhoId,
        usuario_id: usuarioId,
        estado: 'ABERTO',
        data_criacao: carrinhos[0]?.data_criacao || new Date(),
        itens: itens.map((it: any) => ({
          id_item: it.id_item,
          carrinho_id: it.carrinho_id,
          produto_id: it.produto_id,
          quantidade: it.quantidade,
          custo_unitario: it.custo_unitario,
          produto_peso: it.produto_peso,
          data_criacao: it.data_criacao,
          produto: it.produto_nome
            ? {
                id_produto: it.produto_id,
                nome: it.produto_nome,
                descricao: it.produto_descricao,
                preco: it.produto_preco,
                preco_promocional: it.produto_preco_promocional,
                stock: it.produto_stock,
                status_produto: it.status_produto,
                fornecedor_id: it.fornecedor_id,
                categoria_id: it.categoria_id,
              }
            : null,
        })),
      };

      return carrinho;
    } catch (err) {
      this.logger.error(
        `Erro ao obter carrinho do utilizador ${usuarioId}: ${err.message}`,
        err.stack,
      );
      throw new InternalServerErrorException(
        'Não foi possível obter o carrinho',
      );
    }
  }

  // ────────────────────────────────────────────────────────
  async adicionarItem(usuarioId: number, dto: AdicionarItemDto) {
    const carrinho = await this.getCarrinhoAtivo(usuarioId);

    const produto = await this.produtoRepo.findOne({
      where: { id_produto: dto.produto_id },
    });
    if (!produto) throw new NotFoundException('Produto não encontrado');

    const preco = produto.preco_promocional
      ? parseFloat(produto.preco_promocional)
      : parseFloat(produto.preco);
    const peso = produto.atributos_especificos?.peso_g || null;

    // Verificar se item já existe
    const existentes = await this.dataSource.query(
      `SELECT id_item, quantidade FROM carrinho_itens 
       WHERE carrinho_id = ? AND produto_id = ? LIMIT 1`,
      [carrinho.id_carrinho, dto.produto_id],
    );

    if (existentes.length > 0) {
      await this.dataSource.query(
        `UPDATE carrinho_itens SET quantidade = quantidade + ? WHERE id_item = ?`,
        [dto.quantidade, existentes[0].id_item],
      );
    } else {
      await this.dataSource.query(
        `INSERT INTO carrinho_itens 
         (carrinho_id, produto_id, quantidade, custo_unitario, produto_peso)
         VALUES (?, ?, ?, ?, ?)`,
        [
          carrinho.id_carrinho,
          dto.produto_id,
          dto.quantidade,
          preco.toString(),
          peso ? peso.toString() : null,
        ],
      );
    }

    return this.getCarrinhoAtivo(usuarioId);
  }

  // ────────────────────────────────────────────────────────
  async removerItem(usuarioId: number, itemId: number) {
    const carrinho = await this.getCarrinhoAtivo(usuarioId);

    const itens = await this.dataSource.query(
      `SELECT id_item FROM carrinho_itens 
       WHERE id_item = ? AND carrinho_id = ? LIMIT 1`,
      [itemId, carrinho.id_carrinho],
    );
    if (itens.length === 0) throw new NotFoundException('Item não encontrado');

    await this.dataSource.query(`DELETE FROM carrinho_itens WHERE id_item = ?`, [
      itemId,
    ]);

    return this.getCarrinhoAtivo(usuarioId);
  }

  // ────────────────────────────────────────────────────────
  async atualizarQuantidade(
    usuarioId: number,
    itemId: number,
    quantidade: number,
  ) {
    if (quantidade < 1) {
      throw new BadRequestException('Quantidade deve ser >= 1');
    }

    const carrinho = await this.getCarrinhoAtivo(usuarioId);

    const itens = await this.dataSource.query(
      `SELECT id_item FROM carrinho_itens 
       WHERE id_item = ? AND carrinho_id = ? LIMIT 1`,
      [itemId, carrinho.id_carrinho],
    );
    if (itens.length === 0) throw new NotFoundException('Item não encontrado');

    await this.dataSource.query(
      `UPDATE carrinho_itens SET quantidade = ? WHERE id_item = ?`,
      [quantidade, itemId],
    );

    return this.getCarrinhoAtivo(usuarioId);
  }

  // ────────────────────────────────────────────────────────
  async limparCarrinho(usuarioId: number) {
    const carrinho = await this.getCarrinhoAtivo(usuarioId);

    await this.dataSource.query(
      `DELETE FROM carrinho_itens WHERE carrinho_id = ?`,
      [carrinho.id_carrinho],
    );

    return this.getCarrinhoAtivo(usuarioId);
  }

  // ────────────────────────────────────────────────────────
  async finalizarCarrinho(usuarioId: number) {
    const carrinho = await this.getCarrinhoAtivo(usuarioId);

    if (!carrinho.itens || carrinho.itens.length === 0) {
      throw new BadRequestException('Carrinho vazio');
    }

    await this.dataSource.query(
      `UPDATE carrinho SET estado = 'FINALIZADO' WHERE id_carrinho = ?`,
      [carrinho.id_carrinho],
    );

    return { message: 'Carrinho finalizado com sucesso' };
  }
}
