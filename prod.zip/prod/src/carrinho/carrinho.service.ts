import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Carrinho } from '../entities/Carrinho.entity';
import { CarrinhoItens } from '../entities/CarrinhoItens.entity';
import { Produtos } from '../entities/Produtos.entity';
import { AdicionarItemDto } from './dto/adicionar-item.dto';

@Injectable()
export class CarrinhoService {
  constructor(
    @InjectRepository(Carrinho) private carrinhoRepo: Repository<Carrinho>,
    @InjectRepository(CarrinhoItens) private itemRepo: Repository<CarrinhoItens>,
    @InjectRepository(Produtos) private produtoRepo: Repository<Produtos>,
  ) {}

  async getCarrinhoAtivo(usuarioId: number) {
    let carrinho = await this.carrinhoRepo.findOne({
      where: { usuario_id: usuarioId, estado: 'ABERTO' },
      relations: { itens: { produto: true } },
    });
    if (!carrinho) {
      carrinho = this.carrinhoRepo.create({ usuario_id: usuarioId, estado: 'ABERTO' });
      carrinho = await this.carrinhoRepo.save(carrinho);
    }
    return carrinho;
  }

  async adicionarItem(usuarioId: number, dto: AdicionarItemDto) {
    const carrinho = await this.getCarrinhoAtivo(usuarioId);
    const produto = await this.produtoRepo.findOne({ where: { id_produto: dto.produto_id } });
    if (!produto) throw new NotFoundException('Produto não encontrado');

    const preco = produto.preco_promocional ? parseFloat(produto.preco_promocional) : parseFloat(produto.preco);
    const peso = produto.atributos_especificos?.peso_g || null;

    // Verificar se já existe item
    let item = await this.itemRepo.findOne({
      where: { carrinho_id: carrinho.id_carrinho, produto_id: dto.produto_id },
    });
    if (item) {
      item.quantidade += dto.quantidade;
    } else {
      item = this.itemRepo.create({
        carrinho_id: carrinho.id_carrinho,
        produto_id: dto.produto_id,
        quantidade: dto.quantidade,
        custo_unitario: preco.toString(),
        produto_peso: peso ? peso.toString() : null,
      });
    }
    await this.itemRepo.save(item);
    return this.getCarrinhoAtivo(usuarioId);
  }

  async removerItem(usuarioId: number, itemId: number) {
    const carrinho = await this.getCarrinhoAtivo(usuarioId);
    const item = await this.itemRepo.findOne({
      where: { id_item: itemId, carrinho_id: carrinho.id_carrinho },
    });
    if (!item) throw new NotFoundException('Item não encontrado');
    await this.itemRepo.remove(item);
    return this.getCarrinhoAtivo(usuarioId);
  }

  async atualizarQuantidade(usuarioId: number, itemId: number, quantidade: number) {
    if (quantidade < 1) throw new BadRequestException('Quantidade deve ser >= 1');
    const carrinho = await this.getCarrinhoAtivo(usuarioId);
    const item = await this.itemRepo.findOne({
      where: { id_item: itemId, carrinho_id: carrinho.id_carrinho },
    });
    if (!item) throw new NotFoundException('Item não encontrado');
    item.quantidade = quantidade;
    await this.itemRepo.save(item);
    return this.getCarrinhoAtivo(usuarioId);
  }

  async limparCarrinho(usuarioId: number) {
    const carrinho = await this.getCarrinhoAtivo(usuarioId);
    await this.itemRepo.delete({ carrinho_id: carrinho.id_carrinho });
    return this.getCarrinhoAtivo(usuarioId);
  }

  async finalizarCarrinho(usuarioId: number) {
    const carrinho = await this.getCarrinhoAtivo(usuarioId);
    if (carrinho.itens.length === 0) {
      throw new BadRequestException('Carrinho vazio');
    }
    carrinho.estado = 'FINALIZADO';
    await this.carrinhoRepo.save(carrinho);
    // Aqui poderia criar um pedido automaticamente
    return { message: 'Carrinho finalizado com sucesso' };
  }
}
