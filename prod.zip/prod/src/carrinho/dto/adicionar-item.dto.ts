import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, Min } from 'class-validator';

export class AdicionarItemDto {
  @ApiProperty({ example: 1 })
  @IsNumber()
  produto_id: number;

  @ApiProperty({ example: 2 })
  @IsNumber()
  @Min(1)
  quantidade: number;
}
