import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BannersService } from './banners.service';
import { BannersController } from './banners.controller';
import { PessoaAnexo } from '../entities/PessoaAnexo.entity';
import { Anexo } from '../entities/Anexo.entity';
import { Pessoa } from '../entities/Pessoa.entity';

@Module({
  imports: [TypeOrmModule.forFeature([PessoaAnexo, Anexo, Pessoa])],
  controllers: [BannersController],
  providers: [BannersService],
})
export class BannersModule {}
