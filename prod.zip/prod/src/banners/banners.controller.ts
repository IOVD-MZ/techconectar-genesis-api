import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  ParseIntPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiBody,
  ApiQuery,
  ApiParam,
} from '@nestjs/swagger';
import { BannersService } from './banners.service';
import { CreateBannerDto } from './dto/create-banner.dto';
import { UpdateBannerDto } from './dto/update-banner.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('banners')
@Controller('banners')
export class BannersController {
  constructor(private readonly bannersService: BannersService) {}

  // ═══════════ PÚBLICO ═══════════
  @Get()
  @ApiOperation({ summary: 'Listar banners ativos (público)' })
  @ApiQuery({ name: 'fornecedor_id', required: false, type: Number })
  @ApiResponse({ status: 200, description: 'Lista de banners' })
  async listar(@Query('fornecedor_id') fornecedorId?: string) {
    return this.bannersService.listar(
      fornecedorId ? parseInt(fornecedorId) : undefined,
    );
  }

  @Get('fornecedor/:fornecedorId')
  @ApiOperation({ summary: 'Listar banners de um fornecedor específico' })
  @ApiParam({ name: 'fornecedorId', description: 'ID do fornecedor' })
  async listarPorFornecedor(
    @Param('fornecedorId', ParseIntPipe) fornecedorId: number,
  ) {
    return this.bannersService.listarPorFornecedor(fornecedorId);
  }

  // ═══════════ ADMIN ═══════════
  @Post()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Criar banner (apenas ADMIN)' })
  @ApiBody({ type: CreateBannerDto })
  @ApiResponse({ status: 201, description: 'Banner criado' })
  async criar(@Body() dto: CreateBannerDto) {
    const { idpessoa, anexo_id, tipo, ...config } = dto;
    return this.bannersService.criar({ idpessoa, anexo_id, tipo, config });
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Atualizar banner (apenas ADMIN)' })
  @ApiParam({ name: 'id', description: 'ID da relação banner' })
  @ApiBody({ type: UpdateBannerDto })
  async atualizar(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateBannerDto,
  ) {
    const { tipo, ...config } = dto;
    return this.bannersService.atualizar(id, { tipo, config });
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Remover banner (apenas ADMIN)' })
  @ApiParam({ name: 'id', description: 'ID da relação banner' })
  async remover(@Param('id', ParseIntPipe) id: number) {
    return this.bannersService.remover(id);
  }
}
