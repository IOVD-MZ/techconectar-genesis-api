import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PessoaAnexo } from '../entities/PessoaAnexo.entity';
import { Anexo } from '../entities/Anexo.entity';
import { Pessoa } from '../entities/Pessoa.entity';

const BANNER_TIPOS = [
  'banner_hero',
  'banner_secundario',
  'banner_masonry',
  'banner_evento',
] as const;

export interface BannerConfig {
  link_url?: string;
  peso?: number;
  titulo?: string;
  ordem?: number;
  data_inicio?: string;
  data_fim?: string;
  [key: string]: any;
}

@Injectable()
export class BannersService {
  private readonly logger = new Logger(BannersService.name);

  constructor(
    @InjectRepository(PessoaAnexo)
    private pessoaAnexoRepo: Repository<PessoaAnexo>,
    @InjectRepository(Anexo)
    private anexoRepo: Repository<Anexo>,
    @InjectRepository(Pessoa)
    private pessoaRepo: Repository<Pessoa>,
  ) {}

  /**
   * Lista todos os banners (público).
   * Filtra por tipo banner_* e não deletados.
   * Aplica filtro de validade (data_inicio/data_fim) se definidos no config.
   */
  async listar(fornecedorId?: number) {
    const qb = this.pessoaAnexoRepo
      .createQueryBuilder('pa')
      .innerJoinAndSelect('pa.anexo', 'anexo')
      .innerJoinAndSelect('pa.pessoa', 'pessoa')
      .where('pa.tipo IN (:...tipos)', { tipos: BANNER_TIPOS })
      .andWhere('anexo.is_deleted = :isDeleted', { isDeleted: false });

    if (fornecedorId) {
      qb.andWhere('pa.pessoa_id = :fornecedorId', { fornecedorId });
    }

    const relacoes = await qb.orderBy('pa.criado_em', 'DESC').getMany();

    const agora = new Date();

    return relacoes
      .map((r) => this.formatBanner(r))
      .filter((b) => b !== null)
      .filter((b) => {
        // Filtro de validade: se data_inicio ou data_fim estiverem definidas no config
        const config = b.config || {};
        if (config.data_inicio) {
          const inicio = new Date(config.data_inicio);
          if (!isNaN(inicio.getTime()) && inicio > agora) return false;
        }
        if (config.data_fim) {
          const fim = new Date(config.data_fim);
          if (!isNaN(fim.getTime()) && fim < agora) return false;
        }
        return true;
      });
  }

  /**
   * Lista banners de um fornecedor específico.
   */
  async listarPorFornecedor(fornecedorId: number) {
    if (!fornecedorId || isNaN(fornecedorId)) {
      throw new BadRequestException('Fornecedor inválido');
    }
    return this.listar(fornecedorId);
  }

  /**
   * Cria um banner (associa um anexo existente a uma pessoa com tipo banner_*).
   * Persiste o config na coluna JSON.
   */
  async criar(dto: {
    idpessoa: number;
    anexo_id: number;
    tipo: string;
    config?: BannerConfig;
  }) {
    if (!BANNER_TIPOS.includes(dto.tipo as any)) {
      throw new BadRequestException(
        `Tipo inválido. Válidos: ${BANNER_TIPOS.join(', ')}`,
      );
    }

    const pessoa = await this.pessoaRepo.findOne({
      where: { idpessoa: dto.idpessoa },
      select: { idpessoa: true },
    });
    if (!pessoa) throw new NotFoundException('Pessoa não encontrada');

    const anexo = await this.anexoRepo.findOne({
      where: { id: dto.anexo_id, is_deleted: false },
    });
    if (!anexo) throw new NotFoundException('Anexo não encontrado');

    const rel = this.pessoaAnexoRepo.create({
      pessoa_id: dto.idpessoa,
      anexo_id: dto.anexo_id,
      tipo: dto.tipo,
      config: dto.config || null,
    });

    const saved = await this.pessoaAnexoRepo.save(rel);

    // Recarrega com relações
    const full = await this.pessoaAnexoRepo.findOne({
      where: { id: saved.id },
      relations: { anexo: true, pessoa: true },
    });

    return this.formatBanner(full);
  }

  /**
   * Atualiza tipo e/ou config de um banner.
   * Se config for fornecido, substitui o config existente (merge é opcional).
   */
  async atualizar(
    id: number,
    dto: { tipo?: string; config?: BannerConfig },
  ) {
    const rel = await this.pessoaAnexoRepo.findOne({
      where: { id },
      relations: { anexo: true, pessoa: true },
    });
    if (!rel) throw new NotFoundException('Banner não encontrado');

    if (dto.tipo) {
      if (!BANNER_TIPOS.includes(dto.tipo as any)) {
        throw new BadRequestException(
          `Tipo inválido. Válidos: ${BANNER_TIPOS.join(', ')}`,
        );
      }
      rel.tipo = dto.tipo;
    }

    // Merge do config (preserva chaves existentes, sobrescreve apenas as enviadas)
    if (dto.config) {
      const configExistente = rel.config || {};
      rel.config = { ...configExistente, ...dto.config };
    }

    await this.pessoaAnexoRepo.save(rel);

    // Recarrega
    const full = await this.pessoaAnexoRepo.findOne({
      where: { id },
      relations: { anexo: true, pessoa: true },
    });

    return this.formatBanner(full);
  }

  /**
   * Remove um banner (hard delete da relação).
   */
  async remover(id: number) {
    const rel = await this.pessoaAnexoRepo.findOne({ where: { id } });
    if (!rel) throw new NotFoundException('Banner não encontrado');

    await this.pessoaAnexoRepo.remove(rel);
    return { message: 'Banner removido com sucesso' };
  }

  // ---------- HELPER ----------
  private formatBanner(rel: PessoaAnexo | null) {
    if (!rel || !rel.anexo) return null;

    const a = rel.anexo;
    const url = a.caminho_armazenamento;
    const config: BannerConfig = rel.config || {};

    return {
      id: rel.id,
      tipo: rel.tipo,
      titulo: config.titulo || a.nome_ficheiro_original || null,
      imagem_url: url,
      link_url: config.link_url || null,
      ordem: config.ordem ?? 0,
      peso: config.peso ?? 10,
      fornecedor_id:
        rel.pessoa && rel.pessoa.tipo_pessoa === 'FORNECEDOR'
          ? rel.pessoa_id
          : null,
      idpessoa_dono: rel.pessoa_id,
      data_inicio: config.data_inicio || null,
      data_fim: config.data_fim || null,
      is_ativo: !a.is_deleted,
      config,
      anexo: {
        id: a.id,
        nome_ficheiro_original: a.nome_ficheiro_original,
        mime_type: a.mime_type,
        tamanho_bytes: a.tamanho_bytes,
        hash_sha256: a.hash_sha256,
      },
    };
  }
}
