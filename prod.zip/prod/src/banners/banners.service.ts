import {
  Injectable, NotFoundException, BadRequestException, Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { PessoaAnexo } from '../entities/PessoaAnexo.entity';
import { Anexo } from '../entities/Anexo.entity';
import { Pessoa } from '../entities/Pessoa.entity';

const BANNER_TIPOS = [
  'banner_hero','banner_secundario','banner_masonry','banner_evento',
];

@Injectable()
export class BannersService {
  private readonly logger = new Logger(BannersService.name);

  constructor(
    @InjectRepository(PessoaAnexo)
    private pessoaAnexoRepo: Repository<PessoaAnexo>,
    @InjectRepository(Anexo)
    private anexoRepo: Repository<Anexo>,
    @InjectRepository(Pessoa)
    private pessoaRepo: Repository<Pessoa>,
    private dataSource: DataSource,
  ) {}

  async listar(fornecedorId?: number) {
    try {
      const placeholders = BANNER_TIPOS.map(() => '?').join(',');
      let sql = `
        SELECT 
          pa.id, pa.pessoa_id, pa.anexo_id, pa.tipo,
          pa.config, pa.criado_em,
          a.nome_ficheiro_original, a.caminho_armazenamento,
          a.tamanho_bytes, a.hash_sha256, a.mime_type,
          p.nome_completo AS pessoa_nome, p.tipo_pessoa
        FROM pessoa_anexo pa
        INNER JOIN anexo a ON a.id = pa.anexo_id
        LEFT JOIN pessoa p ON p.idpessoa = pa.pessoa_id
        WHERE pa.tipo IN (${placeholders}) AND a.is_deleted = 0`;
      const params: any[] = [...BANNER_TIPOS];

      if (fornecedorId) {
        sql += ` AND pa.pessoa_id = ?`;
        params.push(fornecedorId);
      }
      sql += ` ORDER BY pa.criado_em DESC`;

      const rows = await this.dataSource.query(sql, params);
      const agora = new Date();

      return (rows || [])
        .map((r: any) => this.formatBannerFromRow(r))
        .filter((b) => b !== null)
        .filter((b) => {
          const cfg = b.config || {};
          if (cfg.data_inicio) {
            const dt = new Date(cfg.data_inicio);
            if (!isNaN(dt.getTime()) && dt > agora) return false;
          }
          if (cfg.data_fim) {
            const dt = new Date(cfg.data_fim);
            if (!isNaN(dt.getTime()) && dt < agora) return false;
          }
          return true;
        });
    } catch (err) {
      this.logger.error(`Erro ao listar banners: ${err.message}`, err.stack);
      return [];
    }
  }

  async listarPorFornecedor(fornecedorId: number) {
    if (!fornecedorId || isNaN(fornecedorId)) {
      throw new BadRequestException('Fornecedor inválido');
    }
    return this.listar(fornecedorId);
  }

  async criar(dto: any) {
    if (!BANNER_TIPOS.includes(dto.tipo)) {
      throw new BadRequestException(`Tipo inválido: ${dto.tipo}`);
    }

    const pessoa = await this.pessoaRepo.findOne({
      where: { idpessoa: dto.idpessoa }, select: { idpessoa: true },
    });
    if (!pessoa) throw new NotFoundException('Pessoa não encontrada');

    const anexo = await this.anexoRepo.findOne({
      where: { id: dto.anexo_id, is_deleted: false },
    });
    if (!anexo) throw new NotFoundException('Anexo não encontrado');

    const { idpessoa, anexo_id, tipo, ...config } = dto;
    const configObj = Object.keys(config).length > 0 ? config : null;

    await this.dataSource.query(
      `INSERT INTO pessoa_anexo (pessoa_id, anexo_id, tipo, config) VALUES (?, ?, ?, ?)`,
      [idpessoa, anexo_id, tipo, configObj ? JSON.stringify(configObj) : null],
    );

    const result = await this.dataSource.query(
      `SELECT MAX(id) AS new_id FROM pessoa_anexo WHERE pessoa_id = ? AND anexo_id = ?`,
      [idpessoa, anexo_id],
    );
    const newId = result[0].new_id;

    return this.listar().then((list) => list.find((b) => b.id === newId));
  }

  async atualizar(id: number, dto: any) {
    const existing = await this.dataSource.query(
      `SELECT id, tipo, config FROM pessoa_anexo WHERE id = ?`, [id],
    );
    if (!existing || existing.length === 0) {
      throw new NotFoundException('Banner não encontrado');
    }

    const { tipo, ...config } = dto;
    const configAtual = existing[0].config
      ? typeof existing[0].config === 'string'
        ? JSON.parse(existing[0].config)
        : existing[0].config
      : {};
    const configNovo = { ...configAtual, ...config };

    if (tipo) {
      if (!BANNER_TIPOS.includes(tipo)) throw new BadRequestException('Tipo inválido');
      await this.dataSource.query(
        `UPDATE pessoa_anexo SET tipo = ?, config = ? WHERE id = ?`,
        [tipo, JSON.stringify(configNovo), id],
      );
    } else {
      await this.dataSource.query(
        `UPDATE pessoa_anexo SET config = ? WHERE id = ?`,
        [JSON.stringify(configNovo), id],
      );
    }

    const result = await this.dataSource.query(
      `SELECT pa.id, pa.pessoa_id, pa.anexo_id, pa.tipo, pa.config, pa.criado_em,
              a.nome_ficheiro_original, a.caminho_armazenamento,
              a.tamanho_bytes, a.hash_sha256, a.mime_type,
              p.nome_completo AS pessoa_nome, p.tipo_pessoa
       FROM pessoa_anexo pa
       INNER JOIN anexo a ON a.id = pa.anexo_id
       LEFT JOIN pessoa p ON p.idpessoa = pa.pessoa_id
       WHERE pa.id = ?`, [id],
    );
    return this.formatBannerFromRow(result[0]);
  }

  async remover(id: number) {
    const existing = await this.dataSource.query(
      `SELECT id FROM pessoa_anexo WHERE id = ?`, [id],
    );
    if (!existing || existing.length === 0) {
      throw new NotFoundException('Banner não encontrado');
    }
    await this.dataSource.query(`DELETE FROM pessoa_anexo WHERE id = ?`, [id]);
    return { message: 'Banner removido com sucesso' };
  }

  private formatBannerFromRow(r: any) {
    if (!r) return null;
    const config = r.config
      ? typeof r.config === 'string' ? JSON.parse(r.config) : r.config
      : {};

    return {
      id: r.id,
      tipo: r.tipo,
      titulo: config.titulo || r.nome_ficheiro_original || null,
      imagem_url: r.caminho_armazenamento,
      link_url: config.link_url || null,
      ordem: config.ordem ?? 0,
      peso: config.peso ?? 10,
      fornecedor_id: r.tipo_pessoa === 'FORNECEDOR' ? r.pessoa_id : null,
      idpessoa_dono: r.pessoa_id,
      data_inicio: config.data_inicio || null,
      data_fim: config.data_fim || null,
      is_ativo: true,
      config,
      anexo: {
        id: r.anexo_id,
        nome_ficheiro_original: r.nome_ficheiro_original,
        mime_type: r.mime_type,
        tamanho_bytes: r.tamanho_bytes,
        hash_sha256: r.hash_sha256,
      },
    };
  }
}
