import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  IsUrl,
  Min,
  Max,
} from 'class-validator';

export class CreateBannerDto {
  @ApiProperty({ example: 1, description: 'ID da pessoa (fornecedor ou sistema)' })
  @IsNumber()
  idpessoa: number;

  @ApiProperty({ example: 5, description: 'ID do anexo existente' })
  @IsNumber()
  anexo_id: number;

  @ApiProperty({
    enum: ['banner_hero', 'banner_secundario', 'banner_masonry', 'banner_evento'],
  })
  @IsEnum(['banner_hero', 'banner_secundario', 'banner_masonry', 'banner_evento'])
  tipo: string;

  @ApiPropertyOptional({ example: 'Promoção de Verão' })
  @IsOptional()
  @IsString()
  titulo?: string;

  @ApiPropertyOptional({ example: '/produtos?categoria=4' })
  @IsOptional()
  @IsString()
  link_url?: string;

  @ApiPropertyOptional({ example: 10, description: 'Peso para sorteio ponderado (1-100)' })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(100)
  peso?: number;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsNumber()
  ordem?: number;

  @ApiPropertyOptional({ example: '2026-09-13T00:00:00Z' })
  @IsOptional()
  @IsString()
  data_inicio?: string;

  @ApiPropertyOptional({ example: '2026-10-13T23:59:59Z' })
  @IsOptional()
  @IsString()
  data_fim?: string;
}
