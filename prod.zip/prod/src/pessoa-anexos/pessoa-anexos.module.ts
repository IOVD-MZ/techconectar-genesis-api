import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PessoaAnexosService } from './pessoa-anexos.service';
import { PessoaAnexosController } from './pessoa-anexos.controller';
import { PessoaAnexo } from '../entities/PessoaAnexo.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Anexo } from '../entities/Anexo.entity';

@Module({
  imports: [TypeOrmModule.forFeature([PessoaAnexo, Pessoa, Anexo])],
  controllers: [PessoaAnexosController],
  providers: [PessoaAnexosService],
})
export class PessoaAnexosModule {}
