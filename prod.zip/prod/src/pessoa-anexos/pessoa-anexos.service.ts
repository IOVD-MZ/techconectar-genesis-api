import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { PessoaAnexo } from '../entities/PessoaAnexo.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Anexo } from '../entities/Anexo.entity';
import { CreatePessoaAnexoDto, UpdatePessoaAnexoDto } from '../anexos/dto/pessoa-anexo.dto';

@Injectable()
export class PessoaAnexosService {
  constructor(
    @InjectRepository(PessoaAnexo) private relRepo: Repository<PessoaAnexo>,
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
    @InjectRepository(Anexo) private anexoRepo: Repository<Anexo>,
    private dataSource: DataSource,
  ) {}

  async create(pessoaId: number, dto: CreatePessoaAnexoDto) {
    const pessoa = await this.pessoaRepo.findOne({ where: { idpessoa: pessoaId } });
    if (!pessoa) throw new NotFoundException('Pessoa não encontrada');

    const anexo = await this.anexoRepo.findOne({ where: { id: dto.anexo_id } });
    if (!anexo) throw new NotFoundException('Anexo não encontrado');

    const existente = await this.relRepo.findOne({
      where: { pessoa_id: pessoaId, anexo_id: dto.anexo_id },
    });
    if (existente) throw new ConflictException('Anexo já está associado a esta pessoa');

    const rel = this.relRepo.create({
      pessoa_id: pessoaId,
      anexo_id: dto.anexo_id,
      tipo: dto.tipo,
    });
    return await this.relRepo.save(rel);
  }

    async findAll(pessoaId: number) {
    if (!pessoaId || isNaN(pessoaId)) {
      throw new NotFoundException('Pessoa inválida');
    }
    const rows = await this.dataSource.query(
      `SELECT 
         pa.id, pa.pessoa_id, pa.anexo_id, pa.tipo,
         pa.config, pa.criado_em, pa.atualizado_em,
         a.nome_ficheiro_original, a.caminho_armazenamento,
         a.tamanho_bytes, a.hash_sha256, a.mime_type, a.is_deleted
       FROM pessoa_anexo pa
       INNER JOIN anexo a ON a.id = pa.anexo_id
       WHERE pa.pessoa_id = ? AND a.is_deleted = 0
       ORDER BY pa.criado_em ASC`,
      [pessoaId],
    );

    return (rows || []).map((r: any) => ({
      id: r.id,
      pessoa_id: r.pessoa_id,
      anexo_id: r.anexo_id,
      tipo: r.tipo,
      config: r.config ? (typeof r.config === 'string' ? JSON.parse(r.config) : r.config) : null,
      criado_em: r.criado_em,
      atualizado_em: r.atualizado_em,
      anexo: {
        id: r.anexo_id,
        nome_ficheiro_original: r.nome_ficheiro_original,
        caminho_armazenamento: r.caminho_armazenamento,
        url: r.caminho_armazenamento,
        tamanho_bytes: r.tamanho_bytes,
        hash_sha256: r.hash_sha256,
        mime_type: r.mime_type,
      },
    }));
  }

  async findOne(id: number) {
    const rel = await this.relRepo.findOne({
      where: { id },
      relations: { anexo: true, pessoa: true },
    });
    if (!rel) throw new NotFoundException('Relação não encontrada');
    return rel;
  }

  async update(id: number, dto: UpdatePessoaAnexoDto) {
    await this.findOne(id);
    await this.relRepo.update(id, dto);
    return this.findOne(id);
  }

  async remove(id: number) {
    const rel = await this.findOne(id);
    await this.relRepo.remove(rel);
    return { message: 'Relação removida' };
  }
}
