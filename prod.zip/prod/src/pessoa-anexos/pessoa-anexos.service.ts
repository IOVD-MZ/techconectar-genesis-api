import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PessoaAnexo } from '../entities/PessoaAnexo.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Anexo } from '../entities/Anexo.entity';
import { CreatePessoaAnexoDto, UpdatePessoaAnexoDto } from '../anexos/dto/pessoa-anexo.dto';

@Injectable()
export class PessoaAnexosService {
  constructor(
    @InjectRepository(PessoaAnexo) private relRepo: Repository<PessoaAnexo>,
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
    @InjectRepository(Anexo) private anexoRepo: Repository<Anexo>,
  ) {}

  async create(pessoaId: number, dto: CreatePessoaAnexoDto) {
    const pessoa = await this.pessoaRepo.findOne({ where: { idpessoa: pessoaId } });
    if (!pessoa) throw new NotFoundException('Pessoa não encontrada');

    const anexo = await this.anexoRepo.findOne({ where: { id: dto.anexo_id } });
    if (!anexo) throw new NotFoundException('Anexo não encontrado');

    const existente = await this.relRepo.findOne({
      where: { pessoa_id: pessoaId, anexo_id: dto.anexo_id },
    });
    if (existente) throw new ConflictException('Anexo já está associado a esta pessoa');

    const rel = this.relRepo.create({
      pessoa_id: pessoaId,
      anexo_id: dto.anexo_id,
      tipo: dto.tipo,
    });
    return await this.relRepo.save(rel);
  }

  async findAll(pessoaId: number) {
    return await this.relRepo.find({
      where: { pessoa_id: pessoaId },
      relations: { anexo: true },
      order: { criado_em: 'ASC' },
    });
  }

  async findOne(id: number) {
    const rel = await this.relRepo.findOne({
      where: { id },
      relations: { anexo: true, pessoa: true },
    });
    if (!rel) throw new NotFoundException('Relação não encontrada');
    return rel;
  }

  async update(id: number, dto: UpdatePessoaAnexoDto) {
    await this.findOne(id);
    await this.relRepo.update(id, dto);
    return this.findOne(id);
  }

  async remove(id: number) {
    const rel = await this.findOne(id);
    await this.relRepo.remove(rel);
    return { message: 'Relação removida' };
  }
}
