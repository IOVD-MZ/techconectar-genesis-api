import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { PessoaAnexosService } from './pessoa-anexos.service';
import { CreatePessoaAnexoDto, UpdatePessoaAnexoDto } from '../anexos/dto/pessoa-anexo.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('pessoa-anexos')
@Controller('pessoa-anexos')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class PessoaAnexosController {
  constructor(private readonly service: PessoaAnexosService) {}

  @Post('pessoa/:pessoaId')
  @Permissions('anexos:upload')
  @ApiOperation({ summary: 'Associar anexo a uma pessoa' })
  @ApiBody({ type: CreatePessoaAnexoDto })
  create(@Param('pessoaId') pessoaId: string, @Body() dto: CreatePessoaAnexoDto) {
    return this.service.create(+pessoaId, dto);
  }

  @Get('pessoa/:pessoaId')
  @Permissions('anexos:visualizar')
  @ApiOperation({ summary: 'Listar anexos de uma pessoa' })
  findAll(@Param('pessoaId') pessoaId: string) {
    return this.service.findAll(+pessoaId);
  }

  @Get(':id')
  @Permissions('anexos:visualizar')
  @ApiOperation({ summary: 'Obter detalhe de uma relação' })
  findOne(@Param('id') id: string) {
    return this.service.findOne(+id);
  }

  @Patch(':id')
  @Permissions('anexos:editar')
  @ApiOperation({ summary: 'Atualizar relação' })
  @ApiBody({ type: UpdatePessoaAnexoDto })
  update(@Param('id') id: string, @Body() dto: UpdatePessoaAnexoDto) {
    return this.service.update(+id, dto);
  }

  @Delete(':id')
  @Permissions('anexos:eliminar')
  @ApiOperation({ summary: 'Remover relação' })
  remove(@Param('id') id: string) {
    return this.service.remove(+id);
  }
}
