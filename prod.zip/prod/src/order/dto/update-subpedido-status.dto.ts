import { IsEnum } from "class-validator";

export class UpdateSubPedidoStatusDto {
  @IsEnum(["PENDENTE", "ACEITO_LOJA", "EM_PREPARACAO", "PRONTO_PARA_RECOLHA", "ENTREGUE_AO_ESTAFETA", "CANCELADO"])
  status: string;
}
