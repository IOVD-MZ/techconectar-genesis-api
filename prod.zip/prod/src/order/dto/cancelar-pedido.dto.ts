import { IsString, IsEnum } from "class-validator";

export class CancelarPedidoDto {
  @IsEnum(["DESISTENCIA_CLIENTE", "SEM_STOCK", "ESTABELECIMENTO_FECHADO", "ESTAFETA_INDISPONIVEL", "ENDERECO_INCORRETO", "OUTRO"])
  motivo_categoria: string;

  @IsString()
  descricao_detalhada?: string;
}
