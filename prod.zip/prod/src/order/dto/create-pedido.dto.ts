import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNumber, IsArray, ValidateNested, IsString, IsOptional, Min } from 'class-validator';
import { Type } from 'class-transformer';

class ItemPedidoDto {
  @ApiProperty({ example: 1, description: 'ID do produto' })
  @IsNumber()
  produto_id: number;

  @ApiProperty({ example: 2, description: 'Quantidade' })
  @IsNumber()
  @Min(1)
  quantidade: number;
}

export class CreatePedidoDto {
  @ApiProperty({ example: 3, description: 'ID do cliente' })
  @IsNumber()
  cliente_id: number;

  @ApiProperty({
    example: [{ produto_id: 1, quantidade: 2 }, { produto_id: 4, quantidade: 3 }],
    description: 'Lista de itens do pedido',
    type: [ItemPedidoDto],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ItemPedidoDto)
  itens: ItemPedidoDto[];

  @ApiPropertyOptional({ example: 'Bairro 3, Songo', description: 'Endereço de entrega alternativo' })
  @IsOptional()
  @IsString()
  endereco_entrega_alternativo?: string;

  @ApiPropertyOptional({ example: 100, description: 'Taxa de entrega' })
  @IsOptional()
  @IsNumber()
  @Min(0)
  taxa_entrega?: number;

  @ApiPropertyOptional({ example: 'MPESA', enum: ['MPESA', 'EMOLA', 'CARTAO'] })
  @IsOptional()
  @IsString()
  metodo_pagamento?: string;
}
