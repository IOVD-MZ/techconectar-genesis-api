import { IsEnum } from "class-validator";

export class UpdatePedidoStatusDto {
  @IsEnum(["PENDENTE", "EM_PROCESSAMENTO", "PAGO", "CONCLUIDO", "CANCELADO"])
  status: string;
}
