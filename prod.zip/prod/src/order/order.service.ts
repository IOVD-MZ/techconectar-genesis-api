import { Injectable, BadRequestException, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Pedidos } from '../entities/Pedidos.entity';
import { SubPedidos } from '../entities/SubPedidos.entity';
import { PedidoItens } from '../entities/PedidoItens.entity';
import { Produtos } from '../entities/Produtos.entity';
import { Pagamentos } from '../entities/Pagamentos.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { CreatePedidoDto } from './dto/create-pedido.dto';
import { CancelarPedidoDto } from './dto/cancelar-pedido.dto';
import { EventsGateway } from '../events/events.gateway';

@Injectable()
export class OrderService {
  constructor(
    @InjectRepository(Pedidos) private pedidoRepo: Repository<Pedidos>,
    @InjectRepository(SubPedidos) private subRepo: Repository<SubPedidos>,
    @InjectRepository(PedidoItens) private itemRepo: Repository<PedidoItens>,
    @InjectRepository(Produtos) private produtoRepo: Repository<Produtos>,
    @InjectRepository(Pagamentos) private pagamentoRepo: Repository<Pagamentos>,
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
    private dataSource: DataSource,
    private eventsGateway: EventsGateway,
  ) {}

  // ---------- CRIAÇÃO DE PEDIDO (CORRIGIDO) ----------
  async create(createDto: CreatePedidoDto) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
    // Validar cliente usando idpessoa ou idusuario
    let cliente = await this.pessoaRepo.findOne({
      where: { idpessoa: createDto.cliente_id, tipo_pessoa: 'CLIENTE' },
    });
    if (!cliente) {
      cliente = await this.pessoaRepo.findOne({
        where: { idusuario: createDto.cliente_id, tipo_pessoa: 'CLIENTE' },
      });
    }
    if (!cliente) {
      throw new BadRequestException('Cliente inválido');
    }

      // 1. Criar pedido pai
      const pedido = this.pedidoRepo.create({
        cliente_id: createDto.cliente_id,
        total_produtos: '0',
        taxa_entrega: (createDto.taxa_entrega || 0).toString(),
        status_pedido: 'PENDENTE',
        endereco_entrega_alternativo: createDto.endereco_entrega_alternativo ?? null,
      });
      const savedPedido = await queryRunner.manager.save(pedido);

      // 2. Agrupar itens por fornecedor (simplificado: assume um único fornecedor)
      const primeiroItem = createDto.itens[0];
      const produto = await queryRunner.manager.findOne(Produtos, {
        where: { id_produto: primeiroItem.produto_id },
        select: { fornecedor_id: true },
      });
      if (!produto) throw new BadRequestException('Produto inválido');
      const fornecedorId = produto.fornecedor_id;
      if (fornecedorId === null || fornecedorId === undefined) {
        throw new BadRequestException('Produto não tem fornecedor associado');
      }

      // 3. Criar sub-pedido
      const subPedido = this.subRepo.create({
        pedido_pai_id: savedPedido.id_pedido,
        fornecedor_id: fornecedorId,
        subtotal_produtos: '0',
        status_sub_pedido: 'PENDENTE',
      });
      const savedSub = await queryRunner.manager.save(subPedido);

      // 4. Processar itens com lock de stock
      let totalPedido = 0;
      for (const itemDto of createDto.itens) {
        const produtoLock = await queryRunner.manager
          .createQueryBuilder(Produtos, 'p')
          .where('p.id_produto = :id', { id: itemDto.produto_id })
          .setLock('pessimistic_write')
          .getOne();

        if (!produtoLock) throw new BadRequestException(`Produto ${itemDto.produto_id} não encontrado`);
        if (produtoLock.stock < itemDto.quantidade) {
          throw new BadRequestException(`Estoque insuficiente para ${produtoLock.nome}`);
        }

        const preco = produtoLock.preco_promocional ? parseFloat(produtoLock.preco_promocional) : parseFloat(produtoLock.preco);
        const subtotal = preco * itemDto.quantidade;
        totalPedido += subtotal;

        const item = this.itemRepo.create({
          pedido_id: savedPedido.id_pedido,
          sub_pedido_id: savedSub.id_sub_pedido,
          produto_id: produtoLock.id_produto,
          nome_produto_snapshot: produtoLock.nome,
          quantidade: itemDto.quantidade,
          preco_unitario_historico: preco.toString(),
        });
        await queryRunner.manager.save(item);

        produtoLock.stock -= itemDto.quantidade;
        await queryRunner.manager.save(produtoLock);
      }

      // Atualizar totais
      await queryRunner.manager.update(Pedidos, savedPedido.id_pedido, {
        total_produtos: totalPedido.toString(),
      });
      await queryRunner.manager.update(SubPedidos, savedSub.id_sub_pedido, {
        subtotal_produtos: totalPedido.toString(),
      });

      await queryRunner.commitTransaction();

      if (createDto.metodo_pagamento) {
        await this.registrarPagamentoPendente(
          savedPedido.id_pedido,
          createDto.metodo_pagamento,
          totalPedido + (createDto.taxa_entrega || 0),
        );
      }

      this.eventsGateway.notifyUser(createDto.cliente_id, 'pedido-criado', {
        pedidoId: savedPedido.id_pedido,
        status: 'PENDENTE',
      });

      this.eventsGateway.notifyRoom('fornecedores', 'pedido-criado', {
        pedidoId: savedPedido.id_pedido,
        fornecedorId: fornecedorId,
      });

      return await this.findOne(savedPedido.id_pedido);
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  private async registrarPagamentoPendente(pedidoId: number, metodo: string, valor: number) {
    const pagamento = this.pagamentoRepo.create({
      pedido_id: pedidoId,
      metodo_pagamento: metodo,
      valor: valor.toString(),
      status_pagamento: 'PENDENTE',
    });
    await this.pagamentoRepo.save(pagamento);
  }

  // ---------- LISTAR PEDIDOS (com filtro para ADMIN/FORNECEDOR/CLIENTE) ----------
  async findAll(user?: any) {
    if (!user) {
      return [];
    }
    const papeis = user.papeis || [];

    if (papeis.includes('ADMIN')) {
      return await this.pedidoRepo.find({
        relations: {
          cliente: true,
          subPedidos: { itens: { produto: true } },
          pagamentos: true,
          entregas: true,
        },
        order: { data_pedido: 'DESC' },
      });
    }

    if (papeis.includes('FORNECEDOR')) {
      const pedidos = await this.pedidoRepo.find({
        relations: {
          cliente: true,
          subPedidos: { itens: { produto: true } },
          pagamentos: true,
          entregas: true,
        },
        order: { data_pedido: 'DESC' },
      });
      return pedidos.filter(p =>
        p.subPedidos?.some(sp => sp.fornecedor_id === user.idpessoa)
      );
    }

    if (papeis.includes('CLIENTE')) {
      return await this.pedidoRepo.find({
        where: { cliente_id: user.idpessoa },
        relations: {
          cliente: true,
          subPedidos: { itens: { produto: true } },
          pagamentos: true,
          entregas: true,
        },
        order: { data_pedido: 'DESC' },
      });
    }

    return [];
  }

  // ---------- DETALHAR PEDIDO (com validação de propriedade) ----------
  async findOne(id: number, user?: any) {
    const pedido = await this.pedidoRepo.findOne({
      where: { id_pedido: id },
      relations: {
        cliente: true,
        subPedidos: { itens: { produto: true } },
        pagamentos: true,
        entregas: true,
      },
    });
    if (!pedido) throw new NotFoundException('Pedido não encontrado');

    if (user) {
      const papeis = user.papeis || [];
      if (papeis.includes('CLIENTE') && pedido.cliente_id !== user.idpessoa) {
        throw new ForbiddenException('Não tem permissão para ver este pedido');
      }
      if (papeis.includes('FORNECEDOR')) {
        const pertence = pedido.subPedidos?.some(sp => sp.fornecedor_id === user.idpessoa);
        if (!pertence) {
          throw new ForbiddenException('Este pedido não contém produtos da sua loja');
        }
      }
    }
    return pedido;
  }

  // ---------- ATUALIZAR STATUS DO PEDIDO (nível pedido) – apenas ADMIN ----------
  async updateStatusPedido(id: number, status: string, user?: any) {
    const pedido = await this.findOne(id, user);
    if (user && !user.papeis.includes('ADMIN')) {
      throw new ForbiddenException('Apenas ADMIN pode alterar status do pedido pai');
    }
    await this.pedidoRepo.update(id, { status_pedido: status });
    this.eventsGateway.notifyUser(pedido.cliente_id, 'pedido-status-changed', {
      pedidoId: id,
      novoStatus: status,
    });
    return this.findOne(id, user);
  }

  // ---------- ATUALIZAR STATUS DO SUB-PEDIDO (nível fornecedor) ----------
  async updateSubPedidoStatus(subId: number, status: string, user?: any) {
    const sub = await this.subRepo.findOne({
      where: { id_sub_pedido: subId },
      relations: { pedidoPai: true },
    });
    if (!sub) throw new NotFoundException('Sub-pedido não encontrado');

    if (user) {
      const papeis = user.papeis || [];
      if (papeis.includes('FORNECEDOR') && sub.fornecedor_id !== user.idpessoa) {
        throw new ForbiddenException('Este sub-pedido não pertence à sua loja');
      }
    }

    const statusPermitidos = ['PENDENTE', 'ACEITO_LOJA', 'EM_PREPARACAO', 'PRONTO_PARA_RECOLHA', 'ENTREGUE_AO_ESTAFETA', 'CANCELADO'];
    if (!statusPermitidos.includes(status)) {
      throw new BadRequestException(`Status inválido. Valores permitidos: ${statusPermitidos.join(', ')}`);
    }

    await this.subRepo.update(subId, { status_sub_pedido: status });

    this.eventsGateway.notifyUser(sub.pedidoPai.cliente_id, 'pedido-status-changed', {
      pedidoId: sub.pedido_pai_id,
      novoStatus: status,
      subPedidoId: subId,
    });
    this.eventsGateway.notifyRoom('fornecedores', 'pedido-status-changed', {
      pedidoId: sub.pedido_pai_id,
      subPedidoId: subId,
      novoStatus: status,
    });

    return this.findOne(sub.pedido_pai_id, user);
  }

  // ---------- CANCELAR PEDIDO (nível pedido) – ADMIN e FORNECEDOR ----------
  async cancelarPedido(id: number, cancelDto: CancelarPedidoDto, userId: number, user: any) {
    const pedido = await this.findOne(id, user);
    const papeis = user.papeis || [];

    if (!papeis.includes('ADMIN') && !papeis.includes('FORNECEDOR')) {
      throw new ForbiddenException('Não tem permissão para cancelar este pedido');
    }

    if (papeis.includes('FORNECEDOR')) {
      const pertence = pedido.subPedidos?.some(sp => sp.fornecedor_id === user.idpessoa);
      if (!pertence) {
        throw new ForbiddenException('Este pedido não contém produtos da sua loja');
      }
    }

    if (pedido.status_pedido === 'CONCLUIDO' || pedido.status_pedido === 'CANCELADO') {
      throw new BadRequestException('Pedido já não pode ser cancelado');
    }

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await queryRunner.manager.update(Pedidos, id, { status_pedido: 'CANCELADO' });
      await queryRunner.manager.update(SubPedidos, { pedido_pai_id: id }, { status_sub_pedido: 'CANCELADO' });

      const itens = await queryRunner.manager.find(PedidoItens, {
        where: { pedido_id: id },
        relations: { produto: true },
      });
      for (const item of itens) {
        const produto = item.produto;
        await queryRunner.manager.update(Produtos, produto.id_produto, {
          stock: produto.stock + item.quantidade,
        });
      }

      await queryRunner.manager.query(
        `INSERT INTO cancelamento_log (pedido_id, cancelado_por_id, motivo_categoria, descricao_detalhada)
         VALUES (?, ?, ?, ?)`,
        [id, userId, cancelDto.motivo_categoria, cancelDto.descricao_detalhada ?? null],
      );

      await queryRunner.commitTransaction();

      this.eventsGateway.notifyUser(pedido.cliente_id, 'pedido-cancelado', {
        pedidoId: id,
        motivo: cancelDto.motivo_categoria,
      });

      return this.findOne(id, user);
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  // ---------- MÉTODO ADICIONAL: listar sub-pedidos por fornecedor ----------
  async findSubPedidosByFornecedor(fornecedorId: number) {
    return await this.subRepo.find({
      where: { fornecedor_id: fornecedorId },
      relations: { pedidoPai: true, itens: { produto: true } },
      order: { criado_em: 'DESC' },
    });
  }
}
