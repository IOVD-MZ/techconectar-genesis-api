import { Controller, Get, Post, Body, Patch, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { OrderService } from './order.service';
import { CreatePedidoDto } from './dto/create-pedido.dto';
import { UpdatePedidoStatusDto } from './dto/update-pedido-status.dto';
import { UpdateSubPedidoStatusDto } from './dto/update-subpedido-status.dto';
import { CancelarPedidoDto } from './dto/cancelar-pedido.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';
import { PermissionsGuard } from '../auth/guards/permissions.guard';

@ApiTags('orders')
@Controller('orders')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class OrderController {
  constructor(private readonly orderService: OrderService) {}

  @Post()
  @Permissions('pedidos:criar')
  @ApiOperation({ summary: 'Criar um novo pedido' })
  @ApiBody({ type: CreatePedidoDto })
  @ApiResponse({ status: 201, description: 'Pedido criado' })
  @ApiResponse({ status: 500, description: 'Erro interno (já corrigido)' })
  create(@Body() createDto: CreatePedidoDto, @Request() req) {
    if (req.user.papeis.includes('CLIENTE')) {
      createDto.cliente_id = req.user.idpessoa;
    }
    return this.orderService.create(createDto);
  }

  @Get()
  @Permissions('pedidos:visualizar')
  @ApiOperation({ summary: 'Listar pedidos (filtrado por papel)' })
  @ApiResponse({ status: 200, description: 'Lista de pedidos' })
  findAll(@Request() req) {
    return this.orderService.findAll(req.user);
  }

  @Get(':id')
  @Permissions('pedidos:visualizar')
  @ApiOperation({ summary: 'Obter pedido por ID' })
  @ApiResponse({ status: 200, description: 'Pedido encontrado' })
  @ApiResponse({ status: 403, description: 'Sem permissão para ver este pedido' })
  @ApiResponse({ status: 404, description: 'Pedido não encontrado' })
  findOne(@Param('id') id: string, @Request() req) {
    return this.orderService.findOne(+id, req.user);
  }

  @Patch(':id/status')
  @Permissions('pedidos:atualizar_status')
  @ApiOperation({ summary: 'Atualizar status do pedido (nível pedido - apenas ADMIN)' })
  @ApiBody({ type: UpdatePedidoStatusDto })
  @ApiResponse({ status: 200, description: 'Status atualizado' })
  updateStatusPedido(@Param('id') id: string, @Body() dto: UpdatePedidoStatusDto, @Request() req) {
    return this.orderService.updateStatusPedido(+id, dto.status, req.user);
  }

  @Patch('subpedido/:subId/status')
  @Permissions('pedidos:aceitar_recusar')
  @ApiOperation({ summary: 'Atualizar status de sub-pedido (nível fornecedor)' })
  @ApiBody({ type: UpdateSubPedidoStatusDto })
  @ApiResponse({ status: 200, description: 'Sub-pedido atualizado' })
  updateSubPedidoStatus(@Param('subId') subId: string, @Body() dto: UpdateSubPedidoStatusDto, @Request() req) {
    return this.orderService.updateSubPedidoStatus(+subId, dto.status, req.user);
  }

  @Post(':id/cancelar')
  @Permissions('pedidos:cancelar')
  @ApiOperation({ summary: 'Cancelar pedido (nível pedido - ADMIN/FORNECEDOR)' })
  @ApiBody({ type: CancelarPedidoDto })
  @ApiResponse({ status: 200, description: 'Pedido cancelado' })
  cancelarPedido(@Param('id') id: string, @Body() dto: CancelarPedidoDto, @Request() req) {
    return this.orderService.cancelarPedido(+id, dto, req.user.idpessoa, req.user);
  }

  @Get('fornecedor/:fornecedorId/subpedidos')
  @Permissions('pedidos:visualizar')
  @ApiOperation({ summary: 'Listar sub-pedidos de um fornecedor' })
  @ApiResponse({ status: 200, description: 'Lista de sub-pedidos' })
  findSubPedidosByFornecedor(@Param('fornecedorId') fornecedorId: string) {
    return this.orderService.findSubPedidosByFornecedor(+fornecedorId);
  }
}
