import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderService } from './order.service';
import { OrderController } from './order.controller';
import { Pedidos } from '../entities/Pedidos.entity';
import { SubPedidos } from '../entities/SubPedidos.entity';
import { PedidoItens } from '../entities/PedidoItens.entity';
import { Produtos } from '../entities/Produtos.entity';
import { Pagamentos } from '../entities/Pagamentos.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { EventsModule } from '../events/events.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Pedidos, SubPedidos, PedidoItens, Produtos, Pagamentos, Pessoa]),
    EventsModule,
  ],
  controllers: [OrderController],
  providers: [OrderService],
})
export class OrderModule {}
