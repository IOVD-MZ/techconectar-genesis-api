import { Controller, Post, Body, Get, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { AvaliacoesService } from './avaliacoes.service';
import { CreateAvaliacaoDto } from './dto/create-avaliacao.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('avaliacoes')
@Controller('avaliacoes')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class AvaliacoesController {
  constructor(private readonly avaliacoesService: AvaliacoesService) {}

  @Post()
  @Permissions('avaliacoes:criar')
  @ApiOperation({ summary: 'Criar avaliação' })
  @ApiBody({ type: CreateAvaliacaoDto })
  @ApiResponse({ status: 201, description: 'Avaliação criada' })
  create(@Body() createDto: CreateAvaliacaoDto, @Request() req) {
    return this.avaliacoesService.create(req.user.idpessoa || req.user.idusuario, createDto);
  }

  @Get()
  @Permissions('avaliacoes:visualizar')
  @ApiOperation({ summary: 'Listar avaliações (filtrado por papel)' })
  @ApiResponse({ status: 200, description: 'Lista de avaliações' })
  findAll(@Request() req) {
    return this.avaliacoesService.findAll(req.user);
  }

  @Get('estabelecimento/:id')
  @Permissions('avaliacoes:visualizar')
  @ApiOperation({ summary: 'Avaliações de um estabelecimento' })
  findByEstabelecimento(@Param('id') id: string) {
    return this.avaliacoesService.findByEstabelecimento(+id);
  }

  @Get('estafeta/:id')
  @Permissions('avaliacoes:visualizar')
  @ApiOperation({ summary: 'Avaliações de um estafeta' })
  findByEstafeta(@Param('id') id: string) {
    return this.avaliacoesService.findByEstafeta(+id);
  }
}
