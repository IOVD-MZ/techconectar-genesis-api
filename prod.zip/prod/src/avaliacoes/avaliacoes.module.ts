import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AvaliacoesService } from './avaliacoes.service';
import { AvaliacoesController } from './avaliacoes.controller';
import { Avaliacoes } from '../entities/Avaliacoes.entity';
import { Pedidos } from '../entities/Pedidos.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Avaliacoes, Pedidos])],
  controllers: [AvaliacoesController],
  providers: [AvaliacoesService],
})
export class AvaliacoesModule {}
