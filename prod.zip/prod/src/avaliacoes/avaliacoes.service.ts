import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Avaliacoes } from '../entities/Avaliacoes.entity';
import { Pedidos } from '../entities/Pedidos.entity';
import { CreateAvaliacaoDto } from './dto/create-avaliacao.dto';

@Injectable()
export class AvaliacoesService {
  constructor(
    @InjectRepository(Avaliacoes) private avaliacaoRepo: Repository<Avaliacoes>,
    @InjectRepository(Pedidos) private pedidoRepo: Repository<Pedidos>,
  ) {}

  async create(clienteId: number, createDto: CreateAvaliacaoDto) {
    // Verificar se o pedido existe e pertence ao cliente
    const pedido = await this.pedidoRepo.findOne({
      where: { id_pedido: createDto.pedido_id },
    });
    if (!pedido) throw new NotFoundException('Pedido não encontrado');
    // Comparar usando idpessoa (clienteId já é idpessoa vindo do controller)
    if (Number(pedido.cliente_id) !== Number(clienteId)) {
      throw new ForbiddenException('Não pode avaliar pedidos de outro cliente');
    }

    const avaliacao = this.avaliacaoRepo.create({
      pedido_id: createDto.pedido_id,
      cliente_id: clienteId,
      estabelecimento_id: createDto.estabelecimento_id || null,
      produto_id: createDto.produto_id || null,
      estafeta_id: createDto.estafeta_id || null,
      classificacao: createDto.classificacao,
      comentario: createDto.comentario || null,
    });
    return await this.avaliacaoRepo.save(avaliacao);
  }

  async findAll(user: any) {
    const papeis = user.papeis || [];
    if (papeis.includes('ADMIN')) {
      return await this.avaliacaoRepo.find({ relations: { cliente: true, estabelecimento: true, produto: true, estafeta: true } });
    }
    if (papeis.includes('CLIENTE')) {
      return await this.avaliacaoRepo.find({ where: { cliente_id: user.idusuario }, relations: { cliente: true, estabelecimento: true, produto: true, estafeta: true } });
    }
    return [];
  }

  async findByEstabelecimento(id: number) {
    return await this.avaliacaoRepo.find({ where: { estabelecimento_id: id }, relations: { cliente: true, produto: true } });
  }

  async findByEstafeta(id: number) {
    return await this.avaliacaoRepo.find({ where: { estafeta_id: id }, relations: { cliente: true, estabelecimento: true } });
  }
}
