import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNumber, IsString, IsOptional, Min, Max } from 'class-validator';

export class CreateAvaliacaoDto {
  @ApiProperty({ description: 'ID do pedido', example: 1 })
  @IsNumber()
  pedido_id: number;

  @ApiPropertyOptional({ description: 'ID do estabelecimento', example: 1 })
  @IsOptional()
  @IsNumber()
  estabelecimento_id?: number;

  @ApiPropertyOptional({ description: 'ID do produto', example: 1 })
  @IsOptional()
  @IsNumber()
  produto_id?: number;

  @ApiPropertyOptional({ description: 'ID do estafeta', example: 2 })
  @IsOptional()
  @IsNumber()
  estafeta_id?: number;

  @ApiProperty({ description: 'Classificação (1-5)', example: 5, minimum: 1, maximum: 5 })
  @IsNumber()
  @Min(1)
  @Max(5)
  classificacao: number;

  @ApiPropertyOptional({ description: 'Comentário', example: 'Ótimo serviço!' })
  @IsOptional()
  @IsString()
  comentario?: string;
}
