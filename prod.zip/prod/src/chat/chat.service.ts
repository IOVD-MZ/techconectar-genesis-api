import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MensagensChat } from '../entities/MensagensChat.entity';
import { Pedidos } from '../entities/Pedidos.entity';

@Injectable()
export class ChatService {
  constructor(
    @InjectRepository(MensagensChat)
    private mensagemRepo: Repository<MensagensChat>,
    @InjectRepository(Pedidos)
    private pedidoRepo: Repository<Pedidos>,
  ) {}

  async listarPorPedido(pedidoId: number, user: any) {
    if (!pedidoId || isNaN(pedidoId)) {
      throw new NotFoundException('Pedido inválido');
    }

    const pedido = await this.pedidoRepo.findOne({
      where: { id_pedido: pedidoId },
      select: { id_pedido: true, cliente_id: true },
    });
    if (!pedido) throw new NotFoundException('Pedido não encontrado');

    // Validação de acesso: ADMIN, dono do pedido, ou fornecedor do sub-pedido
    const papeis = user?.papeis || [];
    const isAdmin = papeis.includes('ADMIN');
    const isClienteDono = Number(pedido.cliente_id) === Number(user.idpessoa);

    if (!isAdmin && !isClienteDono) {
      // Verificar se é fornecedor deste pedido
      const sub = await this.pedidoRepo.manager.query(
        `SELECT 1 FROM sub_pedidos WHERE pedido_pai_id = ? AND fornecedor_id = ? LIMIT 1`,
        [pedidoId, user.idpessoa],
      );
      if (!sub || sub.length === 0) {
        throw new ForbiddenException('Sem permissão para ver o chat deste pedido');
      }
    }

    const mensagens = await this.mensagemRepo.find({
      where: { pedido_id: pedidoId },
      order: { data_envio: 'ASC' },
      relations: { remetente: true },
    });

    return mensagens;
  }
}
