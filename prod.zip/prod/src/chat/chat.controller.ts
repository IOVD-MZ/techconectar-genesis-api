import { Controller, Get, Post, Body, Param, ParseIntPipe, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { ChatService } from './chat.service';
import { CreateMensagemDto } from './dto/create-mensagem.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('chat')
@Controller('pedidos')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT-auth')
export class ChatController {
  constructor(private readonly chatService: ChatService) {}

  @Get(':id/chat')
  @ApiOperation({ summary: 'Listar mensagens de chat de um pedido' })
  async listar(@Param('id', ParseIntPipe) id: number, @Request() req) {
    return this.chatService.listarPorPedido(id, req.user);
  }

  @Post(':id/chat')
  @ApiOperation({ summary: 'Enviar mensagem de chat num pedido' })
  @ApiBody({ type: CreateMensagemDto })
  async enviar(@Param('id', ParseIntPipe) id: number, @Body() dto: CreateMensagemDto, @Request() req) {
    return this.chatService.enviarMensagem(id, dto, req.user);
  }
}
