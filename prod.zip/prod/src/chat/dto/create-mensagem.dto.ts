import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, MaxLength, IsEnum, IsOptional } from 'class-validator';

export class CreateMensagemDto {
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(2000) mensagem: string;
  @ApiProperty({ enum: ['CLIENTE','ESTAFETA','FORNECEDOR','SISTEMA'], required: false })
  @IsOptional() @IsEnum(['CLIENTE','ESTAFETA','FORNECEDOR','SISTEMA']) tipo_remetente?: string;
}
