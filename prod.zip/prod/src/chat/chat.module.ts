import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ChatService } from './chat.service';
import { ChatController } from './chat.controller';
import { MensagensChat } from '../entities/MensagensChat.entity';
import { Pedidos } from '../entities/Pedidos.entity';

@Module({
  imports: [TypeOrmModule.forFeature([MensagensChat, Pedidos])],
  controllers: [ChatController],
  providers: [ChatService],
})
export class ChatModule {}
