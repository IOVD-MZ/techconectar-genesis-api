import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsString, IsNumber, IsOptional, MaxLength } from 'class-validator';

export class CreateContactoDto {
  @ApiProperty() @IsNumber() idpessoa: number;
  @ApiProperty({ enum: ['TELEFONE', 'EMAIL', 'WHATSAPP'] })
  @IsEnum(['TELEFONE', 'EMAIL', 'WHATSAPP']) tipo_contacto: string;
  @ApiProperty() @IsString() @MaxLength(255) descricao: string;
}

export class UpdateContactoDto {
  @ApiPropertyOptional({ enum: ['TELEFONE', 'EMAIL', 'WHATSAPP'] })
  @IsOptional() @IsEnum(['TELEFONE', 'EMAIL', 'WHATSAPP']) tipo_contacto?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(255) descricao?: string;
}
