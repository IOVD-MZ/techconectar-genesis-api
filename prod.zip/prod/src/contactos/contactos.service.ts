import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Contacto } from '../entities/Contacto.entity';
import { Pessoa } from '../entities/Pessoa.entity';

@Injectable()
export class ContactosService {
  constructor(
    @InjectRepository(Contacto) private contactoRepo: Repository<Contacto>,
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
  ) {}

  async findByPessoa(idpessoa: number) {
    if (!idpessoa || isNaN(idpessoa)) throw new NotFoundException('Pessoa inválida');
    const pessoa = await this.pessoaRepo.findOne({
      where: { idpessoa },
      select: { idpessoa: true, nome_completo: true, tipo_pessoa: true },
    });
    if (!pessoa) throw new NotFoundException('Pessoa não encontrada');

    const contactos = await this.contactoRepo.find({
      where: { idpessoa },
      order: { idcontacto: 'ASC' },
    });

    return {
      pessoa,
      contactos: contactos.map((c) => ({
        idcontacto: c.idcontacto,
        tipo_contacto: c.tipo_contacto,
        descricao: c.descricao,
        data_criacao: c.data_criacao,
        data_modificacao: c.data_modificacao,
      })),
    };
  }

  async criar(dto: { idpessoa: number; tipo_contacto: string; descricao: string }) {
    const contacto = this.contactoRepo.create(dto);
    return await this.contactoRepo.save(contacto);
  }

  async atualizar(id: number, dto: any, user: any) {
    const contacto = await this.contactoRepo.findOne({ where: { idcontacto: id } });
    if (!contacto) throw new NotFoundException('Contacto não encontrado');

    const papeis = user.papeis || [];
    const isAdmin = papeis.includes('ADMIN');
    const isProprio = Number(user.idpessoa) === Number(contacto.idpessoa);
    if (!isAdmin && !isProprio) throw new ForbiddenException('Sem permissão');

    await this.contactoRepo.update(id, dto);
    return this.contactoRepo.findOne({ where: { idcontacto: id } });
  }

  async remover(id: number, user: any) {
    const contacto = await this.contactoRepo.findOne({ where: { idcontacto: id } });
    if (!contacto) throw new NotFoundException('Contacto não encontrado');

    const papeis = user.papeis || [];
    const isAdmin = papeis.includes('ADMIN');
    const isProprio = Number(user.idpessoa) === Number(contacto.idpessoa);
    if (!isAdmin && !isProprio) throw new ForbiddenException('Sem permissão');

    await this.contactoRepo.remove(contacto);
    return { message: 'Contacto removido' };
  }
}
