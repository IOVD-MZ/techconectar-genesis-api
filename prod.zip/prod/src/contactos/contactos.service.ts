import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Contacto } from '../entities/Contacto.entity';
import { Pessoa } from '../entities/Pessoa.entity';

@Injectable()
export class ContactosService {
  constructor(
    @InjectRepository(Contacto) private contactoRepo: Repository<Contacto>,
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
  ) {}

  async findByPessoa(idpessoa: number) {
    if (!idpessoa || isNaN(idpessoa)) {
      throw new NotFoundException('Pessoa inválida');
    }

    const pessoa = await this.pessoaRepo.findOne({
      where: { idpessoa },
      select: { idpessoa: true, nome_completo: true, tipo_pessoa: true },
    });
    if (!pessoa) throw new NotFoundException('Pessoa não encontrada');

    const contactos = await this.contactoRepo.find({
      where: { idpessoa },
      order: { idcontacto: 'ASC' },
    });

    return {
      pessoa,
      contactos: contactos.map((c) => ({
        idcontacto: c.idcontacto,
        tipo_contacto: c.tipo_contacto,
        descricao: c.descricao,
        data_criacao: c.data_criacao,
        data_modificacao: c.data_modificacao,
      })),
    };
  }
}
