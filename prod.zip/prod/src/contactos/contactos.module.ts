import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContactosService } from './contactos.service';
import { ContactosController } from './contactos.controller';
import { Contacto } from '../entities/Contacto.entity';
import { Pessoa } from '../entities/Pessoa.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Contacto, Pessoa])],
  controllers: [ContactosController],
  providers: [ContactosService],
})
export class ContactosModule {}
