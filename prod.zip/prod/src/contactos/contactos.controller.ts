import {
  Controller, Get, Post, Patch, Delete, Body, Param, ParseIntPipe, UseGuards, Request, ForbiddenException,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { ContactosService } from './contactos.service';
import { CreateContactoDto, UpdateContactoDto } from './dto/create-contacto.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('contactos')
@Controller('contactos')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT-auth')
export class ContactosController {
  constructor(private readonly contactosService: ContactosService) {}

  @Get('pessoa/:idpessoa')
  @ApiOperation({ summary: 'Listar contactos de uma pessoa' })
  async findByPessoa(@Param('idpessoa', ParseIntPipe) idpessoa: number) {
    return this.contactosService.findByPessoa(idpessoa);
  }

  @Post()
  @ApiOperation({ summary: 'Criar contacto' })
  @ApiBody({ type: CreateContactoDto })
  async criar(@Body() dto: CreateContactoDto, @Request() req) {
    const papeis = req.user.papeis || [];
    const isAdmin = papeis.includes('ADMIN');
    const isProprio = Number(req.user.idpessoa) === Number(dto.idpessoa);
    if (!isAdmin && !isProprio) throw new ForbiddenException('Sem permissão');
    return this.contactosService.criar(dto);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar contacto' })
  @ApiBody({ type: UpdateContactoDto })
  async atualizar(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateContactoDto, @Request() req) {
    return this.contactosService.atualizar(id, dto, req.user);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Remover contacto' })
  async remover(@Param('id', ParseIntPipe) id: number, @Request() req) {
    return this.contactosService.remover(id, req.user);
  }
}
