import { Controller, Get, Param, ParseIntPipe, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam } from '@nestjs/swagger';
import { ContactosService } from './contactos.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('contactos')
@Controller('contactos')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT-auth')
export class ContactosController {
  constructor(private readonly contactosService: ContactosService) {}

  @Get('pessoa/:idpessoa')
  @ApiOperation({ summary: 'Listar contactos de uma pessoa' })
  @ApiParam({ name: 'idpessoa', description: 'ID da pessoa' })
  @ApiResponse({ status: 200, description: 'Lista de contactos' })
  async findByPessoa(@Param('idpessoa', ParseIntPipe) idpessoa: number) {
    return this.contactosService.findByPessoa(idpessoa);
  }
}
