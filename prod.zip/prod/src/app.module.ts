import { Module } from '@nestjs/common';
import { AnexoModule } from './anexo/anexo.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { CatalogModule } from './catalog/catalog.module';
import { OrderModule } from './order/order.module';
import { PaymentModule } from './payment/payment.module';
import { DeliveryModule } from './delivery/delivery.module';
import { AdminModule } from './admin/admin.module';
import { EventsModule } from './events/events.module';
import { RequisicoesModule } from './requisicoes/requisicoes.module';
import { AvaliacoesModule } from './avaliacoes/avaliacoes.module';
import { CupoesModule } from './cupoes/cupoes.module';
import { CarrinhoModule } from './carrinho/carrinho.module';
import { FavoritosModule } from './favoritos/favoritos.module';
import { PessoaAnexosModule } from './pessoa-anexos/pessoa-anexos.module';
import { ProdutoAnexosModule } from './produto-anexos/produto-anexos.module';
import { VendasModule } from './vendas/vendas.module';
import { PessoasModule } from './pessoas/pessoas.module';
import { ClientesModule } from './clientes/clientes.module';
import { EstabelecimentosModule } from './estabelecimentos/estabelecimentos.module';
import { BannersModule } from './banners/banners.module';
import { ChatModule } from './chat/chat.module';
import { ContactosModule } from './contactos/contactos.module';
import { PerfisModule } from './perfis/perfis.module';

@Module({
  imports: [
    AnexoModule,
    ConfigModule.forRoot({ isGlobal: true, envFilePath: '.env' }),
    TypeOrmModule.forRootAsync({
      imports: [
    AnexoModule,ConfigModule],
      useFactory: (config: ConfigService) => ({
        type: 'mysql',
        host: config.get('DB_HOST'),
        port: +config.get('DB_PORT'),
        username: config.get('DB_USERNAME'),
        password: config.get('DB_PASSWORD'),
        database: config.get('DB_NAME'),
        entities: [__dirname + '/**/*.entity{.ts,.js}'],
        synchronize: false,
        logging: true,
      }),
      inject: [ConfigService],
    }),
    AuthModule,
    CatalogModule,
    OrderModule,
    PaymentModule,
    DeliveryModule,
    AdminModule,
    EventsModule,
    RequisicoesModule,
    AvaliacoesModule,
    CupoesModule,
    CarrinhoModule,
    FavoritosModule,
    PessoaAnexosModule,
    ProdutoAnexosModule,
    VendasModule,
    PessoasModule,
    ClientesModule,
    EstabelecimentosModule,
    BannersModule,
    ChatModule,
    ContactosModule,
    PerfisModule,
  ],
})
export class AppModule {}
