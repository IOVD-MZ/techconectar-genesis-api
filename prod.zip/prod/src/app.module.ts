import { Module } from '@nestjs/common';
import { AnexoModule } from './anexo/anexo.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { CatalogModule } from './catalog/catalog.module';
import { OrderModule } from './order/order.module';
import { PaymentModule } from './payment/payment.module';
import { DeliveryModule } from './delivery/delivery.module';
import { AdminModule } from './admin/admin.module';
import { EventsModule } from './events/events.module';
import { RequisicoesModule } from './requisicoes/requisicoes.module';
import { AvaliacoesModule } from './avaliacoes/avaliacoes.module';
import { CupoesModule } from './cupoes/cupoes.module';
import { CarrinhoModule } from './carrinho/carrinho.module';
import { FavoritosModule } from './favoritos/favoritos.module';
import { PessoaAnexosModule } from './pessoa-anexos/pessoa-anexos.module';
import { ProdutoAnexosModule } from './produto-anexos/produto-anexos.module';
import { VendasModule } from './vendas/vendas.module';

@Module({
  imports: [
    AnexoModule,
    ConfigModule.forRoot({ isGlobal: true, envFilePath: '.env' }),
    TypeOrmModule.forRootAsync({
      imports: [
    AnexoModule,ConfigModule],
      useFactory: (config: ConfigService) => ({
        type: 'mysql',
        host: config.get('DB_HOST'),
        port: +config.get('DB_PORT'),
        username: config.get('DB_USERNAME'),
        password: config.get('DB_PASSWORD'),
        database: config.get('DB_NAME'),
        entities: [__dirname + '/**/*.entity{.ts,.js}'],
        synchronize: false,
        logging: true,
      }),
      inject: [ConfigService],
    }),
    AuthModule,
    CatalogModule,
    OrderModule,
    PaymentModule,
    DeliveryModule,
    AdminModule,
    EventsModule,
    RequisicoesModule,
    AvaliacoesModule,
    CupoesModule,
    CarrinhoModule,
    FavoritosModule,
    PessoaAnexosModule,
    ProdutoAnexosModule,
    VendasModule,
  ],
})
export class AppModule {}
