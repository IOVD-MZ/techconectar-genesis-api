import { Controller, Post, Body, Get, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { PaymentService } from './payment.service';
import { CreatePagamentoDto } from './dto/create-pagamento.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';
import { PermissionsGuard } from '../auth/guards/permissions.guard';

@ApiTags('payments')
@Controller('payments')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class PaymentController {
  constructor(private readonly paymentService: PaymentService) {}

  @Post()
  @Permissions('pagamentos:criar')
  @ApiOperation({ summary: 'Registrar pagamento de pedido' })
  @ApiBody({ type: CreatePagamentoDto })
  @ApiResponse({ status: 201, description: 'Pagamento registado' })
  create(@Body() createDto: CreatePagamentoDto, @Request() req) {
    // Verificar se o cliente é dono do pedido (para evitar fraude)
    return this.paymentService.create(createDto, req.user);
  }

  @Get('pedido/:pedidoId')
  @Permissions('pagamentos:visualizar')
  @ApiOperation({ summary: 'Consultar pagamento por pedido' })
  @ApiResponse({ status: 200, description: 'Pagamento encontrado' })
  findByPedido(@Param('pedidoId') pedidoId: string, @Request() req) {
    return this.paymentService.findByPedido(+pedidoId, req.user);
  }

  @Post('webhook/:provider')
  @ApiOperation({ summary: 'Webhook de pagamento (público)' })
  @ApiResponse({ status: 200, description: 'Webhook processado' })
  async webhook(@Param('provider') provider: string, @Body() payload: any) {
    return this.paymentService.handleWebhook(provider, payload);
  }
}
