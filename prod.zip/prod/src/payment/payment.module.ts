import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { PaymentService } from "./payment.service";
import { PaymentController } from "./payment.controller";
import { Pagamentos } from "../entities/Pagamentos.entity";
import { Pedidos } from "../entities/Pedidos.entity";

@Module({
  imports: [TypeOrmModule.forFeature([Pagamentos, Pedidos])],
  controllers: [PaymentController],
  providers: [PaymentService],
})
export class PaymentModule {}
