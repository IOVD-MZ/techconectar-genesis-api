import { Injectable, BadRequestException, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Pagamentos } from '../entities/Pagamentos.entity';
import { Pedidos } from '../entities/Pedidos.entity';
import { CreatePagamentoDto } from './dto/create-pagamento.dto';

@Injectable()
export class PaymentService {
  constructor(
    @InjectRepository(Pagamentos) private pagamentoRepo: Repository<Pagamentos>,
    @InjectRepository(Pedidos) private pedidoRepo: Repository<Pedidos>,
    private dataSource: DataSource,
  ) {}

  async create(createDto: CreatePagamentoDto, user?: any) {
    const pedido = await this.pedidoRepo.findOne({
      where: { id_pedido: createDto.pedido_id },
      relations: { cliente: true },
    });
    if (!pedido) throw new NotFoundException('Pedido não encontrado');

    if (user && user.papeis && user.papeis.includes('CLIENTE')) {
      if (pedido.cliente_id !== user.idusuario) {
        throw new ForbiddenException('Não é dono deste pedido');
      }
    }

    const metodosValidos = ['EMOLA', 'MPESA', 'CARTAO', 'NUMERARIO_ENTREGA', 'POS_ENTREGA'];
    if (!metodosValidos.includes(createDto.metodo_pagamento)) {
      throw new BadRequestException(`Método de pagamento inválido. Valores permitidos: ${metodosValidos.join(', ')}`);
    }

    await this.dataSource.query(
      `CALL sp_registar_pagamento(?, ?, ?, ?, ?)`,
      [
        createDto.pedido_id,
        createDto.metodo_pagamento,
        createDto.valor,
        createDto.referencia_transacao || null,
        createDto.numero_conta_pagador || null,
      ],
    );

    const pagamento = await this.pagamentoRepo.findOne({
      where: { pedido_id: createDto.pedido_id },
      order: { id_pagamento: 'DESC' },
    });
    return pagamento;
  }

  async findByPedido(pedidoId: number, user?: any) {
    const pedido = await this.pedidoRepo.findOne({
      where: { id_pedido: pedidoId },
      relations: { cliente: true },
    });
    if (!pedido) throw new NotFoundException('Pedido não encontrado');

    if (user && user.papeis && user.papeis.includes('CLIENTE')) {
      if (pedido.cliente_id !== user.idusuario) {
        throw new ForbiddenException('Não é dono deste pedido');
      }
    }

    return await this.pagamentoRepo.find({
      where: { pedido_id: pedidoId },
      order: { criado_em: 'DESC' },
    });
  }

  async handleWebhook(provider: string, payload: any) {
    const refExterna = payload.TransactionID || payload.reference || payload.id;
    if (refExterna) {
      const existente = await this.pagamentoRepo.findOne({
        where: { referencia_externa: refExterna },
      });
      if (existente) return { status: 'ignored', message: 'Transação já processada' };
    }

    const pedidoId = payload.orderId || payload.pedido_id || payload.order_id;
    const metodo = provider.toUpperCase();
    const valor = payload.amount || payload.valor || 0;
    const referencia = refExterna;
    const conta = payload.phoneNumber || payload.numero_conta || '';

    if (!pedidoId) {
      throw new BadRequestException('Pedido ID não informado no webhook');
    }

    await this.dataSource.query(
      `CALL sp_registar_pagamento(?, ?, ?, ?, ?)`,
      [pedidoId, metodo, valor, referencia, conta],
    );

    return { status: 'processed' };
  }
}
