import { IsNumber, IsString, IsEnum, IsOptional, Min } from "class-validator";

export class CreatePagamentoDto {
  @IsNumber()
  pedido_id: number;

  @IsEnum(["EMOLA", "MPESA", "CARTAO", "NUMERARIO_ENTREGA", "POS_ENTREGA"])
  metodo_pagamento: string;

  @IsNumber()
  @Min(0)
  valor: number;

  @IsOptional()
  @IsString()
  referencia_transacao?: string;

  @IsOptional()
  @IsString()
  referencia_externa?: string;

  @IsOptional()
  @IsString()
  numero_conta_pagador?: string;
}
