import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FavoritosService } from './favoritos.service';
import { FavoritosController } from './favoritos.controller';
import { Favoritos } from '../entities/Favoritos.entity';
import { Produtos } from '../entities/Produtos.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Favoritos, Produtos])],
  controllers: [FavoritosController],
  providers: [FavoritosService],
})
export class FavoritosModule {}
