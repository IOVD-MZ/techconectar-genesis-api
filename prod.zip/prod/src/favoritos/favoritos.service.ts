import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Favoritos } from '../entities/Favoritos.entity';
import { Produtos } from '../entities/Produtos.entity';

@Injectable()
export class FavoritosService {
  constructor(
    @InjectRepository(Favoritos) private favoritoRepo: Repository<Favoritos>,
    @InjectRepository(Produtos) private produtoRepo: Repository<Produtos>,
  ) {}

  async adicionar(clienteId: number, produtoId: number) {
    const produto = await this.produtoRepo.findOne({ where: { id_produto: produtoId } });
    if (!produto) throw new NotFoundException('Produto não encontrado');
    const existente = await this.favoritoRepo.findOne({
      where: { cliente_id: clienteId, produto_id: produtoId },
    });
    if (existente) throw new ConflictException('Produto já está nos favoritos');
    const favorito = this.favoritoRepo.create({ cliente_id: clienteId, produto_id: produtoId });
    return await this.favoritoRepo.save(favorito);
  }

  async remover(clienteId: number, produtoId: number) {
    const favorito = await this.favoritoRepo.findOne({
      where: { cliente_id: clienteId, produto_id: produtoId },
    });
    if (!favorito) throw new NotFoundException('Favorito não encontrado');
    await this.favoritoRepo.remove(favorito);
    return { message: 'Removido dos favoritos' };
  }

  async listar(clienteId: number) {
    return await this.favoritoRepo.find({
      where: { cliente_id: clienteId },
      relations: { produto: true },
      order: { criado_em: 'DESC' },
    });
  }

  async verificar(clienteId: number, produtoId: number) {
    const favorito = await this.favoritoRepo.findOne({
      where: { cliente_id: clienteId, produto_id: produtoId },
    });
    return { isFavorito: !!favorito };
  }
}
