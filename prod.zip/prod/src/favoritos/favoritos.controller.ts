import { Controller, Get, Post, Delete, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { FavoritosService } from './favoritos.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';

@ApiTags('favoritos')
@Controller('favoritos')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class FavoritosController {
  constructor(private readonly favoritosService: FavoritosService) {}

  @Post('produto/:produtoId')
  @ApiOperation({ summary: 'Adicionar produto aos favoritos' })
  adicionar(@Request() req, @Param('produtoId') produtoId: string) {
    return this.favoritosService.adicionar(req.user.idpessoa, +produtoId);
  }

  @Delete('produto/:produtoId')
  @ApiOperation({ summary: 'Remover produto dos favoritos' })
  remover(@Request() req, @Param('produtoId') produtoId: string) {
    return this.favoritosService.remover(req.user.idpessoa, +produtoId);
  }

  @Get()
  @ApiOperation({ summary: 'Listar favoritos do cliente' })
  listar(@Request() req) {
    return this.favoritosService.listar(req.user.idpessoa);
  }

  @Get('produto/:produtoId/check')
  @ApiOperation({ summary: 'Verificar se produto está nos favoritos' })
  verificar(@Request() req, @Param('produtoId') produtoId: string) {
    return this.favoritosService.verificar(req.user.idpessoa, +produtoId);
  }
}
