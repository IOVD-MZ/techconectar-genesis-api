import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, HttpStatus, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam, ApiBody, ApiQuery } from '@nestjs/swagger';
import { CatalogService } from './catalog.service';
import { CreateProdutoDto, UpdateProdutoDto } from './dto/create-produto.dto';
import { CreateCategoriaDto, UpdateCategoriaDto } from './dto/create-categoria.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
@ApiTags('catalog')
@Controller('catalog')
export class CatalogController {
  constructor(private readonly catalogService: CatalogService) {}
  // ---------- ROTAS PÚBLICAS (sem autenticação) ----------
  @Get('produtos')
  @ApiOperation({ summary: 'Listar produtos com paginação e filtros' })
  @ApiQuery({ name: 'page', required: false, type: Number, example: 1 })
  @ApiQuery({ name: 'limit', required: false, type: Number, example: 10 })
  @ApiQuery({ name: 'search', required: false, type: String, example: 'hambúrguer' })
  @ApiQuery({ name: 'categoria', required: false, type: Number, example: 4 })
  @ApiQuery({ name: 'minPreco', required: false, type: Number, example: 100 })
  @ApiQuery({ name: 'maxPreco', required: false, type: Number, example: 500 })
  @ApiResponse({ status: HttpStatus.OK, description: 'Lista de produtos (paginada)' })
  findAllProdutos(@Query() query: any) {
    return this.catalogService.findAllProdutos(query);
  }
  @Get('produtos/:id')
  @ApiOperation({ summary: 'Obter um produto por ID' })
  @ApiParam({ name: 'id', description: 'ID do produto', example: 1 })
  @ApiResponse({ status: HttpStatus.OK, description: 'Produto encontrado' })
  @ApiResponse({ status: HttpStatus.NOT_FOUND, description: 'Produto não encontrado' })
  findOneProduto(@Param('id') id: string) {
    return this.catalogService.findOneProduto(+id);
  }
  @Get('categorias')
  @ApiOperation({ summary: 'Listar todas as categorias' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Lista de categorias' })
  findAllCategorias() {
    return this.catalogService.findAllCategorias();
  }
  @Get('categorias/:id')
  @ApiOperation({ summary: 'Obter uma categoria por ID' })
  @ApiParam({ name: 'id', description: 'ID da categoria', example: 1 })
  @ApiResponse({ status: HttpStatus.OK, description: 'Categoria encontrada' })
  findOneCategoria(@Param('id') id: string) {
    return this.catalogService.findOneCategoria(+id);
  }
  @Get('produtos/categoria/:categoriaId')
  @ApiOperation({ summary: 'Listar produtos por categoria' })
  @ApiParam({ name: 'categoriaId', description: 'ID da categoria', example: 2 })
  @ApiResponse({ status: HttpStatus.OK, description: 'Lista de produtos da categoria' })
  findByCategoria(@Param('categoriaId') categoriaId: string) {
    return this.catalogService.findByCategoria(+categoriaId);
  }
  // ---------- GEOLOCALIZAÇÃO DO FORNECEDOR (pública) ----------
  @Get('fornecedor/:fornecedorId/geolocalizacao')
  @ApiOperation({ summary: 'Obter geolocalização do fornecedor' })
  @ApiParam({ name: 'fornecedorId', description: 'ID do fornecedor' })
  @ApiResponse({ status: 200, description: 'Coordenadas do fornecedor' })
  @ApiResponse({ status: 404, description: 'Fornecedor não encontrado' })
  getFornecedorGeolocalizacao(@Param('fornecedorId') fornecedorId: string) {
    return this.catalogService.getFornecedorGeolocalizacao(+fornecedorId);
  }
  // ---------- ROTAS PROTEGIDAS (requerem autenticação e permissões) ----------
  @Post('produtos')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Criar um novo produto' })
  @ApiBody({ type: CreateProdutoDto })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Produto criado com sucesso' })
  @Permissions('produtos:criar')
  createProduto(@Body() createDto: CreateProdutoDto) {
    return this.catalogService.createProduto(createDto);
  }
  @Patch('produtos/:id')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Atualizar um produto' })
  @ApiParam({ name: 'id', description: 'ID do produto', example: 1 })
  @ApiBody({ type: UpdateProdutoDto })
  @ApiResponse({ status: HttpStatus.OK, description: 'Produto atualizado' })
  @Permissions('produtos:editar')
  updateProduto(@Param('id') id: string, @Body() updateDto: UpdateProdutoDto) {
    return this.catalogService.updateProduto(+id, updateDto);
  }
  @Delete('produtos/:id')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Remover um produto' })
  @ApiParam({ name: 'id', description: 'ID do produto', example: 1 })
  @ApiResponse({ status: HttpStatus.OK, description: 'Produto removido' })
  @Permissions('produtos:eliminar')
  removeProduto(@Param('id') id: string) {
    return this.catalogService.removeProduto(+id);
  }
  @Post('categorias')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Criar uma nova categoria' })
  @ApiBody({ type: CreateCategoriaDto })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Categoria criada' })
  @Permissions('produtos:criar')
  createCategoria(@Body() createDto: CreateCategoriaDto) {
    return this.catalogService.createCategoria(createDto);
  }
  @Patch('categorias/:id')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Atualizar uma categoria' })
  @ApiParam({ name: 'id', description: 'ID da categoria', example: 1 })
  @ApiBody({ type: UpdateCategoriaDto })
  @ApiResponse({ status: HttpStatus.OK, description: 'Categoria atualizada' })
  @Permissions('produtos:editar')
  updateCategoria(@Param('id') id: string, @Body() updateDto: UpdateCategoriaDto) {
    return this.catalogService.updateCategoria(+id, updateDto);
  }
  @Delete('categorias/:id')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Remover uma categoria' })
  @ApiParam({ name: 'id', description: 'ID da categoria', example: 1 })
  @ApiResponse({ status: HttpStatus.OK, description: 'Categoria removida' })
  @Permissions('produtos:eliminar')
  removeCategoria(@Param('id') id: string) {
    return this.catalogService.removeCategoria(+id);
  }
  @Get("fornecedores")
  @ApiOperation({ summary: "Listar fornecedores (público)" })
  @ApiResponse({ status: 200, description: "Lista de fornecedores" })
  async listarFornecedores() {
    return this.catalogService.listarFornecedores();
  }
}
