import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, ILike, Between, MoreThanOrEqual, LessThanOrEqual } from 'typeorm';
import { Produtos } from '../entities/Produtos.entity';
import { Categorias } from '../entities/Categorias.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { CreateProdutoDto, UpdateProdutoDto } from './dto/create-produto.dto';
import { CreateCategoriaDto, UpdateCategoriaDto } from './dto/create-categoria.dto';

@Injectable()
export class CatalogService {
  constructor(
    @InjectRepository(Produtos)
    private produtoRepo: Repository<Produtos>,
    @InjectRepository(Categorias)
    private categoriaRepo: Repository<Categorias>,
    @InjectRepository(Pessoa)
    private pessoaRepo: Repository<Pessoa>,
  ) {}

  // ---------- PRODUTOS ----------
  
  async createProduto(createDto: CreateProdutoDto) {
    const produtoData: any = {
      fornecedor_id: createDto.fornecedor_id,
      categoria_id: createDto.categoria_id,
      nome: createDto.nome,
      descricao: createDto.descricao || null,
      preco: createDto.preco.toString(),
      preco_promocional: createDto.preco_promocional ? createDto.preco_promocional.toString() : null,
      stock: createDto.stock,
      status_produto: createDto.status_produto || 'DISPONIVEL',
      imagem_capa: createDto.imagem_capa || null,
      destaque_patrocinado: createDto.destaque_patrocinado || false,
      validade: createDto.validade || null,
      is_perecivel: createDto.is_perecivel || false,
      atributos_especificos: createDto.atributos_especificos || null,
    };
    const produto = this.produtoRepo.create(produtoData);
    return await this.produtoRepo.save(produto);
  }

  async findAllProdutos(query: any) {
    const { page = 1, limit = 10, search, categoria, minPreco, maxPreco } = query;
    const skip = (page - 1) * limit;
    const take = limit > 0 ? limit : 10;

    const qb = this.produtoRepo.createQueryBuilder('p')
      .leftJoinAndSelect('p.categoria', 'categoria')
      .leftJoinAndSelect('p.fornecedor', 'fornecedor')
      .where('p.status_produto = :status', { status: 'DISPONIVEL' });

    if (search) {
      qb.andWhere('p.nome LIKE :search', { search: `%${search}%` });
    }
    if (categoria) {
      qb.andWhere('p.categoria_id = :categoria', { categoria });
    }
    if (minPreco !== undefined && maxPreco !== undefined) {
      qb.andWhere('p.preco BETWEEN :minPreco AND :maxPreco', { minPreco, maxPreco });
    } else if (minPreco !== undefined) {
      qb.andWhere('p.preco >= :minPreco', { minPreco });
    } else if (maxPreco !== undefined) {
      qb.andWhere('p.preco <= :maxPreco', { maxPreco });
    }

    const [items, total] = await qb
      .skip(skip)
      .take(take)
      .orderBy('p.nome', 'ASC')
      .getManyAndCount();

    return {
      items,
      total,
      page: +page,
      limit: +limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  async findOneProduto(id: number) {
    const produto = await this.produtoRepo.findOne({
      where: { id_produto: id },
      relations: { categoria: true, fornecedor: true },
    });
    if (!produto) throw new NotFoundException('Produto não encontrado');
    return produto;
  }

  async updateProduto(id: number, updateDto: UpdateProdutoDto) {
    await this.findOneProduto(id);
    const updateData: any = { ...updateDto };
    if (updateData.preco !== undefined) {
      updateData.preco = updateData.preco.toString();
    }
    if (updateData.preco_promocional !== undefined && updateData.preco_promocional !== null) {
      updateData.preco_promocional = updateData.preco_promocional.toString();
    }
    if (updateData.stock !== undefined) {
      updateData.stock = updateData.stock;
    }
    await this.produtoRepo.update(id, updateData);
    return this.findOneProduto(id);
  }

  async removeProduto(id: number) {
    const produto = await this.findOneProduto(id);
    return await this.produtoRepo.remove(produto);
  }

  async findByCategoria(categoriaId: number) {
    return await this.produtoRepo.find({
      where: { categoria_id: categoriaId, status_produto: 'DISPONIVEL' },
      relations: { categoria: true, fornecedor: true },
    });
  }

  // ---------- CATEGORIAS ----------

  async createCategoria(createDto: CreateCategoriaDto) {
    const categoria = this.categoriaRepo.create(createDto);
    return await this.categoriaRepo.save(categoria);
  }

  async findAllCategorias() {
    return await this.categoriaRepo.find({
      relations: { subCategorias: true, categoriaPai: true },
    });
  }

  async findOneCategoria(id: number) {
    const categoria = await this.categoriaRepo.findOne({
      where: { id_categoria: id },
      relations: { subCategorias: true, categoriaPai: true },
    });
    if (!categoria) throw new NotFoundException('Categoria não encontrada');
    return categoria;
  }

  async updateCategoria(id: number, updateDto: UpdateCategoriaDto) {
    await this.findOneCategoria(id);
    await this.categoriaRepo.update(id, updateDto);
    return this.findOneCategoria(id);
  }

  async removeCategoria(id: number) {
    const categoria = await this.findOneCategoria(id);
    if (categoria.subCategorias && categoria.subCategorias.length > 0) {
      throw new BadRequestException('Não é possível excluir uma categoria com subcategorias');
    }
    return await this.categoriaRepo.remove(categoria);
  }

  // ---------- GEOLOCALIZAÇÃO DO FORNECEDOR ----------

    async getFornecedorGeolocalizacao(fornecedorId: number) {
    const result = await this.pessoaRepo.manager.query(
      `SELECT ST_Y(g.localizacao) as latitude, ST_X(g.localizacao) as longitude, p.nome_completo
       FROM pessoa p
       LEFT JOIN geolocalizacoes_pessoa gp ON gp.idpessoa = p.idpessoa
       LEFT JOIN geolocalizacoes g ON g.idgeolocalizacoes = gp.idgeolocalizacoes
       WHERE p.idpessoa = ?`,
      [fornecedorId],
    );
    if (!result || result.length === 0) {
      throw new NotFoundException('Fornecedor não encontrado');
    }
    return {
      latitude: result[0].latitude,
      longitude: result[0].longitude,
      nome_completo: result[0].nome_completo,
    };
  }


  async listarFornecedores() {
    return await this.pessoaRepo.find({
      where: { tipo_pessoa: "FORNECEDOR" },
      select: { idpessoa: true, nome_completo: true, alcunha: true, slogan: true, selo_verificacao: true },
    });
  }
}
