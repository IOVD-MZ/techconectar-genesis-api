import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CatalogService } from './catalog.service';
import { CatalogController } from './catalog.controller';
import { Produtos } from '../entities/Produtos.entity';
import { Categorias } from '../entities/Categorias.entity';
import { Pessoa } from '../entities/Pessoa.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Produtos, Categorias, Pessoa])],
  controllers: [CatalogController],
  providers: [CatalogService],
})
export class CatalogModule {}
