import { IsString, IsNumber, IsOptional, IsEnum, IsBoolean, Min, MaxLength } from "class-validator";
import { PartialType } from "@nestjs/mapped-types";

export class CreateProdutoDto {
  @IsNumber()
  fornecedor_id: number;

  @IsNumber()
  categoria_id: number;

  @IsString()
  @MaxLength(255)
  nome: string;

  @IsOptional()
  @IsString()
  descricao?: string;

  @IsNumber()
  @Min(0)
  preco: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  preco_promocional?: number;

  @IsNumber()
  @Min(0)
  stock: number;

  @IsOptional()
  @IsEnum(["DISPONIVEL", "INDISPONIVEL", "DESCONTINUADO"])
  status_produto?: string;

  @IsOptional()
  @IsString()
  imagem_capa?: string;

  @IsOptional()
  @IsBoolean()
  destaque_patrocinado?: boolean;

  @IsOptional()
  @IsString()
  validade?: string;

  @IsOptional()
  @IsBoolean()
  is_perecivel?: boolean;

  @IsOptional()
  atributos_especificos?: any;
}

export class UpdateProdutoDto extends PartialType(CreateProdutoDto) {}
