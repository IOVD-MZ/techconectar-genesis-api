import { IsString, IsOptional, IsNumber } from "class-validator";
import { PartialType } from "@nestjs/mapped-types";

export class CreateCategoriaDto {
  @IsString()
  nome: string;

  @IsOptional()
  @IsNumber()
  categoria_pai_id?: number;
}

export class UpdateCategoriaDto extends PartialType(CreateCategoriaDto) {}
