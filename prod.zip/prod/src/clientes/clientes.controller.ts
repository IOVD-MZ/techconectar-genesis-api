import { Controller, Patch, Param, Body, ParseIntPipe, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiBody, ApiProperty } from '@nestjs/swagger';
import { IsNumber, Min } from 'class-validator';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';
import { ClientesService } from './clientes.service';

class UpdateLimiteCreditoDto {
  @ApiProperty({ example: 5000.00 }) @IsNumber() @Min(0) limite_credito: number;
}

@ApiTags('clientes')
@Controller('clientes')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class ClientesController {
  constructor(private readonly clientesService: ClientesService) {}

  @Patch(':id/limite-credito')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Atualizar limite de crédito (ADMIN)' })
  @ApiBody({ type: UpdateLimiteCreditoDto })
  async atualizarLimite(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateLimiteCreditoDto) {
    return this.clientesService.atualizarLimiteCredito(id, dto.limite_credito);
  }
}
