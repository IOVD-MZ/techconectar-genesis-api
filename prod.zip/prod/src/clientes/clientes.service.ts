import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Pessoa } from '../entities/Pessoa.entity';

@Injectable()
export class ClientesService {
  constructor(@InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>) {}

  async atualizarLimiteCredito(idpessoa: number, limite: number) {
    const pessoa = await this.pessoaRepo.findOne({ where: { idpessoa } });
    if (!pessoa) throw new NotFoundException('Cliente não encontrado');
    await this.pessoaRepo.update(idpessoa, { limites: limite.toFixed(2) });
    return { idpessoa, limite_credito: limite.toFixed(2), message: 'Limite atualizado' };
  }
}
