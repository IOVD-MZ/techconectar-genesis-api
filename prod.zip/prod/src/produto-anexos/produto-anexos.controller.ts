import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { ProdutoAnexosService } from './produto-anexos.service';
import { CreateProdutoAnexoDto, UpdateProdutoAnexoDto } from '../anexos/dto/produto-anexo.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('produto-anexos')
@Controller('produto-anexos')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class ProdutoAnexosController {
  constructor(private readonly service: ProdutoAnexosService) {}

  @Post('produto/:produtoId')
  @Permissions('anexos:upload')
  @ApiOperation({ summary: 'Associar anexo a um produto' })
  @ApiBody({ type: CreateProdutoAnexoDto })
  create(@Param('produtoId') produtoId: string, @Body() dto: CreateProdutoAnexoDto) {
    return this.service.create(+produtoId, dto);
  }

  @Get('produto/:produtoId')
  @Permissions('anexos:visualizar')
  @ApiOperation({ summary: 'Listar anexos de um produto' })
  findAll(@Param('produtoId') produtoId: string) {
    return this.service.findAll(+produtoId);
  }

  @Get(':id')
  @Permissions('anexos:visualizar')
  @ApiOperation({ summary: 'Obter detalhe de uma relação' })
  findOne(@Param('id') id: string) {
    return this.service.findOne(+id);
  }

  @Patch(':id')
  @Permissions('anexos:editar')
  @ApiOperation({ summary: 'Atualizar relação' })
  @ApiBody({ type: UpdateProdutoAnexoDto })
  update(@Param('id') id: string, @Body() dto: UpdateProdutoAnexoDto) {
    return this.service.update(+id, dto);
  }

  @Delete(':id')
  @Permissions('anexos:eliminar')
  @ApiOperation({ summary: 'Remover relação' })
  remove(@Param('id') id: string) {
    return this.service.remove(+id);
  }
}
