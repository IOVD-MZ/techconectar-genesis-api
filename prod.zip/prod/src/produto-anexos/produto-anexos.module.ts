import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProdutoAnexosService } from './produto-anexos.service';
import { ProdutoAnexosController } from './produto-anexos.controller';
import { ProdutoAnexo } from '../entities/ProdutoAnexo.entity';
import { Produtos } from '../entities/Produtos.entity';
import { Anexo } from '../entities/Anexo.entity';

@Module({
  imports: [TypeOrmModule.forFeature([ProdutoAnexo, Produtos, Anexo])],
  controllers: [ProdutoAnexosController],
  providers: [ProdutoAnexosService],
})
export class ProdutoAnexosModule {}
