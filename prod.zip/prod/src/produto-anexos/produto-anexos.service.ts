import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ProdutoAnexo } from '../entities/ProdutoAnexo.entity';
import { Produtos } from '../entities/Produtos.entity';
import { Anexo } from '../entities/Anexo.entity';
import { CreateProdutoAnexoDto, UpdateProdutoAnexoDto } from '../anexos/dto/produto-anexo.dto';

@Injectable()
export class ProdutoAnexosService {
  constructor(
    @InjectRepository(ProdutoAnexo) private relRepo: Repository<ProdutoAnexo>,
    @InjectRepository(Produtos) private produtoRepo: Repository<Produtos>,
    @InjectRepository(Anexo) private anexoRepo: Repository<Anexo>,
  ) {}

  async create(produtoId: number, dto: CreateProdutoAnexoDto) {
    const produto = await this.produtoRepo.findOne({ where: { id_produto: produtoId } });
    if (!produto) throw new NotFoundException('Produto não encontrado');

    const anexo = await this.anexoRepo.findOne({ where: { id: dto.anexo_id } });
    if (!anexo) throw new NotFoundException('Anexo não encontrado');

    const existente = await this.relRepo.findOne({
      where: { produto_id: produtoId, anexo_id: dto.anexo_id },
    });
    if (existente) throw new ConflictException('Anexo já está associado a este produto');

    const rel = this.relRepo.create({
      produto_id: produtoId,
      anexo_id: dto.anexo_id,
      tipo: dto.tipo,
      ordem: dto.ordem ?? 0,
    });
    return await this.relRepo.save(rel);
  }

  async findAll(produtoId: number) {
    return await this.relRepo.find({
      where: { produto_id: produtoId },
      relations: { anexo: true },
      order: { ordem: 'ASC', criado_em: 'ASC' },
    });
  }

  async findOne(id: number) {
    const rel = await this.relRepo.findOne({
      where: { id },
      relations: { anexo: true, produto: true },
    });
    if (!rel) throw new NotFoundException('Relação não encontrada');
    return rel;
  }

  async update(id: number, dto: UpdateProdutoAnexoDto) {
    await this.findOne(id);
    await this.relRepo.update(id, dto);
    return this.findOne(id);
  }

  async remove(id: number) {
    const rel = await this.findOne(id);
    await this.relRepo.remove(rel);
    return { message: 'Relação removida' };
  }
}
