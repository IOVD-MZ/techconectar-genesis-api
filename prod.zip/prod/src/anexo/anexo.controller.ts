import {
  Controller,
  Post,
  Get,
  Delete,
  Param,
  Body,
  UseGuards,
  ParseIntPipe,
  BadRequestException,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiBody,
} from '@nestjs/swagger';
import { AnexoService } from './anexo.service';
import { UploadAnexoDto } from './dto/upload-anexo.dto';
import { AnexoResponseDto } from './dto/anexo-response.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('anexos')
@Controller('anexos')
export class AnexoController {
  constructor(private readonly anexoService: AnexoService) {}

  @Post('upload')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @Permissions('anexos:upload')
  @ApiOperation({ summary: 'Registar metadados de ficheiro' })
  @ApiBody({ type: UploadAnexoDto })
  @ApiResponse({
    status: 201,
    description: 'Metadados registados com sucesso',
    type: AnexoResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Dados inválidos' })
  @ApiResponse({ status: 404, description: 'Pessoa não encontrada' })
  @ApiResponse({ status: 409, description: 'Ficheiro duplicado (mesmo hash)' })
  async upload(@Body() dto: UploadAnexoDto) {
    return this.anexoService.registrarMetadados(dto);
  }

  @Get()
  @Permissions('anexos:visualizar')
  @ApiOperation({ summary: 'Listar todos os anexos' })
  @ApiResponse({ status: 200, type: [AnexoResponseDto] })
  findAll() {
    return this.anexoService.findAll();
  }

  // === NOVOS ENDPOINTS UNIFICADOS ===

  @Get('produto/:produtoId')
  @Permissions('anexos:visualizar')
  @ApiOperation({ summary: 'Listar anexos de um produto (via produto_anexo)' })
  @ApiResponse({ status: 200, type: [AnexoResponseDto] })
  async findByProduto(@Param('produtoId', ParseIntPipe) produtoId: number) {
    return this.anexoService.findByProduto(produtoId);
  }


  // === ENDPOINTS EXISTENTES (mantidos) ===

  @Get('pessoa/:idpessoa')
  @Permissions('anexos:visualizar')
  @ApiOperation({ summary: 'Listar anexos de uma pessoa (via relação pessoa_anexo)' })
  @ApiResponse({ status: 200, type: [AnexoResponseDto] })
  findByPessoa(@Param('idpessoa', ParseIntPipe) idpessoa: number) {
    return this.anexoService.findByPessoa(idpessoa);
  }

  @Get(':id')
  @Permissions('anexos:visualizar')
  @ApiOperation({ summary: 'Obter detalhes de um anexo' })
  @ApiResponse({ status: 200, type: AnexoResponseDto })
  @ApiResponse({ status: 404, description: 'Anexo não encontrado' })
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.anexoService.findOne(id);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @Permissions('anexos:eliminar')
  @ApiOperation({ summary: 'Remover anexo (soft delete)' })
  @ApiResponse({ status: 204, description: 'Anexo removido' })
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.anexoService.remove(id);
  }

  @Delete(':id/hard')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @ApiBearerAuth('JWT-auth')
  @Permissions('anexos:eliminar')
  @ApiOperation({ summary: 'Remover anexo permanentemente (hard delete)' })
  @ApiResponse({ status: 204, description: 'Anexo removido permanentemente' })
  hardRemove(@Param('id', ParseIntPipe) id: number) {
    return this.anexoService.hardRemove(id);
  }
}
