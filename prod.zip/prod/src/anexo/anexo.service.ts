import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ConflictException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Anexo } from '../entities/Anexo.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { ProdutoAnexo } from '../entities/ProdutoAnexo.entity';
import { PessoaAnexo } from '../entities/PessoaAnexo.entity';
import { UploadAnexoDto } from './dto/upload-anexo.dto';
import { existsSync } from 'fs';
import { promises as fs } from 'fs';
import { join } from 'path';

@Injectable()
export class AnexoService {
  constructor(
    @InjectRepository(Anexo) private anexoRepo: Repository<Anexo>,
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
    @InjectRepository(ProdutoAnexo) private produtoAnexoRepo: Repository<ProdutoAnexo>,
    @InjectRepository(PessoaAnexo) private pessoaAnexoRepo: Repository<PessoaAnexo>,
  ) {}

  // ---------- HELPER: adicionar url derivada do caminho_armazenamento ----------
  private addUrl(anexo: any) {
    if (!anexo) return anexo;
    return {
      ...anexo,
      url: anexo.url || anexo.caminho_armazenamento || null,
    };
  }

  private addUrlToArray(anexos: any[]) {
    return (anexos || []).map((a) => this.addUrl(a));
  }

  // ---------- REGISTAR METADADOS ----------
  async registrarMetadados(dto: UploadAnexoDto) {
    const pessoa = await this.pessoaRepo.findOne({
      where: { idpessoa: dto.idpessoa },
    });
    if (!pessoa) {
      throw new NotFoundException(`Pessoa com ID ${dto.idpessoa} não encontrada`);
    }

    const existente = await this.anexoRepo.findOne({
      where: { hash_sha256: dto.hash_sha256 },
    });
    if (existente) {
      throw new ConflictException(
        `Já existe um ficheiro com o mesmo conteúdo (ID ${existente.id})`,
      );
    }


    const anexo = this.anexoRepo.create({
      id: dto.id,
      idpessoa: dto.idpessoa,
      tipo_anexo: dto.tipo_anexo || null,
      nome_ficheiro_original: dto.nome_ficheiro_original,
      caminho_armazenamento: dto.caminho_armazenamento,
      tamanho_bytes: dto.tamanho_bytes,
      hash_sha256: dto.hash_sha256,
      mime_type: dto.mime_type || null,
      carregado_em: dto.carregado_em ? new Date(dto.carregado_em) : new Date(),
    });

    const saved = await this.anexoRepo.save(anexo);
    return this.addUrl(saved);
  }

  // ---------- LISTAR TODOS ----------
  async findAll() {
    const anexos = await this.anexoRepo.find({
      relations: { pessoa: true },
      order: { carregado_em: 'DESC' },
    });
    return this.addUrlToArray(anexos);
  }

  // ---------- BUSCAR POR PESSOA (via pessoa_anexo) ----------
  async findByPessoa(idpessoa: number) {
    const relacoes = await this.pessoaAnexoRepo.find({
      where: { pessoa_id: idpessoa },
      relations: { anexo: true },
    });
    return this.addUrlToArray(relacoes.map(r => r.anexo));
  }

  // ---------- BUSCAR POR PRODUTO (via produto_anexo) ----------
  async findByProduto(produtoId: number) {
    const relacoes = await this.produtoAnexoRepo.find({
      where: { produto_id: produtoId },
      relations: { anexo: true },
      order: { ordem: 'ASC' },
    });
    return this.addUrlToArray(relacoes.map(r => r.anexo));
  }

  // ---------- BUSCAR POR PESSOA (unificado, mesma lógica) ----------
  async findByPessoaUnificada(pessoaId: number) {
    return this.findByPessoa(pessoaId);
  }

  // ---------- OBTER UM ANEXO ----------
  async findOne(id: number) {
    const anexo = await this.anexoRepo.findOne({
      where: { id },
      relations: { pessoa: true },
    });
    if (!anexo) {
      throw new NotFoundException(`Anexo com ID ${id} não encontrado`);
    }
    return this.addUrl(anexo);
  }

  // ---------- REMOVER (SOFT DELETE) ----------
  async remove(id: number) {
    await this.findOne(id);
    await this.anexoRepo.update(id, {
      is_deleted: true,
      deleted_at: new Date(),
    });
  }

  // ---------- REMOVER (HARD DELETE) ----------
  async hardRemove(id: number) {
    const anexo = await this.findOne(id);
    const filePath = join(process.cwd(), anexo.caminho_armazenamento);
    if (existsSync(filePath)) {
      await fs.unlink(filePath);
    }
    await this.anexoRepo.delete(id);
  }
}
