import {
  IsString,
  IsNumber,
  IsOptional,
  IsNotEmpty,
  IsUrl,
  IsDateString,
  Min,
  MaxLength,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class UploadAnexoDto {
  @ApiProperty({ description: 'ID do anexo', example: 1 })
  @IsNumber()
  @IsNotEmpty()
  id: number;

  @ApiProperty({ description: 'ID da pessoa associada', example: 1 })
  @IsNumber()
  @IsNotEmpty()
  idpessoa: number;

  @ApiPropertyOptional({
    description: 'Tipo de anexo (ex: perfil, produto, etc.)',
    example: 'perfil',
  })
  @IsOptional()
  @IsString()
  tipo_anexo?: string;

  @ApiProperty({ description: 'Nome original do ficheiro', example: 'imagem.jpg' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  nome_ficheiro_original: string;

  @ApiProperty({
    description: 'Caminho de armazenamento (relativo)',
    example: 'uploads/perfil/1712345678-abc123.jpg',
  })
  @IsString()
  @IsNotEmpty()
  @MaxLength(500)
  caminho_armazenamento: string;

  @ApiProperty({ description: 'Tamanho do ficheiro em bytes', example: 24576 })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  tamanho_bytes: number;

  @ApiProperty({
    description: 'Hash SHA-256 do ficheiro',
    example: '3f7c...',
  })
  @IsString()
  @IsNotEmpty()
  @MaxLength(64)
  hash_sha256: string;

  @ApiPropertyOptional({
    description: 'MIME type do ficheiro',
    example: 'image/jpeg',
  })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  mime_type?: string;

  @ApiPropertyOptional({
    description: 'Data em que foi carregado (ISO)',
    example: '2026-08-17T10:00:00.000Z',
  })
  @IsOptional()
  @IsDateString()
  carregado_em?: string;

  @ApiPropertyOptional({
    description: 'URL pública do ficheiro',
    example: '/uploads/perfil/1712345678-abc123.jpg',
  })
  @IsOptional()
  @IsUrl({ require_tld: false })
  url?: string;
}
