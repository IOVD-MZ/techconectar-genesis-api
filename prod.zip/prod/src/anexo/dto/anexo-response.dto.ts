import { ApiProperty } from '@nestjs/swagger';

export class AnexoResponseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  idpessoa: number;

  @ApiProperty()
  tipo_anexo: string | null;

  @ApiProperty()
  nome_ficheiro_original: string;

  @ApiProperty()
  caminho_armazenamento: string;

  @ApiProperty()
  tamanho_bytes: number;

  @ApiProperty()
  hash_sha256: string;

  @ApiProperty()
  mime_type: string | null;

  @ApiProperty()
  carregado_em: Date;

  @ApiProperty()
  url: string;
}
