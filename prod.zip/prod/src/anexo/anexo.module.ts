import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AnexoService } from './anexo.service';
import { AnexoController } from './anexo.controller';
import { Anexo } from '../entities/Anexo.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { ProdutoAnexo } from '../entities/ProdutoAnexo.entity';
import { PessoaAnexo } from '../entities/PessoaAnexo.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Anexo, Pessoa, ProdutoAnexo, PessoaAnexo])],
  controllers: [AnexoController],
  providers: [AnexoService],
})
export class AnexoModule {}
