import { diskStorage } from 'multer';
import { extname, join } from 'path';
import * as crypto from 'crypto';

// Pasta raiz de uploads
const UPLOAD_DIR = join(process.cwd(), 'uploads');

export const multerConfig = {
  storage: diskStorage({
    destination: (req, file, cb) => {
      // Pode-se definir subpastas baseado no tipo de anexo
      let subfolder = 'temporario';
      if (req.body.tipo_anexo) {
        const tipo = req.body.tipo_anexo.toLowerCase();
        if (['perfil', 'produto', 'categoria', 'estabelecimento'].includes(tipo)) {
          subfolder = tipo;
        }
      }
      const dest = join(UPLOAD_DIR, subfolder);
      cb(null, dest);
    },
    filename: (req, file, cb) => {
      // Gera nome único: timestamp + hash + extensão
      const hash = crypto.randomBytes(16).toString('hex');
      const ext = extname(file.originalname);
      const filename = `${Date.now()}-${hash}${ext}`;
      cb(null, filename);
    },
  }),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
  fileFilter: (req, file, cb) => {
    // Aceita apenas imagens e PDFs (ajustar conforme necessidade)
    const allowedMimes = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'application/pdf',
      'image/svg+xml',
    ];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Tipo de ficheiro não suportado'), false);
    }
  },
};
