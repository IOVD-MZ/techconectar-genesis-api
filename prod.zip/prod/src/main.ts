import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const config = app.get(ConfigService);

  // CORS
  const origins = config.get('CORS_ORIGIN')?.split(',') || [];
  app.enableCors({ origin: origins, credentials: true });

  // Validação global
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  // ---------- CONFIGURAÇÃO SWAGGER ----------
  const isProduction = config.get('NODE_ENV') === 'production';
  const baseUrl = isProduction
    ? 'https://garson.techconectar.com'
    : 'http://localhost:3000';

  const swaggerConfig = new DocumentBuilder()
    .setTitle('Genesis API - Delivery & E-commerce')
    .setDescription(`
      API completa para gestão de delivery e e-commerce.

      ## Autenticação

      1. **Obter token:** Faça uma requisição POST para \`/auth/login\` com as credenciais.
      2. **Autorizar:** Clique no botão **"Authorize"** (🔒) no canto superior direito.
      3. **Inserir token:** Cole o token **sem** o prefixo "Bearer " (apenas o token JWT).

      ## Papéis e Permissões

      - **ADMIN**: Acesso total
      - **FORNECEDOR**: Gestão de catálogo, pedidos e pagamentos
      - **ESTAFETA**: Gestão de entregas (apenas as próprias)
      - **CLIENTE**: Visualização e criação de pedidos

      ## Desenvolvido por

      **Tech Conectar** - [https://techconectar.com/](https://techconectar.com/)
    `)
    .setVersion('1.0.0')
    .setContact('Tech Conectar', 'https://techconectar.com/', 'contacto@techconectar.com')
    .setLicense('MIT', 'https://opensource.org/licenses/MIT')
    .addBearerAuth(
      {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        description: 'Insira apenas o token JWT (sem a palavra "Bearer ").',
        name: 'Authorization',
        in: 'header',
      },
      'JWT-auth',
    )
    .addTag('auth', 'Autenticação e gestão de utilizadores')
    .addTag('catalog', 'Catálogo de produtos e categorias')
    .addTag('orders', 'Gestão de pedidos e sub-pedidos')
    .addTag('payments', 'Pagamentos e webhooks')
    .addTag('deliveries', 'Entregas e rastreio')
    .addTag('admin', 'Relatórios administrativos')
    .addTag('anexos', 'Gestão de anexos')
    .addServer(baseUrl, isProduction ? 'Produção' : 'Desenvolvimento')
    .build();

  const document = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup('api/docs', app, document, {
    swaggerOptions: {
      persistAuthorization: true,
      docExpansion: 'none',
      filter: true,
      showRequestDuration: true,
      displayRequestDuration: true,
      tryItOutEnabled: true,
    },
    customSiteTitle: 'Genesis API - Tech Conectar',
    customCss: `
      .swagger-ui .topbar { background-color: #1a1a2e; padding: 10px 0; }
      .swagger-ui .topbar .topbar-wrapper .link:after {
        content: "🚀 Tech Conectar";
        font-size: 16px;
        color: #fff;
        margin-left: 15px;
        font-weight: 600;
      }
      .swagger-ui .info .title small.version-stamp { background-color: #e94560; }
      .swagger-ui .info a { color: #e94560; }
    `,
    customfavIcon: 'https://techconectar.com/favicon.ico',
  });

  const port = config.get('PORT') || 3000;
  await app.listen(port);
  console.log(`🚀 Genesis API rodando em ${baseUrl}`);
  console.log(`📚 Swagger disponível em ${baseUrl}/api/docs`);
  console.log(`🏢 Desenvolvido por Tech Conectar - https://techconectar.com`);
}
bootstrap();
