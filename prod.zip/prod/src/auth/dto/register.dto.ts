import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, MinLength, IsOptional, IsString } from 'class-validator';

export class RegisterDto {
  @ApiProperty({ example: 'novo.cliente@email.com' })
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @ApiProperty({ example: 'senha123' })
  @IsNotEmpty()
  @MinLength(6)
  password: string;

  @ApiProperty({ example: 'Novo Cliente' })
  @IsNotEmpty()
  @IsString()
  nome_completo: string;

  @ApiPropertyOptional({ example: '+258841234567' })
  @IsOptional()
  @IsString()
  telefone?: string;

  @ApiPropertyOptional({ example: 'Bairro 1, Songo' })
  @IsOptional()
  @IsString()
  endereco?: string;
}
