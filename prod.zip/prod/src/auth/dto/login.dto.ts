import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, MinLength } from 'class-validator';

export class LoginDto {
  @ApiProperty({ example: 'admin@genesis.co.mz', description: 'Email do utilizador' })
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @ApiProperty({ example: 'admin123', description: 'Senha do utilizador', minLength: 6 })
  @IsNotEmpty()
  @MinLength(6)
  password: string;
}
