import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredPermissions = this.reflector.get<string[]>('permissions', context.getHandler());
    if (!requiredPermissions || requiredPermissions.length === 0) {
      return true; // Sem permissões exigidas, permite acesso
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;
    if (!user) {
      throw new ForbiddenException('Usuário não autenticado');
    }

    // Agora o user contém 'permissoes' (array de strings) vindo do payload JWT
    const userPermissions = user.permissoes || [];
    const hasAll = requiredPermissions.every(p => userPermissions.includes(p));
    if (!hasAll) {
      throw new ForbiddenException('Permissão insuficiente');
    }
    return true;
  }
}
