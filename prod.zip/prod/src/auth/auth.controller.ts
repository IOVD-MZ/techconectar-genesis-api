import { Controller, Post, Body, UseGuards, Get, Request, HttpStatus, BadRequestException } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';

class LoginResponse {
  access_token: string;
  idusuario: number;
  email: string;
  pessoa: any;
  papeis: any[];
  permissoes: string[];
}

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('login')
  @ApiOperation({ summary: 'Login do utilizador' })
  @ApiBody({ type: LoginDto })
  @ApiResponse({ status: HttpStatus.OK, description: 'Login bem-sucedido', type: LoginResponse })
  @ApiResponse({ status: HttpStatus.UNAUTHORIZED, description: 'Credenciais inválidas' })
  async login(@Body() body: LoginDto) {
    const user = await this.authService.validateUser(body.email, body.password);
    return this.authService.login(user);
  }

  @Post('register')
  @ApiOperation({ summary: 'Registo de novo cliente' })
  @ApiBody({ type: RegisterDto })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Cliente registado com sucesso', type: LoginResponse })
  @ApiResponse({ status: HttpStatus.CONFLICT, description: 'Email já registado' })
  @ApiResponse({ status: HttpStatus.BAD_REQUEST, description: 'Dados inválidos' })
  async register(@Body() body: RegisterDto) {
    if (!body.email || !body.password || !body.nome_completo) {
      throw new BadRequestException('Email, senha e nome completo são obrigatórios');
    }
    if (body.password.length < 6) {
      throw new BadRequestException('Senha deve ter pelo menos 6 caracteres');
    }
    return this.authService.register(body);
  }

  @Get('me')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Obter perfil do utilizador autenticado' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Dados do utilizador', type: LoginResponse })
  @ApiResponse({ status: HttpStatus.UNAUTHORIZED, description: 'Token inválido ou ausente' })
  getProfile(@Request() req) {
    return req.user;
  }
}
