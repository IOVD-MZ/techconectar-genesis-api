import { Injectable, UnauthorizedException, ConflictException, BadRequestException, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Usuario } from '../entities/Usuario.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @InjectRepository(Usuario) private usuarioRepo: Repository<Usuario>,
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
    private jwtService: JwtService,
  ) {}

  async validateUser(email: string, password: string): Promise<any> {
    const usuario = await this.usuarioRepo.findOne({
      where: { email },
      relations: { pessoa: true, papeis: { permissoes: true } },
    });
    if (!usuario) {
      throw new UnauthorizedException('Credenciais inválidas');
    }
    const valid = await bcrypt.compare(password, usuario.password_hash);
    if (!valid) {
      throw new UnauthorizedException('Credenciais inválidas');
    }
    if (!usuario.is_ativo) {
      throw new UnauthorizedException('Utilizador inativo');
    }
    const { password_hash, ...result } = usuario;
    return result;
  }

  async login(usuario: any) {
    const permissoesSet = new Set<string>();
    if (usuario.papeis) {
      for (const papel of usuario.papeis) {
        if (papel.permissoes) {
          for (const permissao of papel.permissoes) {
            permissoesSet.add(permissao.chave);
          }
        }
      }
    }
    const permissoes = Array.from(permissoesSet);
    const payload = {
      idpessoa: usuario.pessoa?.idpessoa || null,
      sub: usuario.idusuario,
      email: usuario.email,
      papeis: usuario.papeis?.map(p => p.nome) || [],
      permissoes: permissoes,
    };
    this.logger.log(
      `Login: user=${usuario.email} papeis=[${(usuario.papeis || []).map(p => p.nome).join(',')}] permissoes=${permissoes.length}`,
    );

    return {
      access_token: this.jwtService.sign(payload),
      usuario: {
        idusuario: usuario.idusuario,
        email: usuario.email,
        pessoa: usuario.pessoa,
        papeis: usuario.papeis || [],
        permissoes: permissoes,
      },
    };
  }

  // ---------- REGISTO DE CLIENTES ----------
  async register(dto: { email: string; password: string; nome_completo: string; telefone?: string; endereco?: string }) {
    // Verificar se email já existe
    const existente = await this.usuarioRepo.findOne({ where: { email: dto.email } });
    if (existente) {
      throw new ConflictException('Email já registado');
    }

    const hashedPassword = await bcrypt.hash(dto.password, 10);

    // Inserir utilizador
    const usuario = this.usuarioRepo.create({
      email: dto.email,
      password_hash: hashedPassword,
      is_ativo: true,
    });
    const savedUsuario = await this.usuarioRepo.save(usuario);

    // Inserir pessoa (CLIENTE)
    const pessoa = this.pessoaRepo.create({
      usuario: savedUsuario,
      nome_completo: dto.nome_completo,
      tipo_pessoa: "CLIENTE",
      selo_verificacao: false,
      limites: "0.00",
      endereco_fisico: dto.endereco || null,
    });
    await this.pessoaRepo.save(pessoa);

    // Associar ao papel CLIENTE (id=4)
    await this.usuarioRepo.manager.query(
      `INSERT INTO usuario_papel (idusuario, idpapel) VALUES (?, 4)`,
      [savedUsuario.idusuario],
    );

    // Fazer login automático
    const usuarioCompleto = await this.usuarioRepo.findOne({
      where: { idusuario: savedUsuario.idusuario },
      relations: { pessoa: true, papeis: { permissoes: true } },
    });
    return this.login(usuarioCompleto);
  }
}
