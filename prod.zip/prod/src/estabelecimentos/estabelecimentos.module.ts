import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstabelecimentosService } from './estabelecimentos.service';
import { EstabelecimentosController } from './estabelecimentos.controller';
import { Estabelecimentos } from '../entities/Estabelecimentos.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Papel } from '../entities/Papel.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Estabelecimentos, Pessoa, Papel])],
  controllers: [EstabelecimentosController],
  providers: [EstabelecimentosService],
})
export class EstabelecimentosModule {}
