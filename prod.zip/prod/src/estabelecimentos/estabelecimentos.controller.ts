import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, ParseIntPipe } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiBody, ApiParam } from '@nestjs/swagger';
import { EstabelecimentosService } from './estabelecimentos.service';
import { CreateEstabelecimentoDto } from './dto/create-estabelecimento.dto';
import { UpdateEstabelecimentoDto } from './dto/update-estabelecimento.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('estabelecimentos')
@Controller('estabelecimentos')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class EstabelecimentosController {
  constructor(private readonly service: EstabelecimentosService) {}

  @Post()
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Criar estabelecimento (ADMIN)' })
  @ApiBody({ type: CreateEstabelecimentoDto })
  async create(@Body() dto: CreateEstabelecimentoDto) {
    return this.service.create(dto);
  }

  @Get()
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Listar estabelecimentos (ADMIN)' })
  async findAll() {
    return this.service.findAll();
  }

  @Get(':id')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Detalhe do estabelecimento (ADMIN)' })
  @ApiParam({ name: 'id' })
  async findOne(@Param('id', ParseIntPipe) id: number) {
    return this.service.findOne(id);
  }

  @Patch(':id')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Atualizar estabelecimento (ADMIN)' })
  @ApiBody({ type: UpdateEstabelecimentoDto })
  async update(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateEstabelecimentoDto) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Remover estabelecimento (ADMIN)' })
  async remove(@Param('id', ParseIntPipe) id: number) {
    return this.service.remove(id);
  }
}
