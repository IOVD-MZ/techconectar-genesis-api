import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Estabelecimentos } from '../entities/Estabelecimentos.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Papel } from '../entities/Papel.entity';
import { CreateEstabelecimentoDto } from './dto/create-estabelecimento.dto';
import { UpdateEstabelecimentoDto } from './dto/update-estabelecimento.dto';

@Injectable()
export class EstabelecimentosService {
  constructor(
    @InjectRepository(Estabelecimentos)
    private estabelecimentoRepo: Repository<Estabelecimentos>,
    @InjectRepository(Pessoa)
    private pessoaRepo: Repository<Pessoa>,
    @InjectRepository(Papel)
    private papelRepo: Repository<Papel>,
    private dataSource: DataSource,
  ) {}

  async create(dto: CreateEstabelecimentoDto) {
    const pessoa = await this.pessoaRepo.findOne({
      where: { idpessoa: dto.pessoa_id },
      relations: { usuario: true },
    });
    if (!pessoa) throw new NotFoundException(`Pessoa ${dto.pessoa_id} não encontrada`);

    const existente = await this.estabelecimentoRepo.findOne({
      where: { pessoa_id: dto.pessoa_id },
    });
    if (existente) throw new ConflictException('Esta pessoa já tem um estabelecimento');

    const qr = this.dataSource.createQueryRunner();
    await qr.connect();
    await qr.startTransaction();

    try {
      const novo = qr.manager.create(Estabelecimentos, {
        pessoa_id: dto.pessoa_id,
        nome_comercial: dto.nome_comercial,
        nuit: dto.nuit ?? null,
        raio_entrega_km: (dto.raio_entrega_km ?? 5).toString(),
        tempo_medio_preparo_min: dto.tempo_medio_preparo_min ?? 30,
        is_aberto: dto.is_aberto ?? true,
        comissao_plataforma_pct: (dto.comissao_plataforma_pct ?? 10).toString(),
        dados_pagamento_mpesa: dto.dados_pagamento_mpesa ?? null,
      });
      const saved = await qr.manager.save(novo);

      if (pessoa.tipo_pessoa !== 'FORNECEDOR') {
        await qr.manager.update(Pessoa, dto.pessoa_id, { tipo_pessoa: 'FORNECEDOR' });
      }

      if (pessoa.idusuario) {
        const papel = await this.papelRepo.findOne({ where: { nome: 'FORNECEDOR' } });
        if (papel) {
          const jaTem = await qr.manager.query(
            `SELECT 1 FROM usuario_papel WHERE idusuario = ? AND idpapel = ?`,
            [pessoa.idusuario, papel.idpapel],
          );
          if (!jaTem || jaTem.length === 0) {
            await qr.manager.query(
              `INSERT INTO usuario_papel (idusuario, idpapel) VALUES (?, ?)`,
              [pessoa.idusuario, papel.idpapel],
            );
          }
        }
      }

      await qr.commitTransaction();
      return this.findOne(saved.id_estabelecimento);
    } catch (err) {
      await qr.rollbackTransaction();
      throw err;
    } finally {
      await qr.release();
    }
  }

  async findAll() {
    return await this.estabelecimentoRepo.find({
      relations: { pessoa: true },
      order: { id_estabelecimento: 'DESC' },
    });
  }

  async findOne(id: number) {
    const est = await this.estabelecimentoRepo.findOne({
      where: { id_estabelecimento: id },
      relations: { pessoa: true },
    });
    if (!est) throw new NotFoundException('Estabelecimento não encontrado');
    return est;
  }

  async update(id: number, dto: UpdateEstabelecimentoDto) {
    await this.findOne(id);
    const data: any = {};
    if (dto.nome_comercial !== undefined) data.nome_comercial = dto.nome_comercial;
    if (dto.nuit !== undefined) data.nuit = dto.nuit;
    if (dto.raio_entrega_km !== undefined) data.raio_entrega_km = dto.raio_entrega_km.toString();
    if (dto.tempo_medio_preparo_min !== undefined) data.tempo_medio_preparo_min = dto.tempo_medio_preparo_min;
    if (dto.is_aberto !== undefined) data.is_aberto = dto.is_aberto;
    if (dto.comissao_plataforma_pct !== undefined) data.comissao_plataforma_pct = dto.comissao_plataforma_pct.toString();
    if (dto.dados_pagamento_mpesa !== undefined) data.dados_pagamento_mpesa = dto.dados_pagamento_mpesa;

    await this.estabelecimentoRepo.update(id, data);
    return this.findOne(id);
  }

  async remove(id: number) {
    const est = await this.findOne(id);
    await this.estabelecimentoRepo.remove(est);
    return { message: 'Estabelecimento removido' };
  }
}
