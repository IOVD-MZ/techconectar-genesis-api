import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsString, IsNumber, IsOptional, IsBoolean, Min, MaxLength } from 'class-validator';

export class CreateEstabelecimentoDto {
  @ApiProperty({ example: 1 })
  @IsNumber()
  pessoa_id: number;

  @ApiProperty({ example: 'Loja do Zé' })
  @IsString()
  @MaxLength(255)
  nome_comercial: string;

  @ApiPropertyOptional({ example: '123456789' })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  nuit?: string;

  @ApiPropertyOptional({ example: 5.0 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  raio_entrega_km?: number;

  @ApiPropertyOptional({ example: 30 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  tempo_medio_preparo_min?: number;

  @ApiPropertyOptional({ example: true })
  @IsOptional()
  @IsBoolean()
  is_aberto?: boolean;

  @ApiPropertyOptional({ example: 10.0 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  comissao_plataforma_pct?: number;

  @ApiPropertyOptional({ example: '841234567' })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  dados_pagamento_mpesa?: string;
}

