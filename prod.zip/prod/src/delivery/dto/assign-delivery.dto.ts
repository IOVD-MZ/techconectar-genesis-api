import { IsNumber } from "class-validator";

export class AssignDeliveryDto {
  @IsNumber()
  estafeta_id: number;
}
