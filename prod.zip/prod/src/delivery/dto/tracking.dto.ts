import { IsNumber, IsLatitude, IsLongitude } from "class-validator";

export class TrackingDto {
  @IsNumber()
  entrega_id: number;

  @IsLatitude()
  latitude: number;

  @IsLongitude()
  longitude: number;
}
