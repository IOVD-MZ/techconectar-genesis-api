import { IsEnum } from "class-validator";

export class UpdateDeliveryStatusDto {
  @IsEnum(["AGUARDANDO_ESTAFETA", "A_CAMINHO_DA_LOJA", "EM_TRANSPORTE", "ENTREGUE", "FALHADA"])
  status: string;
}
