import { Injectable, NotFoundException, BadRequestException, ForbiddenException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import { Entregas } from '../entities/Entregas.entity';
import { Pedidos } from '../entities/Pedidos.entity';
import { RastreioEstafetaLog } from '../entities/RastreioEstafetaLog.entity';
import { AssignDeliveryDto } from './dto/assign-delivery.dto';
import { UpdateDeliveryStatusDto } from './dto/update-delivery-status.dto';
import { TrackingDto } from './dto/tracking.dto';

@Injectable()
export class DeliveryService {
  constructor(
    @InjectRepository(Entregas) private entregaRepo: Repository<Entregas>,
    @InjectRepository(Pedidos) private pedidoRepo: Repository<Pedidos>,
    @InjectRepository(RastreioEstafetaLog) private rastreioRepo: Repository<RastreioEstafetaLog>,
  ) {}

  async create(pedidoId: number) {
    // Verificar se já existe entrega ativa para este pedido
    const entregaExistente = await this.entregaRepo.findOne({
      where: { pedido_id: pedidoId, status_entrega: In(["AGUARDANDO_ESTAFETA", "A_CAMINHO_DA_LOJA", "EM_TRANSPORTE"]) },
    });
    if (entregaExistente) {
      throw new ConflictException("Este pedido já tem uma entrega ativa");
    }

    const pedido = await this.pedidoRepo.findOne({
      where: { id_pedido: pedidoId },
    });
    if (!pedido) throw new NotFoundException('Pedido não encontrado');

    const codigo = Math.floor(100000 + Math.random() * 900000).toString();
    const entrega = this.entregaRepo.create({
      pedido_id: pedidoId,
      status_entrega: 'AGUARDANDO_ESTAFETA',
      codigo_verificacao: codigo,
    });
    return await this.entregaRepo.save(entrega);
  }

  async assignEstafeta(entregaId: number, assignDto: AssignDeliveryDto) {
    const entrega = await this.entregaRepo.findOne({
      where: { id_entrega: entregaId },
    });
    if (!entrega) throw new NotFoundException('Entrega não encontrada');

    await this.entregaRepo.manager.query(
      `CALL sp_atribuir_estafeta(?, ?)`,
      [entregaId, assignDto.estafeta_id],
    );

    return await this.entregaRepo.findOne({
      where: { id_entrega: entregaId },
      relations: { pedido: true, estafeta: true },
    });
  }

  async updateStatus(entregaId: number, dto: UpdateDeliveryStatusDto) {
    const entrega = await this.entregaRepo.findOne({
      where: { id_entrega: entregaId },
    });
    if (!entrega) throw new NotFoundException('Entrega não encontrada');

    await this.entregaRepo.update(entregaId, { status_entrega: dto.status });
    return await this.entregaRepo.findOne({
      where: { id_entrega: entregaId },
      relations: { pedido: true, estafeta: true },
    });
  }

  async confirmarEntrega(entregaId: number, codigo: string) {
    const entrega = await this.entregaRepo.findOne({
      where: { id_entrega: entregaId },
    });
    if (!entrega) throw new NotFoundException('Entrega não encontrada');

    if (entrega.codigo_verificacao !== codigo) {
      throw new BadRequestException('Código de verificação inválido');
    }

    await this.entregaRepo.update(entregaId, { status_entrega: 'ENTREGUE', data_entrega_confirmada: new Date() });
    return await this.entregaRepo.findOne({
      where: { id_entrega: entregaId },
      relations: { pedido: true, estafeta: true },
    });
  }

  async salvarRastreio(trackingDto: TrackingDto) {
    if (!trackingDto.entrega_id || !trackingDto.latitude || !trackingDto.longitude) {
      throw new BadRequestException('Campos obrigatórios: entrega_id, latitude, longitude');
    }

    const entrega = await this.entregaRepo.findOne({
      where: { id_entrega: trackingDto.entrega_id },
      relations: { estafeta: true },
    });
    if (!entrega) throw new NotFoundException('Entrega não encontrada');
    if (!entrega.estafeta_id) {
      throw new BadRequestException('Esta entrega ainda não tem estafeta atribuído');
    }

    const log = this.rastreioRepo.create({
      entrega_id: trackingDto.entrega_id,
      estafeta_id: entrega.estafeta_id,
      latitude: trackingDto.latitude,
      longitude: trackingDto.longitude,
    });
    return await this.rastreioRepo.save(log);
  }

  async getRastreio(entregaId: number) {
    return await this.rastreioRepo.find({
      where: { entrega_id: entregaId },
      order: { registado_em: 'ASC' },
    });
  }

  async findAll() {
    return await this.entregaRepo.find({
      relations: { pedido: true, estafeta: true },
      order: { id_entrega: 'DESC' },
    });
  }

  async findOne(id: number) {
    const entrega = await this.entregaRepo.findOne({
      where: { id_entrega: id },
      relations: { pedido: true, estafeta: true },
    });
    if (!entrega) throw new NotFoundException('Entrega não encontrada');
    return entrega;
  }

  // ---------- MÉTODOS PARA CLIENTE ----------
  async findByCliente(clienteId: number) {
    const pedidos = await this.pedidoRepo.find({
      where: { cliente_id: clienteId },
      select: { id_pedido: true },
    });
    const pedidoIds = pedidos.map(p => p.id_pedido);
    if (pedidoIds.length === 0) return [];
    return await this.entregaRepo.find({
      where: { pedido_id: In(pedidoIds) },
      relations: { pedido: true, estafeta: true },
      order: { id_entrega: 'DESC' },
    });
  }

  async findOneComValidacao(id: number, clienteId: number) {
    const entrega = await this.findOne(id);
    const pedido = await this.pedidoRepo.findOne({
      where: { id_pedido: entrega.pedido_id },
      select: { cliente_id: true },
    });
    if (!pedido || pedido.cliente_id !== clienteId) {
      throw new ForbiddenException('Não tem permissão para ver esta entrega');
    }
    return entrega;
  }

  async getRastreioComValidacao(entregaId: number, clienteId: number) {
    await this.findOneComValidacao(entregaId, clienteId);
    return await this.getRastreio(entregaId);
  }

  async findByPedido(pedidoId: number) {
    return await this.entregaRepo.findOne({
      where: { pedido_id: pedidoId },
      relations: { pedido: true, estafeta: true },
    });
  }

  async findByPedidoComValidacao(pedidoId: number, clienteId: number) {
    const pedido = await this.pedidoRepo.findOne({
      where: { id_pedido: pedidoId },
      select: { cliente_id: true },
    });
    if (!pedido) throw new NotFoundException('Pedido não encontrado');
    if (pedido.cliente_id !== clienteId) {
      throw new ForbiddenException('Não é dono deste pedido');
    }
    return await this.findByPedido(pedidoId);
  }
}
