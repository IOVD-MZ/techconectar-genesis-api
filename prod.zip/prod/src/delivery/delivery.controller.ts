import { Controller, Get, Post, Body, Patch, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam, ApiBody } from '@nestjs/swagger';
import { DeliveryService } from './delivery.service';
import { AssignDeliveryDto } from './dto/assign-delivery.dto';
import { UpdateDeliveryStatusDto } from './dto/update-delivery-status.dto';
import { TrackingDto } from './dto/tracking.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';
import { PermissionsGuard } from '../auth/guards/permissions.guard';

@ApiTags('deliveries')
@Controller('deliveries')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class DeliveryController {
  constructor(private readonly deliveryService: DeliveryService) {}

  @Post('pedido/:pedidoId')
  @Permissions('entregas:criar')
  @ApiOperation({ summary: 'Criar entrega para um pedido' })
  @ApiParam({ name: 'pedidoId', description: 'ID do pedido' })
  @ApiResponse({ status: 201, description: 'Entrega criada' })
  create(@Param('pedidoId') pedidoId: string) {
    return this.deliveryService.create(+pedidoId);
  }

  @Patch(':id/assign')
  @Permissions('entregas:atribuir')
  @ApiOperation({ summary: 'Atribuir estafeta a uma entrega' })
  @ApiParam({ name: 'id', description: 'ID da entrega' })
  @ApiBody({ type: AssignDeliveryDto })
  @ApiResponse({ status: 200, description: 'Estafeta atribuído' })
  assign(@Param('id') id: string, @Body() dto: AssignDeliveryDto) {
    return this.deliveryService.assignEstafeta(+id, dto);
  }

  @Patch(':id/status')
  @Permissions('entregas:atualizar')
  @ApiOperation({ summary: 'Atualizar status da entrega' })
  @ApiParam({ name: 'id', description: 'ID da entrega' })
  @ApiBody({ type: UpdateDeliveryStatusDto })
  @ApiResponse({ status: 200, description: 'Status atualizado' })
  updateStatus(@Param('id') id: string, @Body() dto: UpdateDeliveryStatusDto) {
    return this.deliveryService.updateStatus(+id, dto);
  }

  @Post(':id/confirmar')
  @Permissions('entregas:confirmar')
  @ApiOperation({ summary: 'Confirmar entrega com código de verificação' })
  @ApiParam({ name: 'id', description: 'ID da entrega' })
  @ApiResponse({ status: 200, description: 'Entrega confirmada' })
  confirmar(@Param('id') id: string, @Body('codigo') codigo: string) {
    return this.deliveryService.confirmarEntrega(+id, codigo);
  }

  @Post('tracking')
  @Permissions('entregas:rastrear')
  @ApiOperation({ summary: 'Enviar localização do estafeta' })
  @ApiBody({ type: TrackingDto })
  @ApiResponse({ status: 201, description: 'Localização registada' })
  salvarRastreio(@Body() dto: TrackingDto) {
    return this.deliveryService.salvarRastreio(dto);
  }

  @Get(':id/tracking')
  @Permissions('entregas:visualizar')
  @ApiOperation({ summary: 'Obter histórico de rastreio de uma entrega' })
  @ApiParam({ name: 'id', description: 'ID da entrega' })
  @ApiResponse({ status: 200, description: 'Lista de pontos de rastreio' })
  getRastreio(@Param('id') id: string) {
    return this.deliveryService.getRastreio(+id);
  }

  @Get()
  @Permissions('entregas:visualizar')
  @ApiOperation({ summary: 'Listar entregas' })
  @ApiResponse({ status: 200, description: 'Lista de entregas' })
  findAll() {
    return this.deliveryService.findAll();
  }

  @Get(':id')
  @Permissions('entregas:visualizar')
  @ApiOperation({ summary: 'Obter entrega por ID' })
  @ApiParam({ name: 'id', description: 'ID da entrega' })
  @ApiResponse({ status: 200, description: 'Entrega encontrada' })
  findOne(@Param('id') id: string) {
    return this.deliveryService.findOne(+id);
  }

  @Get('pedido/:pedidoId')
  @Permissions('entregas:visualizar')
  @ApiOperation({ summary: 'Obter entrega de um pedido específico' })
  @ApiParam({ name: 'pedidoId', description: 'ID do pedido' })
  @ApiResponse({ status: 200, description: 'Entrega encontrada' })
  findByPedido(@Param('pedidoId') pedidoId: string) {
    return this.deliveryService.findByPedido(+pedidoId);
  }
}
