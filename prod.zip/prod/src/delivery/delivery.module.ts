import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { DeliveryService } from "./delivery.service";
import { DeliveryController } from "./delivery.controller";
import { Entregas } from "../entities/Entregas.entity";
import { Pedidos } from "../entities/Pedidos.entity";
import { RastreioEstafetaLog } from "../entities/RastreioEstafetaLog.entity";

@Module({
  imports: [TypeOrmModule.forFeature([Entregas, Pedidos, RastreioEstafetaLog])],
  controllers: [DeliveryController],
  providers: [DeliveryService],
})
export class DeliveryModule {}
