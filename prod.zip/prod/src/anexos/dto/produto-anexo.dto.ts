import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNumber, IsEnum, IsOptional, Min } from 'class-validator';

export class CreateProdutoAnexoDto {
  @ApiProperty({ description: 'ID do anexo (tabela anexo)', example: 1 })
  @IsNumber()
  @Min(1)
  anexo_id: number;

  @ApiProperty({ description: 'Tipo do anexo', enum: ['capa','lateral_esquerda','lateral_direita','cima','baixo','traseira','frontal','status'], default: 'capa' })
  @IsEnum(['capa','lateral_esquerda','lateral_direita','cima','baixo','traseira','frontal','status'])
  tipo: string;

  @ApiPropertyOptional({ description: 'Ordem de exibição', default: 0 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  ordem?: number;
}

export class UpdateProdutoAnexoDto {
  @ApiPropertyOptional({ enum: ['capa','lateral_esquerda','lateral_direita','cima','baixo','traseira','frontal','status'] })
  @IsOptional()
  @IsEnum(['capa','lateral_esquerda','lateral_direita','cima','baixo','traseira','frontal','status'])
  tipo?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  ordem?: number;
}
