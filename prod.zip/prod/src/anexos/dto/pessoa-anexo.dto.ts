import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNumber, IsString, IsEnum, IsOptional, Min } from 'class-validator';

export class CreatePessoaAnexoDto {
  @ApiProperty({ description: 'ID do anexo (tabela anexo)', example: 1 })
  @IsNumber()
  @Min(1)
  anexo_id: number;

  @ApiProperty({ description: 'Tipo do anexo', enum: ['foto','outra_imagem'], default: 'foto' })
  @IsEnum(['foto','outra_imagem'])
  tipo: string;
}

export class UpdatePessoaAnexoDto {
  @ApiPropertyOptional({ enum: ['foto','outra_imagem'] })
  @IsOptional()
  @IsEnum(['foto','outra_imagem'])
  tipo?: string;
}
