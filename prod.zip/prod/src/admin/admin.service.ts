import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between, In } from 'typeorm';
import { Pedidos } from '../entities/Pedidos.entity';
import { Entregas } from '../entities/Entregas.entity';
import { Pagamentos } from '../entities/Pagamentos.entity';
import { PedidoItens } from '../entities/PedidoItens.entity';
import { SubPedidos } from '../entities/SubPedidos.entity';
import { Usuario } from '../entities/Usuario.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Papel } from '../entities/Papel.entity';
import { UpdateUsuarioPapeisDto } from './dto/update-usuario-papeis.dto';
import { UpdateUsuarioStatusDto } from './dto/update-usuario-status.dto';

@Injectable()
export class AdminService {
  constructor(
    @InjectRepository(Pedidos) private pedidoRepo: Repository<Pedidos>,
    @InjectRepository(Entregas) private entregaRepo: Repository<Entregas>,
    @InjectRepository(Pagamentos) private pagamentoRepo: Repository<Pagamentos>,
    @InjectRepository(PedidoItens) private itemRepo: Repository<PedidoItens>,
    @InjectRepository(SubPedidos) private subRepo: Repository<SubPedidos>,
    @InjectRepository(Usuario) private usuarioRepo: Repository<Usuario>,
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
    @InjectRepository(Papel) private papelRepo: Repository<Papel>,
  ) {}

  // ---------- RELATÓRIOS (com suporte a FORNECEDOR) ----------
  async getSalesSummary(startDate: Date, endDate: Date, user?: any) {
    const papeis = user?.papeis || [];
    let whereCondition: any = { data_pedido: Between(startDate, endDate), status_pedido: 'CONCLUIDO' };

    if (papeis.includes('FORNECEDOR') && !papeis.includes('ADMIN')) {
      const subPedidos = await this.subRepo.find({
        where: { fornecedor_id: user.idusuario },
        select: { pedido_pai_id: true },
      });
      const pedidoIds = subPedidos.map(sp => sp.pedido_pai_id);
      if (pedidoIds.length === 0) {
        return { totalVendas: 0, totalPedidos: 0, ticketMedio: 0 };
      }
      whereCondition = {
        data_pedido: Between(startDate, endDate),
        status_pedido: 'CONCLUIDO',
        id_pedido: In(pedidoIds),
      };
    }

    const pedidos = await this.pedidoRepo.find({ where: whereCondition });
    const totalVendas = pedidos.reduce((acc, p) => acc + parseFloat(p.total_geral), 0);
    const totalPedidos = pedidos.length;
    const ticketMedio = totalPedidos > 0 ? totalVendas / totalPedidos : 0;
    return { totalVendas, totalPedidos, ticketMedio };
  }

  async getTopProducts(limit: number = 10, user?: any) {
    let query = this.itemRepo.createQueryBuilder('item')
      .select('item.produto_id, item.nome_produto_snapshot, SUM(item.quantidade) as total_vendido')
      .groupBy('item.produto_id, item.nome_produto_snapshot')
      .orderBy('total_vendido', 'DESC')
      .limit(limit);

    if (user?.papeis?.includes('FORNECEDOR') && !user.papeis.includes('ADMIN')) {
      const subPedidos = await this.subRepo.find({
        where: { fornecedor_id: user.idusuario },
        select: { id_sub_pedido: true },
      });
      const subIds = subPedidos.map(sp => sp.id_sub_pedido);
      if (subIds.length === 0) return [];
      query = query.andWhere('item.sub_pedido_id IN (:...subIds)', { subIds });
    }

    return await query.getRawMany();
  }

    async getDeliveryPerformance(user?: any) {
    try {
      const papeis = user?.papeis || [];
      let query = this.entregaRepo
        .createQueryBuilder('e')
        .select('e.estafeta_id', 'estafeta_id')
        .addSelect('p.nome_completo', 'nome')
        .addSelect(
          'AVG(TIMESTAMPDIFF(MINUTE, COALESCE(e.data_recolha, e.data_entrega_confirmada), e.data_entrega_confirmada))',
          'tempo_medio_min',
        )
        .leftJoin('e.estafeta', 'est')
        .leftJoin('est.pessoa', 'p')
        .where('e.status_entrega = :status', { status: 'ENTREGUE' })
        .andWhere('e.estafeta_id IS NOT NULL')
        .groupBy('e.estafeta_id')
        .addGroupBy('p.nome_completo');

      if (papeis.includes('FORNECEDOR') && !papeis.includes('ADMIN')) {
        const subPedidos = await this.subRepo.find({
          where: { fornecedor_id: user.idpessoa || user.idusuario },
          select: { pedido_pai_id: true },
        });
        const pedidoIds = subPedidos.map((sp) => sp.pedido_pai_id);
        if (pedidoIds.length === 0) return [];
        query = query.andWhere('e.pedido_id IN (:...pedidoIds)', { pedidoIds });
      }

      const result = await query.getRawMany();
      return (result || []).map((r) => ({
        estafeta_id: r.estafeta_id,
        nome: r.nome || 'Desconhecido',
        tempo_medio_min: r.tempo_medio_min ? Number(r.tempo_medio_min) : 0,
      }));
    } catch (err) {
      console.error('Erro em getDeliveryPerformance:', err);
      return [];
    }
  }


  async getRevenue(user?: any) {
    const papeis = user?.papeis || [];
    let whereCondition: any = { status_pagamento: 'PAGO' };

    if (papeis.includes('FORNECEDOR') && !papeis.includes('ADMIN')) {
      const subPedidos = await this.subRepo.find({
        where: { fornecedor_id: user.idusuario },
        select: { pedido_pai_id: true },
      });
      const pedidoIds = subPedidos.map(sp => sp.pedido_pai_id);
      if (pedidoIds.length === 0) {
        return { total: 0, comissao: 0, liquido: 0 };
      }
      const pagamentos = await this.pagamentoRepo.find({
        where: { status_pagamento: 'PAGO' },
      });
      const pagamentosFiltrados = pagamentos.filter(p => pedidoIds.includes(p.pedido_id));
      const total = pagamentosFiltrados.reduce((acc, p) => acc + parseFloat(p.valor), 0);
      const comissao = total * 0.10;
      return { total, comissao, liquido: total - comissao };
    }

    const pagamentos = await this.pagamentoRepo.find({ where: whereCondition });
    const total = pagamentos.reduce((acc, p) => acc + parseFloat(p.valor), 0);
    const comissao = total * 0.10;
    return { total, comissao, liquido: total - comissao };
  }

  // ---------- GESTÃO DE UTILIZADORES ----------
  async listarUsuarios(page: number = 1, limit: number = 10, tipo?: string, isAtivo?: boolean) {
    const skip = (page - 1) * limit;
    const queryBuilder = this.usuarioRepo.createQueryBuilder('u')
      .leftJoinAndSelect('u.pessoa', 'pessoa')
      .leftJoinAndSelect('u.papeis', 'papeis')
      .skip(skip)
      .take(limit)
      .orderBy('u.idusuario', 'ASC');

    if (tipo) {
      queryBuilder.andWhere('pessoa.tipo_pessoa = :tipo', { tipo });
    }
    if (isAtivo !== undefined) {
      queryBuilder.andWhere('u.is_ativo = :isAtivo', { isAtivo });
    }

    const [items, total] = await queryBuilder.getManyAndCount();
    // Remover password_hash da resposta por segurança
    const sanitizedItems = items.map(({ password_hash, ...rest }) => rest);
    return { items: sanitizedItems, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

    async getUsuario(id: number) {
    const usuario = await this.usuarioRepo.findOne({
      where: { idusuario: id },
      relations: { pessoa: true, papeis: true },
      select: {
        idusuario: true,
        email: true,
        is_ativo: true,
        ultimo_login: true,
        criado_em: true,
        password_hash: false,
      },
    });
    if (!usuario) throw new NotFoundException('Utilizador não encontrado');
    return usuario;
  }

  async updateUsuarioPapeis(id: number, dto: UpdateUsuarioPapeisDto) {
    const usuario = await this.getUsuario(id);
    const papeis = await this.papelRepo.find({
      where: { nome: In(dto.papeis) },
    });
    if (papeis.length !== dto.papeis.length) {
      throw new NotFoundException('Um ou mais papéis não existem');
    }
    usuario.papeis = papeis;
    await this.usuarioRepo.save(usuario);
    return this.getUsuario(id);
  }

  async updateUsuarioStatus(id: number, dto: UpdateUsuarioStatusDto) {
    const usuario = await this.getUsuario(id);
    usuario.is_ativo = dto.is_ativo;
    await this.usuarioRepo.save(usuario);
    return this.getUsuario(id);
  }
}
