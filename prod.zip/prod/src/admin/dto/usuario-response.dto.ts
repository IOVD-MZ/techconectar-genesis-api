import { ApiProperty } from '@nestjs/swagger';

export class UsuarioResponseDto {
  @ApiProperty() idusuario: number;
  @ApiProperty() email: string;
  @ApiProperty() is_ativo: boolean;
  @ApiProperty() ultimo_login: Date | null;
  @ApiProperty() criado_em: Date;
  @ApiProperty() pessoa: any;
  @ApiProperty() papeis: any[];
}
