import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsString } from 'class-validator';

export class UpdateUsuarioPapeisDto {
  @ApiProperty({ example: ['FORNECEDOR', 'CLIENTE'] })
  @IsArray()
  @IsString({ each: true })
  papeis: string[];
}
