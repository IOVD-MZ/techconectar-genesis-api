import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { Pedidos } from '../entities/Pedidos.entity';
import { Entregas } from '../entities/Entregas.entity';
import { Pagamentos } from '../entities/Pagamentos.entity';
import { PedidoItens } from '../entities/PedidoItens.entity';
import { SubPedidos } from '../entities/SubPedidos.entity';
import { Usuario } from '../entities/Usuario.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Papel } from '../entities/Papel.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Pedidos,
      Entregas,
      Pagamentos,
      PedidoItens,
      SubPedidos,
      Usuario,
      Pessoa,
      Papel,
    ]),
  ],
  controllers: [AdminController],
  providers: [AdminService],
})
export class AdminModule {}
