import { Controller, Get, Query, UseGuards, Request, Param, Body, Patch, ParseIntPipe, DefaultValuePipe, ParseBoolPipe } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery, ApiBody } from '@nestjs/swagger';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';
import { UpdateUsuarioPapeisDto } from './dto/update-usuario-papeis.dto';
import { UpdateUsuarioStatusDto } from './dto/update-usuario-status.dto';

@ApiTags('admin')
@Controller('admin')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  // ---------- RELATÓRIOS ----------
  @Get('reports/sales')
  @Permissions('loja:relatorios')
  @ApiOperation({ summary: 'Resumo de vendas (filtrado por papel)' })
  @ApiQuery({ name: 'start', required: true, type: String })
  @ApiQuery({ name: 'end', required: true, type: String })
  @ApiResponse({ status: 200, description: 'Dados de vendas' })
  async getSales(@Query('start') start: string, @Query('end') end: string, @Request() req) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return this.adminService.getSalesSummary(startDate, endDate, req.user);
  }

  @Get('reports/top-products')
  @Permissions('loja:relatorios')
  @ApiOperation({ summary: 'Produtos mais vendidos (filtrado por papel)' })
  @ApiQuery({ name: 'limit', required: false, type: Number, default: 10 })
  @ApiResponse({ status: 200, description: 'Lista de produtos mais vendidos' })
  async getTopProducts(@Query('limit') limit: string, @Request() req) {
    return this.adminService.getTopProducts(limit ? parseInt(limit) : 10, req.user);
  }

  @Get('reports/delivery-performance')
  @Permissions('loja:relatorios')
  @ApiOperation({ summary: 'Desempenho de estafetas (filtrado por papel)' })
  @ApiResponse({ status: 200, description: 'Desempenho dos estafetas' })
  async getDeliveryPerformance(@Request() req) {
    return this.adminService.getDeliveryPerformance(req.user);
  }

  @Get('reports/revenue')
  @Permissions('loja:relatorios')
  @ApiOperation({ summary: 'Faturação (filtrado por papel)' })
  @ApiResponse({ status: 200, description: 'Dados de faturação' })
  async getRevenue(@Request() req) {
    return this.adminService.getRevenue(req.user);
  }

  // ---------- GESTÃO DE UTILIZADORES ----------
  @Get('usuarios')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Listar utilizadores (paginado)' })
  @ApiQuery({ name: 'page', required: false, type: Number, default: 1 })
  @ApiQuery({ name: 'limit', required: false, type: Number, default: 10 })
  @ApiQuery({ name: 'tipo', required: false, type: String, enum: ['CLIENTE', 'FORNECEDOR', 'ESTAFETA', 'ADMIN'] })
  @ApiQuery({ name: 'is_ativo', required: false, type: Boolean })
  @ApiResponse({ status: 200, description: 'Lista de utilizadores' })
  async listarUsuarios(
    @Query('page', new DefaultValuePipe(1)) page: number,
    @Query('limit', new DefaultValuePipe(10)) limit: number,
    @Query('tipo') tipo?: string,
    @Query('is_ativo', new DefaultValuePipe(undefined), new ParseBoolPipe({ optional: true })) isAtivo?: boolean,
  ) {
    return this.adminService.listarUsuarios(page, limit, tipo, isAtivo);
  }

  @Get('usuarios/:id')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Obter detalhes de um utilizador' })
  @ApiResponse({ status: 200, description: 'Detalhes do utilizador' })
  @ApiResponse({ status: 404, description: 'Utilizador não encontrado' })
  async getUsuario(@Param('id', ParseIntPipe) id: number) {
    return this.adminService.getUsuario(id);
  }

  @Patch('usuarios/:id/papeis')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Actualizar papéis de um utilizador' })
  @ApiBody({ type: UpdateUsuarioPapeisDto })
  @ApiResponse({ status: 200, description: 'Papéis actualizados' })
  async updateUsuarioPapeis(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateUsuarioPapeisDto,
  ) {
    return this.adminService.updateUsuarioPapeis(id, dto);
  }

  @Patch('usuarios/:id/status')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Activar/desactivar utilizador' })
  @ApiBody({ type: UpdateUsuarioStatusDto })
  @ApiResponse({ status: 200, description: 'Status actualizado' })
  async updateUsuarioStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateUsuarioStatusDto,
  ) {
    return this.adminService.updateUsuarioStatus(id, dto);
  }
}
