import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CupoesService } from './cupoes.service';
import { CupoesController } from './cupoes.controller';
import { Cupoes } from '../entities/Cupoes.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Cupoes])],
  controllers: [CupoesController],
  providers: [CupoesService],
})
export class CupoesModule {}
