import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Cupoes } from '../entities/Cupoes.entity';
import { CreateCupomDto } from './dto/create-cupom.dto';

@Injectable()
export class CupoesService {
  constructor(@InjectRepository(Cupoes) private cupomRepo: Repository<Cupoes>) {}

  async create(createDto: CreateCupomDto) {
    const existente = await this.cupomRepo.findOne({ where: { codigo: createDto.codigo } });
    if (existente) throw new BadRequestException('Código já existe');

    // Converter tipos para corresponder à entidade
    const cupomData = {
      codigo: createDto.codigo,
      descricao: createDto.descricao ?? null,
      tipo_desconto: createDto.tipo_desconto,
      valor_desconto: createDto.valor_desconto.toString(),
      valor_minimo_pedido: createDto.valor_minimo_pedido ? createDto.valor_minimo_pedido.toString() : '0',
      limite_uso_total: createDto.limite_uso_total ?? null,
      limite_uso_por_cliente: createDto.limite_uso_por_cliente || 1,
      data_inicio: new Date(createDto.data_inicio),
      data_fim: new Date(createDto.data_fim),
      is_ativo: createDto.is_ativo !== undefined ? createDto.is_ativo : true,
    };

    const cupom = this.cupomRepo.create(cupomData);
    return await this.cupomRepo.save(cupom);
  }

  async findAll() {
    return await this.cupomRepo.find({ order: { criado_em: 'DESC' } });
  }

  async findOne(id: number) {
    const cupom = await this.cupomRepo.findOne({ where: { id_cupom: id } });
    if (!cupom) throw new NotFoundException('Cupão não encontrado');
    return cupom;
  }

  async validate(codigo: string, valorPedido: number) {
    const cupom = await this.cupomRepo.findOne({ where: { codigo, is_ativo: true } });
    if (!cupom) throw new NotFoundException('Cupão inválido ou inativo');
    const now = new Date();
    if (new Date(cupom.data_inicio) > now || new Date(cupom.data_fim) < now) {
      throw new BadRequestException('Cupão expirado');
    }
    const valorMinimo = parseFloat(cupom.valor_minimo_pedido);
    if (valorPedido < valorMinimo) {
      throw new BadRequestException(`Valor mínimo do pedido é ${cupom.valor_minimo_pedido}`);
    }
    return cupom;
  }

  async meusUsos(idpessoa: number) {
    if (!idpessoa) {
      throw new BadRequestException('Pessoa inválida');
    }
    // Consulta direta via QueryBuilder — usos de cupões pelo cliente
    const usos = await this.cupomRepo.manager.query(
      `SELECT 
         pc.pedido_id,
         pc.cupom_id,
         c.codigo,
         c.descricao,
         c.tipo_desconto,
         c.valor_desconto,
         pc.valor_desconto_aplicado,
         pc.aplicado_em
       FROM pedido_cupom pc
       INNER JOIN cupoes c ON c.id_cupom = pc.cupom_id
       INNER JOIN pedidos p ON p.id_pedido = pc.pedido_id
       WHERE p.cliente_id = ?
       ORDER BY pc.aplicado_em DESC
       LIMIT 100`,
      [idpessoa],
    );
    return usos || [];
  }

}
