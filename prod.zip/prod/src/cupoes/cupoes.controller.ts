import { Controller, Post, Body, Get, Param, Patch, Delete, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { CupoesService } from './cupoes.service';
import { CreateCupomDto } from './dto/create-cupom.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('cupoes')
@Controller('cupoes')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class CupoesController {
  constructor(private readonly cupoesService: CupoesService) {}

  @Post()
  @Permissions('cupoes:criar')
  @ApiOperation({ summary: 'Criar cupão' })
  @ApiBody({ type: CreateCupomDto })
  @ApiResponse({ status: 201, description: 'Cupão criado' })
  create(@Body() createDto: CreateCupomDto) {
    return this.cupoesService.create(createDto);
  }

  @Get()
  @Permissions('cupoes:visualizar')
  @ApiOperation({ summary: 'Listar cupões' })
  @ApiResponse({ status: 200, description: 'Lista de cupões' })
  findAll() {
    return this.cupoesService.findAll();
  }

  @Get(':id')
  @Permissions('cupoes:visualizar')
  @ApiOperation({ summary: 'Obter cupão por ID' })
  findOne(@Param('id') id: string) {
    return this.cupoesService.findOne(+id);
  }

  @Post('validar')
  @ApiOperation({ summary: 'Validar cupão (público, antes do checkout)' })
  @ApiResponse({ status: 200, description: 'Cupão válido' })
  async validar(@Body() body: { codigo: string; valorPedido: number }) {
    return this.cupoesService.validate(body.codigo, body.valorPedido);
  }
}
