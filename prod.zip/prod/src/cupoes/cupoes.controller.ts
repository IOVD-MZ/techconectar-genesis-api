import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  Patch,
  Delete,
  UseGuards,
  Request,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiBody,
} from '@nestjs/swagger';
import { CupoesService } from './cupoes.service';
import { CreateCupomDto } from './dto/create-cupom.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('cupoes')
@Controller('cupoes')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class CupoesController {
  constructor(private readonly cupoesService: CupoesService) {}

  // ═══════════════════════════════════════════════════════════
  // ROTAS ESPECÍFICAS (devem vir PRIMEIRO)
  // ═══════════════════════════════════════════════════════════

  @Get('meus-usos')
  @Permissions('cupoes:visualizar_proprios')
  @ApiOperation({ summary: 'Histórico de cupões usados pelo cliente autenticado' })
  @ApiResponse({ status: 200, description: 'Lista de usos' })
  async meusUsos(@Request() req) {
    return this.cupoesService.meusUsos(req.user.idpessoa);
  }

  @Post('validar')
  @ApiOperation({ summary: 'Validar cupão (público, antes do checkout)' })
  @ApiResponse({ status: 200, description: 'Cupão válido' })
  async validar(@Body() body: { codigo: string; valorPedido: number }) {
    return this.cupoesService.validate(body.codigo, body.valorPedido);
  }

  // ═══════════════════════════════════════════════════════════
  // CRUD BÁSICO
  // ═══════════════════════════════════════════════════════════

  @Post()
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Criar cupão (ADMIN)' })
  @ApiBody({ type: CreateCupomDto })
  @ApiResponse({ status: 201, description: 'Cupão criado' })
  create(@Body() createDto: CreateCupomDto) {
    return this.cupoesService.create(createDto);
  }

  @Get()
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Listar cupões (ADMIN)' })
  @ApiResponse({ status: 200, description: 'Lista de cupões' })
  findAll() {
    return this.cupoesService.findAll();
  }

  // ═══════════════════════════════════════════════════════════
  // ROTA PARAMÉTRICA (deve vir POR ÚLTIMO)
  // ═══════════════════════════════════════════════════════════

  @Get(':id')
  @Permissions('admin:gestao_usuarios')
  @ApiOperation({ summary: 'Obter cupão por ID (ADMIN)' })
  @ApiResponse({ status: 200, description: 'Detalhe do cupão' })
  findOne(@Param('id') id: string) {
    return this.cupoesService.findOne(+id);
  }
}
