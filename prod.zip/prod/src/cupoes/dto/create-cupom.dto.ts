import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsString, IsNumber, IsOptional, IsEnum, IsBoolean, Min, MaxLength } from 'class-validator';

export class CreateCupomDto {
  @ApiProperty({ description: 'Código do cupão', example: 'PROMO20' })
  @IsString()
  @MaxLength(30)
  codigo: string;

  @ApiPropertyOptional({ description: 'Descrição' })
  @IsOptional()
  @IsString()
  descricao?: string;

  @ApiProperty({ enum: ['PERCENTUAL', 'VALOR_FIXO'], example: 'PERCENTUAL' })
  @IsEnum(['PERCENTUAL', 'VALOR_FIXO'])
  tipo_desconto: string;

  @ApiProperty({ description: 'Valor do desconto', example: 20.00 })
  @IsNumber()
  @Min(0)
  valor_desconto: number;

  @ApiPropertyOptional({ description: 'Valor mínimo do pedido', example: 100.00 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  valor_minimo_pedido?: number;

  @ApiPropertyOptional({ description: 'Limite de uso total', example: 100 })
  @IsOptional()
  @IsNumber()
  @Min(1)
  limite_uso_total?: number;

  @ApiPropertyOptional({ description: 'Limite por cliente', example: 1 })
  @IsOptional()
  @IsNumber()
  @Min(1)
  limite_uso_por_cliente?: number;

  @ApiProperty({ description: 'Data de início', example: '2026-08-20T00:00:00.000Z' })
  @IsString()
  data_inicio: string;

  @ApiProperty({ description: 'Data de fim', example: '2026-08-31T23:59:59.000Z' })
  @IsString()
  data_fim: string;

  @ApiPropertyOptional({ description: 'Ativo', default: true })
  @IsOptional()
  @IsBoolean()
  is_ativo?: boolean;
}
