import { Controller, Post, Body, Get, UseGuards, Request, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiBody } from '@nestjs/swagger';
import { VendasService } from './vendas.service';
import { VendaBalcaoDto } from './dto/venda-balcao.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';

@ApiTags('vendas')
@Controller('vendas')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
export class VendasController {
  constructor(private readonly vendasService: VendasService) {}

  @Post('balcao')
  @Permissions('vendas:balcao')
  @ApiOperation({ summary: 'Realizar venda balcão (sem cliente cadastrado)' })
  @ApiBody({ type: VendaBalcaoDto })
  @ApiResponse({ status: 201, description: 'Venda realizada com sucesso' })
  async vendaBalcao(@Body() dto: VendaBalcaoDto, @Request() req) {
    // Se for fornecedor, usa o idpessoa do token; se for admin, pode especificar no dto
    const fornecedorId = req.user.papeis && req.user.papeis.includes('FORNECEDOR')
      ? req.user.idpessoa
      : dto.fornecedor_id;
    return this.vendasService.vendaBalcao(fornecedorId, dto);
  }

  @Get('balcao')
  @Permissions('vendas:balcao')
  @ApiOperation({ summary: 'Listar vendas balcão (filtrado por papel)' })
  @ApiResponse({ status: 200, description: 'Lista de vendas balcão' })
  async listarVendasBalcao(@Request() req) {
    const fornecedorId = req.user.papeis && req.user.papeis.includes('FORNECEDOR')
      ? req.user.idpessoa
      : undefined;
    return this.vendasService.listarVendasBalcao(fornecedorId);
  }
}
