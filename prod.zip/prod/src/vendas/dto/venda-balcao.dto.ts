import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, ValidateNested, IsNumber, IsString, IsOptional, Min } from 'class-validator';
import { Type } from 'class-transformer';

class ItemVendaDto {
  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsOptional()
  @IsNumber()
  produto_id: number;

  @ApiProperty({ example: 2 })
  @IsOptional()
  @IsOptional()
  @IsNumber()
  @Min(1)
  quantidade: number;
}

export class VendaBalcaoDto {
  @ApiProperty({ example: 1, description: 'ID do fornecedor (loja)' })
  @IsOptional()
  @IsOptional()
  @IsNumber()
  fornecedor_id?: number;

  @ApiProperty({ example: [{ produto_id: 1, quantidade: 2 }] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ItemVendaDto)
  itens: ItemVendaDto[];

  @ApiPropertyOptional({ example: 'Bairro 3, Songo', description: 'Endereço de entrega (opcional)' })
  @IsOptional()
  @IsString()
  endereco_entrega?: string;

  @ApiPropertyOptional({ example: 'Venda presencial', description: 'Observações' })
  @IsOptional()
  @IsString()
  observacoes?: string;
}
