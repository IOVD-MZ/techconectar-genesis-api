import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VendasService } from './vendas.service';
import { VendasController } from './vendas.controller';
import { Pedidos } from '../entities/Pedidos.entity';
import { SubPedidos } from '../entities/SubPedidos.entity';
import { PedidoItens } from '../entities/PedidoItens.entity';
import { Produtos } from '../entities/Produtos.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { EventsModule } from '../events/events.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Pedidos, SubPedidos, PedidoItens, Produtos, Pessoa]),
    EventsModule,
  ],
  controllers: [VendasController],
  providers: [VendasService],
})
export class VendasModule {}
