import { Injectable, BadRequestException, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Pedidos } from '../entities/Pedidos.entity';
import { SubPedidos } from '../entities/SubPedidos.entity';
import { PedidoItens } from '../entities/PedidoItens.entity';
import { Produtos } from '../entities/Produtos.entity';
import { Pessoa } from '../entities/Pessoa.entity';
import { Usuario } from '../entities/Usuario.entity';
import * as bcrypt from 'bcrypt';
import { VendaBalcaoDto } from './dto/venda-balcao.dto';
import { EventsGateway } from '../events/events.gateway';

@Injectable()
export class VendasService {
  constructor(
    @InjectRepository(Pedidos) private pedidoRepo: Repository<Pedidos>,
    @InjectRepository(SubPedidos) private subRepo: Repository<SubPedidos>,
    @InjectRepository(PedidoItens) private itemRepo: Repository<PedidoItens>,
    @InjectRepository(Produtos) private produtoRepo: Repository<Produtos>,
    @InjectRepository(Pessoa) private pessoaRepo: Repository<Pessoa>,
    private dataSource: DataSource,
    private eventsGateway: EventsGateway,
  ) {}

  async vendaBalcao(fornecedorId: number, dto: VendaBalcaoDto) {
    const fornecedor = await this.pessoaRepo.findOne({
      where: { idpessoa: fornecedorId, tipo_pessoa: "FORNECEDOR" },
    });
    if (!fornecedor) throw new NotFoundException("Fornecedor não encontrado");

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      let clienteBalcao = await this.pessoaRepo.findOne({
        where: { nome_completo: "Cliente Balcão", tipo_pessoa: "CLIENTE" },
      });

      if (!clienteBalcao) {
        const senhaHash = await bcrypt.hash("balcao123", 10);
        const usuarioBalcao = await queryRunner.manager.create(Usuario, {
          email: "balcao.co.mz",
          password_hash: senhaHash,
          is_ativo: false,
        });
        await queryRunner.manager.save(usuarioBalcao);
        const pessoaBalcao = await queryRunner.manager.create(Pessoa, {
          idusuario: usuarioBalcao.idusuario,
          nome_completo: "Cliente Balcão",
          tipo_pessoa: "CLIENTE",
          selo_verificacao: true,
          limites: "0.00",
        });
        await queryRunner.manager.save(pessoaBalcao);
        clienteBalcao = pessoaBalcao;
      }

      const pedido = this.pedidoRepo.create({
        cliente_id: clienteBalcao.idpessoa,
        total_produtos: "0",
        taxa_entrega: "0",
        status_pedido: "CONCLUIDO",
        endereco_entrega_alternativo: dto.endereco_entrega || "Venda presencial",
      });
      const savedPedido = await queryRunner.manager.save(pedido);

      const subPedido = this.subRepo.create({
        pedido_pai_id: savedPedido.id_pedido,
        fornecedor_id: fornecedorId,
        subtotal_produtos: "0",
        status_sub_pedido: "ENTREGUE_AO_ESTAFETA",
      });
      const savedSub = await queryRunner.manager.save(subPedido);

      let totalPedido = 0;
      for (const itemDto of dto.itens) {
        const produto = await queryRunner.manager.findOne(Produtos, {
          where: { id_produto: itemDto.produto_id },
        });
        if (!produto) throw new BadRequestException(`Produto ${itemDto.produto_id} não encontrado`);
        if (produto.fornecedor_id !== fornecedorId) {
          throw new ForbiddenException("Produto não pertence a este fornecedor");
        }
        if (produto.stock < itemDto.quantidade) {
          throw new BadRequestException(`Estoque insuficiente para `);
        }

        const preco = produto.preco_promocional ? parseFloat(produto.preco_promocional) : parseFloat(produto.preco);
        const subtotal = preco * itemDto.quantidade;
        totalPedido += subtotal;

        const item = this.itemRepo.create({
          pedido_id: savedPedido.id_pedido,
          sub_pedido_id: savedSub.id_sub_pedido,
          produto_id: produto.id_produto,
          nome_produto_snapshot: produto.nome,
          quantidade: itemDto.quantidade,
          preco_unitario_historico: preco.toString(),
        });
        await queryRunner.manager.save(item);

        produto.stock -= itemDto.quantidade;
        await queryRunner.manager.save(produto);
      }

      await queryRunner.manager.update(Pedidos, savedPedido.id_pedido, {
        total_produtos: totalPedido.toString(),
      });
      await queryRunner.manager.update(SubPedidos, savedSub.id_sub_pedido, {
        subtotal_produtos: totalPedido.toString(),
      });

      await queryRunner.commitTransaction();

      this.eventsGateway.notifyRoom("fornecedores", "venda-balcao-realizada", {
        pedidoId: savedPedido.id_pedido,
        fornecedorId: fornecedorId,
        total: totalPedido,
      });

      return {
        message: "Venda balcão realizada com sucesso",
        pedido_id: savedPedido.id_pedido,
        total: totalPedido,
      };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  async listarVendasBalcao(fornecedorId?: number) {
    const where: any = { status_pedido: 'CONCLUIDO' };
    const clienteBalcao = await this.pessoaRepo.findOne({
      where: { nome_completo: 'Cliente Balcão', tipo_pessoa: 'CLIENTE' },
    });
    if (clienteBalcao) {
      where.cliente_id = clienteBalcao.idpessoa;
    } else {
      return [];
    }

    const pedidos = await this.pedidoRepo.find({
      where,
      relations: { subPedidos: { itens: { produto: true } } },
      order: { data_pedido: 'DESC' },
    });

    if (fornecedorId) {
      return pedidos.filter(p =>
        p.subPedidos?.some(sp => sp.fornecedor_id === fornecedorId)
      );
    }
    return pedidos;
  }
}
